"""Common engine utilities."""
from __future__ import annotations

from typing import Any, Dict


class LevelRestartMixin:
    """Provide a uniform implementation for restarting the current level."""

    state: Dict[str, Any]

    def restart_level(self) -> None:
        """Reset the engine state for the current level in place."""
        level_idx = int(getattr(self, "state", {}).get("level", 0))
        self._reset_level_state(level_idx)

    def _reset_level_state(self, level_idx: int) -> None:  # pragma: no cover - interface
        raise NotImplementedError
