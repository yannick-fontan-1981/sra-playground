# api/standalone_game_api/engine/LS20_engine.py
from __future__ import annotations

import copy
import json
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from ..game_registry import register_game
from .base import LevelRestartMixin

# ---------------------------------------------------------------------------
# 0) Load declarative spec
# ---------------------------------------------------------------------------

_SPEC_PATH = Path(__file__).resolve().parents[2] / "specs" / "LS20-spec.json"


def _load_spec() -> Dict[str, Any]:
    with open(_SPEC_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


LS20_SPEC: Dict[str, Any] = _load_spec()

CANVAS_W = int(LS20_SPEC["canvas"]["width"])
CANVAS_H = int(LS20_SPEC["canvas"]["height"])
BG_COLOR = int(LS20_SPEC["canvas"]["default_fill_color"])

_MOVEMENT_ACTIONS: List[int] = list(LS20_SPEC["controls"]["available_actions"])
ACTIONS: List[int] = [0, *_MOVEMENT_ACTIONS]

COLOR_FLOOR = 3
# Reserved for potential layout tweaks
COLOR_WALL = 4
COLOR_BLACK = 5
COLOR_HEART = 8
COLOR_HEART_EMPTY = 3
COLOR_OXYGEN_FULL = 15
COLOR_OXYGEN_EMPTY = 3
FOG_SPEC = LS20_SPEC["mechanics"].get("fog_of_war", {})
FOG_LEVELS = {int(v) for v in FOG_SPEC.get("enabled_on_levels", [])}
FOG_MASK_TEMPLATE: List[List[int]] = [
    [int(cell) for cell in row]
    for row in FOG_SPEC.get("mask", [])
]
COLOR_FOG = COLOR_BLACK

SELECTED_SPRITE_SPEC = LS20_SPEC["mechanics"]["selected_sprite"]
SHAPE_IDS = [int(s) for s in SELECTED_SPRITE_SPEC["shape_ids"]]
COLOR_CYCLE = [int(c) for c in SELECTED_SPRITE_SPEC["color_cycle"]]
ROTATION_STEP = 90

MAX_HEARTS = int(LS20_SPEC["mechanics"]["hearts"]["max"])
OXYGEN_DOTS = int(LS20_SPEC["mechanics"]["oxygen_system"]["dots_per_level"])

_TILE_LOOKUP: Dict[str, Dict[str, Any]] = {t["id"]: t for t in LS20_SPEC["tiles"]}
_SELECTED_TEMPLATES: List[List[List[Optional[int]]]] = [
    [[cell if cell is not None else None for cell in row] for row in template]
    for template in LS20_SPEC["ui"]["selected_sprite_display"]["templates"]
]


# ---------------------------------------------------------------------------
# 1) Matrix helpers
# ---------------------------------------------------------------------------


def blank_canvas() -> List[List[int]]:
    return [[BG_COLOR for _ in range(CANVAS_W)] for _ in range(CANVAS_H)]


def draw_block(img: List[List[int]], left: int, top: int, w: int, h: int, color: int) -> None:
    for r in range(max(0, top), min(CANVAS_H, top + h)):
        row = img[r]
        for c in range(max(0, left), min(CANVAS_W, left + w)):
            row[c] = color


def _copy_matrix(matrix: Iterable[Iterable[Optional[int]]]) -> List[List[Optional[int]]]:
    return [list(row) for row in matrix]


def rotate_template(template: List[List[Optional[int]]], rotation_deg: int) -> List[List[Optional[int]]]:
    steps = (rotation_deg // 90) % 4
    out = _copy_matrix(template)
    for _ in range(steps):
        out = [list(row) for row in zip(*out[::-1])]
    return out


def scale_template_to_n(template: List[List[Optional[int]]], n: int) -> List[List[Optional[int]]]:
    if n <= 0:
        return []
    th = len(template)
    tw = len(template[0]) if th else 0
    if th == 0 or tw == 0:
        return []
    out: List[List[Optional[int]]] = [[None for _ in range(n)] for _ in range(n)]
    for r in range(n):
        src_r = min((r * th) // n, th - 1)
        row = template[src_r]
        row_len = len(row)
        if row_len == 0:
            continue
        for c in range(n):
            src_c = min((c * row_len) // n, row_len - 1)
            out[r][c] = row[src_c]
    return out


def scale_template_to_rect(
    template: List[List[Optional[int]]],
    target_h: int,
    target_w: int,
) -> List[List[Optional[int]]]:
    if target_h <= 0 or target_w <= 0:
        return []
    th = len(template)
    tw = len(template[0]) if th else 0
    if th == 0 or tw == 0:
        return []
    out: List[List[Optional[int]]] = [[None for _ in range(target_w)] for _ in range(target_h)]
    for r in range(target_h):
        src_r = min((r * th) // target_h, th - 1)
        row = template[src_r]
        row_len = len(row)
        if row_len == 0:
            continue
        for c in range(target_w):
            src_c = min((c * row_len) // target_w, row_len - 1)
            out[r][c] = row[src_c]
    return out


FOG_MASK: List[List[int]] = []
FOG_MASK_CENTER_Y = 0
FOG_MASK_CENTER_X = 0
if FOG_MASK_TEMPLATE:
    FOG_MASK = [
        [1 if int(cell) > 0 else 0 for cell in row]
        for row in FOG_MASK_TEMPLATE
    ]
    visible_coords = [
        (r, c)
        for r, row in enumerate(FOG_MASK_TEMPLATE)
        for c, cell in enumerate(row)
        if int(cell) > 0
    ]
    if visible_coords:
        avg_y = sum(r for r, _ in visible_coords) / len(visible_coords)
        avg_x = sum(c for _, c in visible_coords) / len(visible_coords)
        FOG_MASK_CENTER_Y = min(
            max(int(round(avg_y)), 0),
            max(len(FOG_MASK) - 1, 0),
        )
        FOG_MASK_CENTER_X = min(
            max(int(round(avg_x)), 0),
            max(len(FOG_MASK[0]) - 1, 0) if FOG_MASK else 0,
        )
    elif FOG_MASK:
        FOG_MASK_CENTER_Y = len(FOG_MASK) // 2
        FOG_MASK_CENTER_X = len(FOG_MASK[0]) // 2


def stamp_sprite(
    img: List[List[int]],
    top_px: int,
    left_px: int,
    sprite: List[List[Optional[int]]],
) -> None:
    for r, row in enumerate(sprite):
        rr = top_px + r
        if not (0 <= rr < CANVAS_H):
            continue
        canvas_row = img[rr]
        for c, val in enumerate(row):
            if val is None:
                continue
            cc = left_px + c
            if 0 <= cc < CANVAS_W:
                canvas_row[cc] = int(val)


def tiles_wh(sprite_size_px: int) -> Tuple[int, int]:
    return CANVAS_H // sprite_size_px, CANVAS_W // sprite_size_px


def tile_to_px(tile_y: int, tile_x: int, sprite_size_px: int) -> Tuple[int, int]:
    return tile_y * sprite_size_px, tile_x * sprite_size_px


def _normalize_tiles(value: Optional[Any]) -> List[Tuple[int, int]]:
    if value is None:
        return []
    if isinstance(value, dict):
        value = [value]
    coords: List[Tuple[int, int]] = []
    for item in value:
        coords.append((int(item["y"]), int(item["x"])))
    return coords


def _build_shape_sprite(
    shape_id: int,
    color: int,
    size_px: int,
    rotation_deg: int,
) -> List[List[Optional[int]]]:
    if not _SELECTED_TEMPLATES:
        return []
    try:
        idx = SHAPE_IDS.index(shape_id)
    except ValueError:
        idx = shape_id % len(_SELECTED_TEMPLATES)
    template = _SELECTED_TEMPLATES[idx]
    colored: List[List[Optional[int]]] = []
    for row in template:
        row_out: List[Optional[int]] = []
        for cell in row:
            if cell is None:
                row_out.append(None)
            elif cell == 9:
                row_out.append(9)
            else:
                row_out.append(int(color))
        colored.append(row_out)
    rotated = rotate_template(colored, rotation_deg)
    return scale_template_to_n(rotated, size_px)


def _get_template_sprite(tile_id: str, size_px: int) -> List[List[Optional[int]]]:
    tile = _TILE_LOOKUP[tile_id]
    if "color_matrix_template" in tile:
        template = tile["color_matrix_template"]
        return scale_template_to_n(template, size_px)
    return _copy_matrix(tile.get("color_matrix", []))


# ---------------------------------------------------------------------------
# 2) Engine
# ---------------------------------------------------------------------------


@dataclass
class LS20Engine(LevelRestartMixin):
    spec: Dict[str, Any]
    game_id_runtime: str = field(default_factory=lambda: f"ls20-{uuid.uuid4().hex[:12]}")
    guid: str = field(default_factory=lambda: str(uuid.uuid4()))
    state: Dict[str, Any] = field(default_factory=dict)

    @property
    def available_actions(self) -> List[int]:
        return ACTIONS[:]

    @classmethod
    def reset(cls) -> "LS20Engine":
        inst = cls(copy.deepcopy(LS20_SPEC))
        inst._init_state()
        return inst

    def _init_state(self) -> None:
        levels = int(self.spec["game"]["levels_count"])
        start_sel = self.spec["mechanics"]["selected_sprite"]["starts_with"]
        start_selection = {
            "shape_id": int(start_sel["shape_id"]),
            "color": int(start_sel["color"]),
            "rotation_deg": int(start_sel.get("rotation_deg", 0)),
        }
        self.state = {
            "game_id": self.game_id_runtime,
            "guid": self.guid,
            "score": 0,
            "level": 0,
            "game_state": "NOT_FINISHED",
            "hearts": MAX_HEARTS,
            "oxygen": OXYGEN_DOTS,
            "oxygen_consumed": 0,
            "selected": start_selection,
            "level_completion": [False] * levels,
        }
        self._load_level(0)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def observe(self) -> Dict[str, Any]:
        frame = self._render_frame()
        frames: List[List[List[int]]] = []
        pending_frames = self.state.pop("_pending_transition_frames", None)
        if pending_frames:
            frames.extend(pending_frames)
        frames.append(frame)
        self.state["_last_frame"] = frames[-1]
        game_state = self.state.get("game_state", "NOT_FINISHED")
        obs_state = "WIN" if game_state == "FINISHED" else game_state
        return {
            "game_id": self.game_id_runtime,
            "guid": self.guid,
            "frame": frames,
            "state": obs_state,
            "score": int(self.state.get("score", 0)),
            "action_input": {"id": 0, "data": {"game_id": self.game_id_runtime}},
            "available_actions": self.available_actions,
        }

    def step(self, action: int) -> Tuple[Dict[str, Any], float, bool, Dict[str, Any]]:
        game_state = self.state.get("game_state", "NOT_FINISHED")
        if game_state in {"FINISHED", "LOSE"}:
            obs = self.observe()
            return obs, 0.0, True, {"reason": "already_finished"}

        moved = self._apply_action(action)
        level_completed = False
        if moved:
            self._consume_oxygen()
            if self.state.get("game_state") == "LOSE":
                obs = self.observe()
                return obs, 0.0, True, {"reason": "out_of_oxygen"}
            level_completed = self._apply_tile_interactions()
        reward = 0.0
        if level_completed:
            reward += float(self.spec.get("scoring", {}).get("on_level_complete", {}).get("delta", 1))
        done = self.state.get("game_state") in {"FINISHED", "LOSE"}
        obs = self.observe()
        if self.state.get("game_state") == "FINISHED":
            done = True
        if self.state.get("game_state") == "LOSE":
            done = True
        return obs, reward, done, {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _current_level(self) -> Dict[str, Any]:
        level_idx = int(self.state.get("level", 0))
        level_idx = max(0, min(level_idx, len(self.spec["level_data"]) - 1))
        return self.spec["level_data"][level_idx]

    def _load_level(self, level_idx: int) -> None:
        level = self.spec["level_data"][level_idx]
        self.state["level"] = level_idx
        self.state["hearts"] = MAX_HEARTS
        self.state["cursor_txy"] = (
            int(level["cursor_tile"]["y"]),
            int(level["cursor_tile"]["x"]),
        )
        self.state["_level_start_cursor"] = self.state["cursor_txy"]
        self.state["oxygen"] = OXYGEN_DOTS
        self.state["oxygen_consumed"] = 0
        self.state["capsules_used"] = set()
        default_sel = self.spec["mechanics"]["selected_sprite"]["starts_with"]
        level_sel = level.get("selected_start") or default_sel
        self.state["selected"] = {
            "shape_id": int(level_sel["shape_id"]),
            "color": int(level_sel["color"]),
            "rotation_deg": int(level_sel.get("rotation_deg", 0)),
        }
        self.state["_level_start_selected"] = dict(self.state["selected"])
        containers = _normalize_tiles(level.get("target_containers"))
        self.state["containers"] = containers
        targets: List[Dict[str, Any]] = []
        for idx, target in enumerate(level.get("targets", [])):
            tile = containers[idx] if idx < len(containers) else containers[0]
            targets.append(
                {
                    "tile": tile,
                    "shape_id": int(target["shape_id"]),
                    "color": int(target["color"]),
                    "rotation_deg": int(target.get("rotation_deg", 0)),
                    "cleared": False,
                }
            )
        self.state["level_targets"] = targets
        self.state["shape_changers"] = _normalize_tiles(level.get("shape_changer_tile"))
        self.state["color_changers"] = _normalize_tiles(level.get("color_changer_tile"))
        self.state["rotation_tiles"] = _normalize_tiles(level.get("rotation_tile"))
        self.state["capsule_tiles"] = _normalize_tiles(level.get("capsule_tile"))
        grid_spec = level.get("grid") or {}
        layout: List[List[str]] = []
        if grid_spec:
            raw_layout = grid_spec.get("layout", [])
            for row in raw_layout:
                if isinstance(row, str):
                    layout.append(list(row))
                else:
                    layout.append([str(cell) for cell in row])
        legend = {str(k): str(v) for k, v in grid_spec.get("legend", {}).items()}
        self.state["grid_layout"] = layout
        self.state["grid_legend"] = legend
        wall_symbols = {symbol for symbol, meaning in legend.items() if meaning == "wall"}
        if not wall_symbols:
            wall_symbols = {"W"}
        self.state["grid_wall_symbols"] = wall_symbols
        if layout and layout[0]:
            self.state["grid_size"] = (len(layout), len(layout[0]))
        else:
            self.state["grid_size"] = tiles_wh(int(level["sprite_size_px"]))
        self.state["_sprite_cache"] = {}
        self.state["_last_cursor_tile"] = None
        self.state["game_state"] = "NOT_FINISHED"

    def _reset_level_state(self, level_idx: int) -> None:
        self._load_level(level_idx)
        self.state.pop("_last_frame", None)

    def _apply_action(self, action: int) -> bool:
        if action == 0:
            return False
        if action not in _MOVEMENT_ACTIONS:
            return False
        dy, dx = 0, 0
        if action == 1:
            dy = -1
        elif action == 2:
            dy = 1
        elif action == 3:
            dx = -1
        elif action == 4:
            dx = 1
        cy, cx = self.state["cursor_txy"]
        level = self._current_level()
        n = int(level["sprite_size_px"])
        tiles_h, tiles_w = self.state.get("grid_size", tiles_wh(n))
        ny, nx = cy + dy, cx + dx
        if not (0 <= ny < tiles_h and 0 <= nx < tiles_w):
            return False
        layout = self.state.get("grid_layout", [])
        if layout:
            row = layout[ny]
            wall_symbols: Set[str] = self.state.get("grid_wall_symbols", {"W"})
            if row[nx] in wall_symbols:
                return False
        self.state["cursor_txy"] = (ny, nx)
        return True

    def _consume_oxygen(self) -> None:
        oxygen = int(self.state.get("oxygen", OXYGEN_DOTS))
        if oxygen <= 0:
            self._handle_oxygen_empty()
            return
        oxygen -= 1
        self.state["oxygen"] = oxygen
        self.state["oxygen_consumed"] = OXYGEN_DOTS - oxygen
        if oxygen <= 0:
            self._handle_oxygen_empty()

    def _handle_oxygen_empty(self) -> None:
        hearts = int(self.state.get("hearts", MAX_HEARTS))
        if hearts <= 0:
            self.state["game_state"] = "LOSE"
            self.state["oxygen"] = 0
            self.state["oxygen_consumed"] = OXYGEN_DOTS
            self._reset_selection_to_start()
            return
        hearts -= 1
        self.state["hearts"] = hearts
        if hearts <= 0:
            self.state["game_state"] = "LOSE"
            self.state["oxygen"] = 0
            self.state["oxygen_consumed"] = OXYGEN_DOTS
            self._reset_selection_to_start()
        else:
            self.state["oxygen"] = OXYGEN_DOTS
            self.state["oxygen_consumed"] = 0
            self.state["capsules_used"] = set()
            start = self.state.get("_level_start_cursor")
            if start:
                self.state["cursor_txy"] = tuple(start)
            self.state["_last_cursor_tile"] = None
            self._reset_selection_to_start()

    def _apply_tile_interactions(self) -> bool:
        cy, cx = self.state["cursor_txy"]
        current_tile = (cy, cx)
        if current_tile == self.state.get("_last_cursor_tile"):
            # already processed interactions for this tile
            return False
        self.state["_last_cursor_tile"] = current_tile

        if current_tile in self.state.get("shape_changers", []):
            self._cycle_shape()
        if current_tile in self.state.get("color_changers", []):
            self._cycle_color()
        if current_tile in self.state.get("rotation_tiles", []):
            self._rotate_selection()
        if current_tile in self.state.get("capsule_tiles", []):
            used: Set[Tuple[int, int]] = self.state.setdefault("capsules_used", set())
            if current_tile not in used:
                used.add(current_tile)
                self.state["oxygen"] = OXYGEN_DOTS
                self.state["oxygen_consumed"] = 0

        level_completed = self._check_targets()
        return level_completed

    def _cycle_shape(self) -> None:
        selected = self.state["selected"]
        shape_id = int(selected.get("shape_id", SHAPE_IDS[0]))
        try:
            idx = SHAPE_IDS.index(shape_id)
        except ValueError:
            idx = 0
        shape_id = SHAPE_IDS[(idx + 1) % len(SHAPE_IDS)]
        selected["shape_id"] = shape_id

    def _cycle_color(self) -> None:
        selected = self.state["selected"]
        color = int(selected.get("color", COLOR_CYCLE[0]))
        try:
            idx = COLOR_CYCLE.index(color)
        except ValueError:
            idx = 0
        color = COLOR_CYCLE[(idx + 1) % len(COLOR_CYCLE)]
        selected["color"] = color

    def _rotate_selection(self) -> None:
        selected = self.state["selected"]
        rotation = int(selected.get("rotation_deg", 0))
        rotation = (rotation + ROTATION_STEP) % 360
        selected["rotation_deg"] = rotation

    def _reset_selection_to_start(self) -> None:
        start = self.state.get("_level_start_selected")
        if start:
            self.state["selected"] = {
                "shape_id": int(start.get("shape_id", SHAPE_IDS[0])),
                "color": int(start.get("color", COLOR_CYCLE[0])),
                "rotation_deg": int(start.get("rotation_deg", 0)),
            }
            return
        default_sel = self.spec["mechanics"]["selected_sprite"]["starts_with"]
        self.state["selected"] = {
            "shape_id": int(default_sel["shape_id"]),
            "color": int(default_sel["color"]),
            "rotation_deg": int(default_sel.get("rotation_deg", 0)),
        }

    def _check_targets(self) -> bool:
        cy, cx = self.state["cursor_txy"]
        selection = self.state["selected"]
        match_found = False
        for target in self.state.get("level_targets", []):
            if target["cleared"]:
                continue
            if target["tile"] != (cy, cx):
                continue
            if self._selection_matches(target, selection):
                target["cleared"] = True
                match_found = True
        if match_found and all(t.get("cleared") for t in self.state.get("level_targets", [])):
            self._complete_level()
            return True
        return False

    def _selection_matches(self, target: Dict[str, Any], selection: Dict[str, Any]) -> bool:
        return (
            int(target["shape_id"]) == int(selection.get("shape_id"))
            and int(target["color"]) == int(selection.get("color"))
            and int(target.get("rotation_deg", 0)) % 360
            == int(selection.get("rotation_deg", 0)) % 360
        )

    def _complete_level(self) -> None:
        level_idx = int(self.state.get("level", 0))
        self.state["level_completion"][level_idx] = True
        current_score = int(self.state.get("score", 0))
        self.state["score"] = current_score + int(
            self.spec.get("scoring", {}).get("on_level_complete", {}).get("delta", 1)
        )
        total_levels = int(self.spec["game"]["levels_count"])
        winning_frame: Optional[List[List[int]]] = None
        if level_idx + 1 < total_levels:
            winning_frame = self._render_frame()
        if level_idx + 1 >= total_levels:
            self.state["game_state"] = "FINISHED"
        else:
            if winning_frame is not None:
                self.state["_pending_transition_frames"] = [winning_frame]
            self._load_level(level_idx + 1)

    def skip_level(self) -> None:
        level_idx = int(self.state.get("level", 0))
        total_levels = int(self.spec["game"]["levels_count"])
        if level_idx + 1 >= total_levels:
            self.state["game_state"] = "FINISHED"
            return

        completion = self.state.get("level_completion")
        if isinstance(completion, list) and 0 <= level_idx < len(completion):
            completion[level_idx] = True

        self._load_level(level_idx + 1)

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _render_frame(self) -> List[List[int]]:
        img = blank_canvas()
        level = self._current_level()
        n = int(level["sprite_size_px"])
        tiles_h, tiles_w = self.state.get("grid_size", tiles_wh(n))

        layout = self.state.get("grid_layout", [])
        wall_symbols: Set[str] = self.state.get("grid_wall_symbols", {"W"})
        if layout:
            for ty, row in enumerate(layout):
                for tx, symbol in enumerate(row):
                    top, left = tile_to_px(ty, tx, n)
                    color = COLOR_WALL if symbol in wall_symbols else COLOR_FLOOR
                    draw_block(img, left, top, n, n, color)
        else:
            for ty in range(1, tiles_h):
                for tx in range(0, tiles_w):
                    top, left = tile_to_px(ty, tx, n)
                    draw_block(img, left, top, n, n, COLOR_FLOOR)

        sprite_cache: Dict[Tuple[str, int], List[List[Optional[int]]]] = self.state.setdefault(
            "_sprite_cache", {}
        )

        def cached_sprite(tile_id: str, size_px: int) -> List[List[Optional[int]]]:
            key = (tile_id, size_px)
            if key not in sprite_cache:
                sprite_cache[key] = _get_template_sprite(tile_id, size_px)
            return sprite_cache[key]

        active_target_tiles: Set[Tuple[int, int]] = {
            tuple(target["tile"])
            for target in self.state.get("level_targets", [])
            if not target.get("cleared")
        }

        # target containers
        for container in self.state.get("containers", []):
            if active_target_tiles and tuple(container) not in active_target_tiles:
                continue
            ty, tx = container
            top, left = tile_to_px(ty, tx, n)
            sprite = cached_sprite("target_container", n)
            stamp_sprite(img, top, left, sprite)

        # capsules
        for ty, tx in self.state.get("capsule_tiles", []):
            if (ty, tx) in self.state.get("capsules_used", set()):
                continue
            sprite = cached_sprite("oxygen_capsule", n)
            top, left = tile_to_px(ty, tx, n)
            stamp_sprite(img, top, left, sprite)

        # shape changers
        for ty, tx in self.state.get("shape_changers", []):
            sprite = cached_sprite("shape_changer", n)
            top, left = tile_to_px(ty, tx, n)
            stamp_sprite(img, top, left, sprite)

        # color changers
        for ty, tx in self.state.get("color_changers", []):
            sprite = cached_sprite("color_changer", n)
            top, left = tile_to_px(ty, tx, n)
            stamp_sprite(img, top, left, sprite)

        # rotation tiles
        for ty, tx in self.state.get("rotation_tiles", []):
            sprite = cached_sprite("rotation_station", n)
            top, left = tile_to_px(ty, tx, n)
            stamp_sprite(img, top, left, sprite)

        # targets (only those not cleared)
        margin = max(1, n // 4)
        margin = min(margin, max(0, n - 1))
        sprite_start = margin
        sprite_size = max(1, n - margin)
        for target in self.state.get("level_targets", []):
            if target.get("cleared"):
                continue
            ty, tx = target["tile"]
            top, left = tile_to_px(ty, tx, n)
            sprite = _build_shape_sprite(
                int(target["shape_id"]),
                int(target["color"]),
                sprite_size,
                int(target.get("rotation_deg", 0)),
            )
            stamp_sprite(img, top + sprite_start, left + sprite_start, sprite)

        # Fog of war (if enabled for this level)
        self._apply_fog(img, n)

        # cursor
        cy, cx = self.state.get("cursor_txy", (0, 0))
        cursor_sprite = cached_sprite("cursor_sprite", n)
        top, left = tile_to_px(cy, cx, n)
        stamp_sprite(img, top, left, cursor_sprite)

        # UI overlays
        self._render_ui(img, n)
        return img

    def _apply_fog(self, img: List[List[int]], sprite_size_px: int) -> None:
        if not FOG_LEVELS or not FOG_MASK:
            return
        current_level = int(self.state.get("level", 0)) + 1
        if current_level not in FOG_LEVELS:
            return
        cy, cx = self.state.get("cursor_txy", (0, 0))
        cursor_top, cursor_left = tile_to_px(cy, cx, sprite_size_px)
        cursor_center_y = cursor_top + sprite_size_px // 2
        cursor_center_x = cursor_left + sprite_size_px // 2

        mask_top = cursor_center_y - FOG_MASK_CENTER_Y
        mask_left = cursor_center_x - FOG_MASK_CENTER_X

        visible: List[List[bool]] = [
            [False for _ in range(CANVAS_W)] for _ in range(CANVAS_H)
        ]

        for r, row in enumerate(FOG_MASK):
            canvas_r = mask_top + r
            if not (0 <= canvas_r < CANVAS_H):
                continue
            visible_row = visible[canvas_r]
            for c, mask_val in enumerate(row):
                if not mask_val:
                    continue
                canvas_c = mask_left + c
                if 0 <= canvas_c < CANVAS_W:
                    visible_row[canvas_c] = True

        for r in range(CANVAS_H):
            canvas_row = img[r]
            visible_row = visible[r]
            for c in range(CANVAS_W):
                if not visible_row[c]:
                    canvas_row[c] = COLOR_FOG

    def _render_ui(self, img: List[List[int]], sprite_size_px: int) -> None:
        # Oxygen bar
        oxygen_bar = _copy_matrix(_TILE_LOOKUP["oxygen_bar"]["color_matrix"])
        oxygen_remaining = int(self.state.get("oxygen", OXYGEN_DOTS))
        consumed = max(0, OXYGEN_DOTS - oxygen_remaining)
        dot_index = 0
        row = oxygen_bar[0]
        for idx, val in enumerate(row):
            if val == COLOR_OXYGEN_FULL:
                if dot_index < consumed:
                    row[idx] = COLOR_OXYGEN_EMPTY
                dot_index += 1
        pos = LS20_SPEC["ui"]["oxygen_bar"]["position_px"]
        stamp_sprite(img, int(pos["y"]), int(pos["x"]), oxygen_bar)

        # Hearts
        heart_bar = _copy_matrix(_TILE_LOOKUP["heart_bar"]["color_matrix"])
        hearts_remaining = max(0, int(self.state.get("hearts", MAX_HEARTS)))
        lost = MAX_HEARTS - hearts_remaining
        heart_groups = [(0, 1), (4, 5), (8, 9)]
        for idx, (start, end) in enumerate(reversed(heart_groups)):
            if idx < lost:
                for r in range(len(heart_bar)):
                    for c in range(start, end + 1):
                        if heart_bar[r][c] == COLOR_HEART:
                            heart_bar[r][c] = COLOR_HEART_EMPTY
        pos = LS20_SPEC["ui"]["heart_display"]["position_px"]
        stamp_sprite(img, int(pos["y"]), int(pos["x"]), heart_bar)

        # Level progress
        level_bar = _copy_matrix(_TILE_LOOKUP["level_bar"]["color_matrix"])
        completed = sum(1 for done in self.state.get("level_completion", []) if done)
        segments: List[Tuple[int, int]] = []
        start: Optional[int] = None
        for idx, val in enumerate(level_bar[0]):
            if val == COLOR_FLOOR:
                if start is None:
                    start = idx
            else:
                if start is not None:
                    segments.append((start, idx))
                    start = None
        if start is not None:
            segments.append((start, len(level_bar[0])))
        complete_color = int(LS20_SPEC["mechanics"]["level_progress"]["complete_color"])
        for seg_idx, (s, e) in enumerate(segments):
            if seg_idx < completed:
                for c in range(s, e):
                    level_bar[0][c] = complete_color
        pos = LS20_SPEC["ui"]["level_progress"]["position_px"]
        stamp_sprite(img, int(pos["y"]), int(pos["x"]), level_bar)

        # Selected sprite display
        selected = self.state.get("selected", {})
        template_size = len(_SELECTED_TEMPLATES[0]) if _SELECTED_TEMPLATES else 0
        sprite_size = max(1, template_size * 3) if template_size else max(1, sprite_size_px)
        sprite = _build_shape_sprite(
            int(selected.get("shape_id", SHAPE_IDS[0])),
            int(selected.get("color", COLOR_CYCLE[0])),
            sprite_size,
            int(selected.get("rotation_deg", 0)),
        )
        pos = LS20_SPEC["ui"]["selected_sprite_display"]["position_px"]
        stamp_sprite(img, int(pos["y"]), int(pos["x"]), sprite)


# ---------------------------------------------------------------------------
# 3) Public helpers
# ---------------------------------------------------------------------------


def reset() -> Tuple[List[List[int]], Dict[str, Any]]:
    env = LS20Engine.reset()
    obs = env.observe()
    return obs["frame"][0], {"palette": LS20_SPEC.get("palette")}


def step(action_name: str) -> Tuple[List[List[int]], Dict[str, Any], bool]:
    name_to_id = {
        "reset": 0,
        "ACTION0": 0,
        "up": 1,
        "down": 2,
        "left": 3,
        "right": 4,
        "ACTION1": 1,
        "ACTION2": 2,
        "ACTION3": 3,
        "ACTION4": 4,
    }
    aid = name_to_id.get(action_name, 1)
    global _ENV_SINGLETON
    try:
        _ENV_SINGLETON
    except NameError:
        _ENV_SINGLETON = LS20Engine.reset()
    obs, reward, done, info = _ENV_SINGLETON.step(aid)
    return obs["frame"][0], {"reward": reward, "info": info}, bool(done)


# ---------------------------------------------------------------------------
# 4) Registration
# ---------------------------------------------------------------------------


def _factory() -> LS20Engine:
    return LS20Engine.reset()


register_game(
    game_id="LS20",
    factory=_factory,
    title="LS20 – Oxygen Shapes",
    description="Cycle shapes and colors to match targets before your oxygen runs out.",
    version="1.0.0",
    tags=["grid", "puzzle", "oxygen", "shapes"],
)
