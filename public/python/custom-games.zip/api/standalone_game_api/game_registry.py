# api/standalone_game_api/game_registry.py
from typing import Any, Callable, Dict, List

_GAME_REGISTRY: Dict[str, Dict[str, Any]] = {}

def register_game(
    game_id: str,
    factory: Callable[[], Any],
    title: str,
    description: str,
    version: str = "1.0.0",
    tags: List[str] | None = None,
) -> None:
    _GAME_REGISTRY[game_id] = {
        "game_id": game_id,
        "title": title,
        "description": description,
        "version": version,
        "tags": tags or [],
        "factory": factory,  # internal only
    }

def get_game(game_id: str) -> Dict[str, Any] | None:
    return _GAME_REGISTRY.get(game_id)

def all_games() -> List[Dict[str, Any]]:
    # Remove the non-serializable "factory" before returning
    return [{k: v for k, v in meta.items() if k != "factory"} for meta in _GAME_REGISTRY.values()]
