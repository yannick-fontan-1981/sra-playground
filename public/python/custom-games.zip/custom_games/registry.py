"""Registry of custom games (data-driven, not official downloads)."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class CustomGameInfo:
    game_id: str
    title: str
    family: str
    levels: int
    engine: str
    description: str
    default_fps: int = 8
    # Dropdown label wave: "custom", "custom_2" or "custom_3".
    wave: str = "custom"


CUSTOM_GAMES: tuple[CustomGameInfo, ...] = (
    CustomGameInfo(
        game_id="skbn-c0000001",
        title="SKBN",
        family="push_only_box_deadlock",
        levels=6,
        engine="sokoban",
        description="Custom Sokoban: push boxes onto targets (6 levels).",
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="clrs-c0000001",
        title="CLRS",
        family="additive_rgb_glass",
        levels=6,
        engine="color_glass",
        description=(
            "Additive RGB glass panes: R+G=Y, G+B=C, B+R=M, RGB=W. "
            "Click select, arrows move, SPACE rotate; match center 10x10 to legend."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="swch-c0000001",
        title="SWCH",
        family="switch_door_battery",
        levels=6,
        engine="switch_rooms",
        description=(
            "Multi-piece rooms: light switches (yellow+piece), door switches "
            "(A+grey+B), battery budget; dark when unlit; arrows only."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="stck-c0000001",
        title="STCK",
        family="isometric_card_stack_combat",
        levels=6,
        engine="stack_iso",
        description=(
            "Isometric diamond grid: build a color card stack at the magenta shop "
            "(per-level palette + max_stack). SPACE executes bottom→top "
            "(cyan L, blue U, green R, yellow D, red attack-8, pink push-8-neighbours). "
            "Damage removes top; orange/grey holes kill; clear all foes."
        ),
        default_fps=10,
    ),
    CustomGameInfo(
        game_id="hano-c0000001",
        title="HANO",
        family="hanoi_order",
        levels=4,
        engine="hanoi",
        description=(
            "Tower of Hanoi: only top disc moves; only a smaller disc may rest on "
            "a larger one. Start left; rebuild full ordered tower on the rightmost "
            "peg (white + ghost outline). Click peg to pick/place (ACTION6)."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="seqn-c0000001",
        title="SEQN",
        family="directional_symbol_sequence_groups",
        levels=6,
        engine="seqn_groups",
        description=(
            "Red frames of symbol sequences (triangle/circle/square/star). "
            "Direction keys light matching white-focus symbols green; mismatch "
            "resets unfinished frames; completed frames lock green. Tight pip bar; "
            "start-order is the puzzle."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="mind-c0000001",
        title="MIND",
        family="mastermind_code",
        levels=6,
        engine="mind_code",
        description=(
            "Mastermind-style code breaking: click palette colours to build a guess, "
            "SPACE/SUBMIT to score. Feedback uses yellow (exact place) and cyan "
            "(colour present, wrong place) — not semantic black/white pegs. "
            "L01 has white didactic click outlines."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="memo-c0000001",
        title="MEMO",
        family="identity_match_across_time",
        levels=6,
        engine="memo_recall",
        description=(
            "Circle recall: click a symbol that was present on the previous step. "
            "10 stages, 15-click budget. Colours/rotation/zoom harden across levels. "
            "L01 has white didactic outlines on the target symbol."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="regn-c0000001",
        title="REGN",
        family="multi_gauge_equilibrium",
        levels=6,
        engine="reign_gauges",
        description=(
            "Three RGB gauges with low/high limits. Choose left or right trios of "
            "+/− consumables, recurring triangles, and coloured transfers. "
            "Keep all gauges in-bounds for N steps (10+2 per level)."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="conn-c0000001",
        title="CONN",
        family="line_config_vs_adversary",
        levels=6,
        engine="connect_four",
        description=(
            "Connect Four 7×6: click a column to drop. L01 teaches the four "
            "winning lines on mini-boards; L02–L06 are versus a scripted AI "
            "of rising strength. Player is yellow, adversary red."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="dnoi-c0000001",
        title="DNOI",
        family="consensus_line_denoise",
        levels=6,
        engine="denoise_trame",
        description=(
            "Denoise a patterned grid: click big pixels to toggle broken↔correct. "
            "L01 foreign noise colour; later levels camouflage noise using trame "
            "colours. Oracle matches ARC-2 constelize consensus denoise."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="syme-c0000001",
        title="SYME",
        family="symmetric_completion",
        levels=6,
        engine="symmetry_fix",
        description=(
            "Repair broken symmetry by toggling broken↔correct. No axis is drawn: "
            "infer H/V/rot180 or H+V. Foreign holes early; camouflage on double-axis "
            "late levels. UX like DNOI."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="gori-c0000001",
        title="GORI",
        family="ballistic_hit_under_gravity",
        levels=6,
        engine="gori_ballistics",
        description=(
            "Gorillas-like ballistic aim: left/right power gauge (start 50%), "
            "click to fire toward a point. Passive target is passive. Miss reconfigures "
            "the whole skyline. L04 one portal pair; L05 two pairs; L06 two pairs "
            "with 90° velocity rotation."
        ),
        default_fps=10,
    ),
    CustomGameInfo(
        game_id="keyd-c0000001",
        title="KEYD",
        family="typed_key_allocation_interlevel",
        levels=6,
        engine="key_doors",
        description=(
            "Typed keys and doors under bounded inventory: consumption, reusable "
            "keys, non-commutative allocation, topology-coded types, and hidden "
            "inter-level possession recall."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="logi-c0000001",
        title="LOGI",
        family="abstract_coloured_electronic_circuits",
        levels=6,
        engine="logic_circuit",
        description=(
            "Dense coloured circuits with abstract three- and four-wire gates, "
            "live propagation, direct switch clicks, mixed solutions, and automatic lamp completion."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="port-c0000001",
        title="PORT",
        family="portal_topology_graph_rewrite_interlevel",
        levels=6,
        engine="portal_topology",
        description=(
            "Oriented portal pairs across separated rooms: learn stable identities, "
            "preserve exit pose, remember hidden pairings between levels, and replan "
            "when a switch rewrites the topology."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="fogw-c0000001",
        title="FOGW",
        family="hidden_motion_delayed_causality_interlevel",
        levels=6,
        engine="fog_hidden_motion",
        description=(
            "Track shaped entities through opaque fog, preserve episode-specific "
            "direction and timing, synchronize capture bays, and revise hidden "
            "routes after delayed switches."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="life-c0000001",
        title="LIFE",
        family="entity_lifecycle_lineage_interlevel",
        levels=6,
        engine="life_lineage",
        description=(
            "Follow stable lineage signatures through birth, compatible merges, "
            "compound splits, changed shells, and episode-specific destination "
            "phenotypes remembered between levels."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="valv-c0000001",
        title="VALV",
        family="finite_flow_inverse_pump_tower_overflow_interlevel",
        levels=6,
        engine="valve_flow",
        description=(
            "Route and recover a finite water stock through reversible valves, "
            "prime hidden relays, stage all-at-once water-tower bursts, and satisfy "
            "permuted target gauges without sewer loss or animated overflow."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="sign-c0000001",
        title="SIGN",
        family="deceptive_signal_terminal_validation",
        levels=6,
        engine="signal_seal",
        description=(
            "Authenticate true beacons among decoys: step-on glow is only a visual "
            "cue; SPACE seals underfoot (true→gauge+white core, false→brown). No "
            "click. Covers inverted HUD until calibrate, shape/position channels, "
            "and delayed SPACE validation."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="casc-c0000001",
        title="CASC",
        family="autonomous_cascade_quiescence",
        levels=6,
        engine="cascade_quiesce",
        description=(
            "Metro-like domino routing: 3x3 tiles with 1px gaps, brown blockers, "
            "magenta continuators. L01 is SPACE-only; later levels need precise "
            "smother/bridge. Multi-terminal Tokyo/NY/Paris maps. Pink O; spent=brown."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="craf-c0000001",
        title="CRAF",
        family="craft_recipe_multiset_economy",
        levels=6,
        engine="craft_console",
        description=(
            "Night-watch craft console: click stock bins into recipe slots, SPACE "
            "crafts (A+B→C), click ORDER to ship. Shared rare resources, morphology "
            "swap, intermediate chains, tight energy, and X↔Y exchange bay."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="esct-c0000001",
        title="ESCT",
        family="other_agent_patrol_escort_passage",
        levels=6,
        engine="escort_patrol",
        description=(
            "Night-watch escort console: a passive convoy advances on a rail while a "
            "deterministic patrol closes in. Cage hunters and clear several delayed "
            "rail chokes; collision resets the level. Later arenas mix fast and "
            "predictive hunters while role colours stay stable."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="ls19-c0000001",
        title="LS19",
        family="legacy_shape_color_rotation_alignment",
        levels=8,
        engine="ls19_legacy",
        description=(
            "Preserved standalone LS20 Legacy game under the LS19 custom identity: "
            "navigate, change shape/color/rotation, manage oxygen, and align with "
            "the matching target across all 8 original levels."
        ),
        default_fps=10,
    ),
    CustomGameInfo(
        game_id="fite-c0000001",
        title="FITE",
        family="survive_N_affinity_combat",
        levels=6,
        engine="fite_arena",
        description=(
            "Turn-based arena: colour kits, move then auto-power (no SPACE), "
            "white-outline player, initiative HUD. Survive 10+level turns with 3 hearts. "
            "Immortal enemies aggro nearest (fight each other). Damage copies attacker kit."
        ),
        default_fps=8,
    ),
    CustomGameInfo(
        game_id="as66-c0000001",
        title="AS66",
        family="always_sliding_wrap_slots",
        levels=9,
        engine="always_sliding",
        description=(
            "Always Sliding (AS66): arrows slide all cursors until blocked; wrap at "
            "edges (edge flashes green). Seat every cursor in a U-slot at once. Later "
            "levels add colour matching, paint portals, and orange blockers/patrols."
        ),
        default_fps=12,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="gare-c0000001",
        title="GARE",
        family="cadenced_rail_transfer",
        levels=6,
        engine="gare_cadence",
        description=(
            "Gare cadencée: click rail buttons to slide trains, then mechanical arms "
            "auto-transfer boxes after the full animation reconciles. Distinguish "
            "stable clicks from intermediate frames; later levels add inverse arms, "
            "red mismatch slots, multi-train rails, and a reset-only trap entry."
        ),
        default_fps=10,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="colm-c0000001",
        title="COLM",
        family="falling_column_match3",
        levels=6,
        engine="columns_match",
        description=(
            "Columns-like: steer a falling triple of jewels, cycle their colours, "
            "match 3+ in a line (H/V/diag). Clears cascade with gravity. Distinct "
            "from craft/inventory games."
        ),
        default_fps=12,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="gaba-c0000001",
        title="GABA",
        family="transport_footprint_clearance",
        levels=6,
        engine="transport_gabarit",
        description=(
            "Transport sous gabarit: carry cargo whose footprint must clear corridors. "
            "Attach/detach with SPACE, rotate with ACTION6. Centre-ok / corner-blocked "
            "is the key trap (Moving Out / Snakebird lineage)."
        ),
        default_fps=10,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="fuit-c0000001",
        title="FUIT",
        family="flee_push_trap",
        levels=6,
        engine="flee_stones",
        description=(
            "Fuite sous pierres: catch a fleeing element by pushing stones to "
            "seal escape routes (walls + Sokoban-1 stones). Deterministic flee "
            "after each move. L03 requires forcing the fleer onto a purple net."
        ),
        default_fps=10,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="etag-c0000001",
        title="ETAG",
        family="multi_floor_labyrinth",
        levels=6,
        engine="etag_floors",
        description=(
            "Labyrinthe à étages: grille 12×12, cellules 4px, gaps+bordure orange. "
            "Multi-cages + allers-retours; jauge d'actions (serrée L4–L6). "
            "Entrée/sortie escalier face grise; rejoindre la sortie."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="tict-c0000001",
        title="TICT",
        family="align_3_vs_adversary",
        levels=6,
        engine="tic_tac_toe",
        description=(
            "Tic-tac-toe 3×3: click empty cells (X yellow vs O red). "
            "L01 saboteur AI; later levels add opponent/player pre-moves, "
            "then multi-boards (win ≥1). L06 perfect minimax on 4 boards. "
            "Animated pulse on three-in-a-row."
        ),
        default_fps=10,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="glob-c0000001",
        title="GLOB",
        family="globe_track_record",
        levels=6,
        engine="globe_track",
        description=(
            "Globe track: 7 latitude rings (1-4-7-10-7-4-1). Click a slot to "
            "arm a path; SPACE plays recorded directions. Lava/cyclone/cyan "
            "hazards; reach the green goal. Exact ASCII globe frame."
        ),
        default_fps=10,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="kata-c0000001",
        title="KATA",
        family="pentomino_packing",
        levels=6,
        engine="katamino",
        description=(
            "Katamino-style pentomino packing: pick, move, rotate and release "
            "pieces to tile the board. Fixed hint pieces, collision preview, "
            "and increasing board sizes across L01–L06."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="hole-c0000001",
        title="HOLE",
        family="additive_hole_paint",
        levels=6,
        engine="hole_palette",
        description=(
            "Hole palette: paint nested regions with R/G/B primaries. Mixing "
            "yields Y/P/C; same-color parent/child conflicts error-reset. "
            "Inspired by ARC e3721c99."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="grav-c0000001",
        title="GRAV",
        family="gravity_box",
        levels=6,
        engine="gravity_box",
        description=(
            "Gravity Box: choose wall gravity (N/E/S/W) so colored crates slide "
            "and stick to matching walls. Later levels add obstacles and a glue "
            "toggle. 64×64 pixel controls; six authored boards."
        ),
        default_fps=20,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="vois-c0000001",
        title="VOIS",
        family="neighbor_cubes",
        levels=6,
        engine="neighbor_cubes",
        description=(
            "Neighbor Cubes: arrange movable cubes so their orthogonal-neighbor "
            "colors reproduce the legend inside one of the outlined zones. "
            "Six authored 64x64 boards with keyboard and pixel-click controls."
        ),
        default_fps=10,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="pola-c0000001",
        title="POLA",
        family="polarity",
        levels=6,
        engine="polarity",
        description=(
            "Polarity: rotate selected red/blue magnets, then let attraction "
            "and repulsion settle the board until a magnet reaches the green "
            "target. Six authored 64x64 magnetic-physics puzzles."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="elas-c0000001",
        title="ELAS",
        family="elastic_grid",
        levels=6,
        engine="elastic_grid",
        description=(
            "Elastic Grid: move and stack colored tiles on an irregular grid "
            "until the visible raster exactly matches the legend at a uniform "
            "scale. Six authored 64x64 boards with hidden stacked tiles."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="tria-c0000001",
        title="TRIA",
        family="triade",
        levels=6,
        engine="triade",
        description=(
            "Triade: steer three colored cubes with three independent "
            "joysticks until their relative arrangement matches the legend. "
            "Six authored 64x64 toroidal movement puzzles."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="seri-c0000001",
        title="SERI",
        family="sequence_lab",
        levels=6,
        engine="sequence_lab",
        description=(
            "Sequence Lab: infer the missing glyph in four visual sequences "
            "per level, select one of three proposals, and submit it. Six "
            "authored 64x64 visual-reasoning levels."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="comb-c0000001",
        title="COMB",
        family="combina",
        levels=6,
        engine="combina",
        description=(
            "Combina: press two to four cyclic indicator buttons and visit "
            "every possible joint configuration within a bounded action "
            "budget. Six authored 64x64 combinatorial puzzles."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="isos-c0000001",
        title="ISOS",
        family="iso_sketch",
        levels=6,
        engine="iso_sketch",
        description=(
            "Iso Sketch: construct an isometric voxel drawing by clicking "
            "visible faces, or erase visible cubes, until the cropped view "
            "matches the legend. Six authored 64x64 construction puzzles."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="sele-c0000001",
        title="SELE",
        family="selene",
        levels=6,
        engine="selene",
        description=(
            "Selene: rotate selected lunar relays and launch a laser through "
            "the complete sphere chain to the terminal target. Six authored "
            "64x64 analytical ray puzzles."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="rewi-c0000001",
        title="REWI",
        family="rewind",
        levels=6,
        engine="rewind",
        description=(
            "Rewind: scan a photographic film, observe its complete playback, "
            "and click the unique image region matching the target fragment. "
            "Six authored 64x64 visual-search puzzles."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="lkey-c0000001",
        title="LKEY",
        family="lock_and_key",
        levels=6,
        engine="lock_and_key",
        description=(
            "Lock & Key: swap keys between rows, apply each row's tool, "
            "and test the resulting teeth against the real locks. "
            "Six authored 64x64 puzzles with empty lock slots."
        ),
        default_fps=8,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="tequ-c0000001",
        title="TEQU",
        family="tower_equilibrium",
        levels=6,
        engine="tower_equilibrium",
        description=(
            "Tower Equilibrium: place beams of three lengths to connect both "
            "foundations to the target while keeping every supported structure "
            "stable. Six authored physics puzzles."
        ),
        default_fps=12,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="gmap-c0000001",
        title="GMAP",
        family="graved_map",
        levels=6,
        engine="graved_map",
        description=(
            "Graved Map: explore connected rooms, reveal the engraved map, "
            "collect keys automatically and enter matching doors from their "
            "keyed side. Six levels with a 30-move limit."
        ),
        default_fps=12,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="cgwl-c0000001",
        title="CGWL",
        family="cabbage_goat_wolf",
        levels=6,
        engine="cabbage_goat_wolf",
        description=(
            "Cabbage, Goat & Wolf: guide the shepherd and transport each "
            "passenger safely across the river, using the calming zone and "
            "colored reception slots. Six tutorial levels."
        ),
        default_fps=12,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="weav-c0000001",
        title="WEAV",
        family="weave",
        levels=6,
        engine="weave",
        description=(
            "Weave colored horizontal and vertical threads through a small "
            "grid to reproduce the visible target motif. Six authored levels."
        ),
        default_fps=12,
        wave="custom_2",
    ),
    CustomGameInfo(
        game_id="gril-c3000001",
        title="GRIL",
        family="grillage",
        levels=6,
        engine="grillage",
        description=(
            "Identify colored shapes behind a grille by translating them, "
            "then select their matching models within a shared movement budget."
        ),
        default_fps=8,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="dico-c3000001",
        title="DICO — Dichotomie, lampes en série",
        family="dichotomy",
        levels=6,
        engine="dichotomy",
        description=(
            "Locate a faulty lamp by testing and subdividing series circuits. "
            "Read the complete outage animation within the fixed test budget."
        ),
        default_fps=16,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="evas-c3000001",
        title="EVAS — Évasion, rondes de nuit",
        family="evasion",
        levels=6,
        engine="evasion",
        description=(
            "Reach the exit while avoiding guards and their moving light cones. "
            "Click a destination to walk or wait with ACTION5."
        ),
        default_fps=24,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="klot-c3000001",
        title="KLOT — Simple Klotski",
        family="simple_klotski",
        levels=6,
        engine="simple_klotski",
        description=(
            "Slide rigid pieces one cell at a time to bring the gold bar or L "
            "into its exit. Selection and movement each consume one action."
        ),
        default_fps=24,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="upst-c3000001",
        title="UPST — Upset",
        family="upset",
        levels=6,
        engine="upset",
        description=(
            "Open and close doors to reshape colored entities' routes and "
            "reactions until the red entity eats the violet boss."
        ),
        default_fps=60,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="ther-c3000001",
        title="THER — Thermomètres",
        family="thermometers",
        levels=6,
        engine="thermometers",
        description=(
            "Fill each thermometer continuously from its bulb until all "
            "row and column totals match the visible clues."
        ),
        default_fps=8,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="zipp-c3000001",
        title="ZIPP — Zip",
        family="zip",
        levels=6,
        engine="zip",
        description=(
            "Draw a path from the blue start through every cell exactly once, "
            "reaching the green exit last without crossing walls."
        ),
        default_fps=10,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="amze-c3000001",
        title="AMZE — Arrow Maze",
        family="arrow_maze",
        levels=6,
        engine="arrow_maze",
        description=(
            "Jump along the current arrow's ray to reach the goal within the "
            "click reserve. Legal destinations are highlighted in cyan."
        ),
        default_fps=24,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="pipe-c3000001",
        title="PIPE — Pipes",
        family="pipes",
        levels=6,
        engine="pipes",
        description=(
            "Rotate pipes to connect every cell to the source without leaks "
            "or cycles."
        ),
        default_fps=10,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="gigo-c3000001",
        title="Gigognes — du centre au bord",
        family="nested_rooms",
        levels=6,
        engine="nested_rooms",
        description="Move nested rooms and their descendants to open a path from the source to the outer exit.",
        default_fps=30,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="catl-c3000001",
        title="Caterpillar Logic",
        family="caterpillar_logic",
        levels=6,
        engine="caterpillar_logic",
        description="Infer the classification rule from examples and sort eight caterpillars into violet or orange.",
        default_fps=24,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="prtl-c3000001",
        title="Portails — chambres de transit",
        family="portal_chambers",
        levels=6,
        engine="portal_chambers",
        description="Place linked portals and move crates through chambers to reach the exit.",
        default_fps=24,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="moto-c3000001",
        title="Moto Orbit",
        family="moto_orbit",
        levels=6,
        engine="moto_orbit",
        description="Reposition turning posts, then launch an autonomous motorcycle run to reach the exit.",
        default_fps=20,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="onde-c3000001",
        title="Ondes — réglages et pellicule",
        family="wave_alignment",
        levels=6,
        engine="wave_alignment",
        description="Shift individual waves or the shared film to match every detector's target height.",
        default_fps=16,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="snar-c3000001",
        title="Sonar — les murs ont des jambes",
        family="sonar_maze",
        levels=6,
        engine="sonar_maze",
        description="Reveal hidden walls with sonar and navigate moving obstacles to reach the exit.",
        default_fps=20,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="trcp-c3000001",
        title="TRCP — Tracing Path",
        family="tracing_path",
        levels=6,
        engine="tracing_path",
        description="Excavate irreversible tunnels and route source pigments to their matching pockets within the tile budget.",
        default_fps=16,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="spor-c3000001",
        title="Spore Lab",
        family="spore_lab",
        levels=6,
        engine="spore_lab",
        description="Schedule biological production and deliver sufficiently fresh doses within the action budget.",
        default_fps=40,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="cwse-c3000001",
        title="Catching without seeing",
        family="catching_without_seeing",
        levels=6,
        engine="catching_without_seeing",
        description="Use an eight-direction lamp and coordinated crate pushes to fill target slots.",
        default_fps=12,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="cava-c3000001",
        title="Cavalier",
        family="knight_maze",
        levels=6,
        engine="knight_maze",
        description="Use knight jumps, seals, switches, portals and fragile cells to reach the goal.",
        default_fps=25,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="smlp-c3000001",
        title="Same Length Path — le même instant",
        family="same_length_path",
        levels=6,
        engine="same_length_path",
        description="Configure gates so every runner reaches the shared exit on the same tick.",
        default_fps=40,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="dame-c3000001",
        title="Dames",
        family="checkers_solitaire",
        levels=6,
        engine="checkers_solitaire",
        description="Select a piece and chain diagonal captures until the solitaire objective is satisfied.",
        default_fps=25,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="hpdl-c3000001",
        title="Homogeneous Pair Deletion — Le train des prises",
        family="homogeneous_pair_deletion",
        levels=6,
        engine="homogeneous_pair_deletion",
        description="Configure receiver capacities, color filters and outputs to process the cube train.",
        default_fps=20,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="catr-c3000001",
        title="Configured Attraction",
        family="configured_attraction",
        levels=6,
        engine="configured_attraction",
        description="Toggle attraction relations in the control panel to match the target arrangement.",
        default_fps=30,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="recr-c3000001",
        title="Recruit Army",
        family="recruit_army",
        levels=6,
        engine="recruit_army",
        description="Recruit an ordered squad between battles to clear successive enemy rooms.",
        default_fps=25,
        wave="custom_3",
    ),
    CustomGameInfo(
        game_id="rswp-c3000001",
        title="Role Swap — Trois ouvriers, un atelier",
        family="role_swap",
        levels=6,
        engine="role_swap",
        description="Configure three workers and execute shared workshop turns with role changes.",
        default_fps=20,
        wave="custom_3",
    ),
)


# Wave-2 game ids (dropdown label custom_2).
CUSTOM_2_GAME_IDS = frozenset(
    item.game_id for item in CUSTOM_GAMES if item.wave == "custom_2"
)


def is_custom_game_id(game_id: str) -> bool:
    return any(item.game_id == game_id for item in CUSTOM_GAMES)


def get_custom_game(game_id: str) -> CustomGameInfo | None:
    for item in CUSTOM_GAMES:
        if item.game_id == game_id:
            return item
    return None


def list_custom_game_infos() -> list[dict[str, Any]]:
    return [
        {
            "game_id": item.game_id,
            "title": item.title,
            "downloaded": True,
            "source_path": str(
                (
                    ROOT.parent / "api" / "standalone_game_api" / "engine" / "LS20_engine.py"
                    if item.engine == "ls19_legacy"
                    else ROOT / "games" / item.engine
                ).resolve()
            ),
            "tags": [
                item.wave if item.wave in ("custom", "custom_2", "custom_3") else "custom",
                *(["legacy"] if item.engine == "ls19_legacy" else []),
                item.family,
            ],
            "wave": item.wave,
            "family": item.family,
            "levels": item.levels,
            "description": item.description,
        }
        for item in CUSTOM_GAMES
    ]


def build_engine(game_id: str) -> Any:
    info = get_custom_game(game_id)
    if info is None:
        raise ValueError(f"unknown custom game: {game_id}")
    if info.engine == "ls19_legacy":
        from custom_games.engines.ls19_legacy import LS19LegacyEngine

        return LS19LegacyEngine(info)
    if info.engine == "sokoban":
        from custom_games.engines.sokoban import SokobanEngine

        return SokobanEngine(info)
    if info.engine == "color_glass":
        from custom_games.engines.color_glass import ColorGlassEngine

        return ColorGlassEngine(info)
    if info.engine == "switch_rooms":
        from custom_games.engines.switch_rooms import SwitchRoomsEngine

        return SwitchRoomsEngine(info)
    if info.engine == "stack_iso":
        from custom_games.engines.stack_iso import StackIsoEngine

        return StackIsoEngine(info)
    if info.engine == "hanoi":
        from custom_games.engines.hanoi import HanoiEngine

        return HanoiEngine(info)
    if info.engine == "seqn_groups":
        from custom_games.engines.seqn_groups import SeqnGroupsEngine

        return SeqnGroupsEngine(info)
    if info.engine == "mind_code":
        from custom_games.engines.mind_code import MindCodeEngine

        return MindCodeEngine(info)
    if info.engine == "memo_recall":
        from custom_games.engines.memo_recall import MemoRecallEngine

        return MemoRecallEngine(info)
    if info.engine == "reign_gauges":
        from custom_games.engines.reign_gauges import ReignGaugesEngine

        return ReignGaugesEngine(info)
    if info.engine == "connect_four":
        from custom_games.engines.connect_four import ConnectFourEngine

        return ConnectFourEngine(info)
    if info.engine == "denoise_trame":
        from custom_games.engines.denoise_trame import DenoiseTrameEngine

        return DenoiseTrameEngine(info)
    if info.engine == "symmetry_fix":
        from custom_games.engines.symmetry_fix import SymmetryFixEngine

        return SymmetryFixEngine(info)
    if info.engine == "gori_ballistics":
        from custom_games.engines.gori_ballistics import GoriBallisticsEngine

        return GoriBallisticsEngine(info)
    if info.engine == "key_doors":
        from custom_games.engines.key_doors import KeyDoorsEngine

        return KeyDoorsEngine(info)
    if info.engine == "logic_circuit":
        from custom_games.engines.logic_circuit import LogicCircuitEngine

        return LogicCircuitEngine(info)
    if info.engine == "portal_topology":
        from custom_games.engines.portal_topology import PortalTopologyEngine

        return PortalTopologyEngine(info)
    if info.engine == "fog_hidden_motion":
        from custom_games.engines.fog_hidden_motion import FogHiddenMotionEngine

        return FogHiddenMotionEngine(info)
    if info.engine == "life_lineage":
        from custom_games.engines.life_lineage import LifeLineageEngine

        return LifeLineageEngine(info)
    if info.engine == "valve_flow":
        from custom_games.engines.valve_flow import ValveFlowEngine

        return ValveFlowEngine(info)
    if info.engine == "signal_seal":
        from custom_games.engines.signal_seal import SignalSealEngine

        return SignalSealEngine(info)
    if info.engine == "cascade_quiesce":
        from custom_games.engines.cascade_quiesce import CascadeQuiesceEngine

        return CascadeQuiesceEngine(info)
    if info.engine == "craft_console":
        from custom_games.engines.craft_console import CraftConsoleEngine

        return CraftConsoleEngine(info)
    if info.engine == "escort_patrol":
        from custom_games.engines.escort_patrol import EscortPatrolEngine

        return EscortPatrolEngine(info)
    if info.engine == "fite_arena":
        from custom_games.engines.fite_arena import FiteArenaEngine

        return FiteArenaEngine(info)
    if info.engine == "always_sliding":
        from custom_games.engines.always_sliding import AlwaysSlidingEngine

        return AlwaysSlidingEngine(info)
    if info.engine == "gare_cadence":
        from custom_games.engines.gare_cadence import GareCadenceEngine

        return GareCadenceEngine(info)
    if info.engine == "columns_match":
        from custom_games.engines.columns_match import ColumnsMatchEngine

        return ColumnsMatchEngine(info)
    if info.engine == "transport_gabarit":
        from custom_games.engines.transport_gabarit import TransportGabaritEngine

        return TransportGabaritEngine(info)
    if info.engine == "flee_stones":
        from custom_games.engines.flee_stones import FleeStonesEngine

        return FleeStonesEngine(info)
    if info.engine == "etag_floors":
        from custom_games.engines.etag_floors import EtagFloorsEngine

        return EtagFloorsEngine(info)
    if info.engine == "tic_tac_toe":
        from custom_games.engines.tic_tac_toe import TicTacToeEngine

        return TicTacToeEngine(info)
    if info.engine == "globe_track":
        from custom_games.engines.globe_track import GlobeTrackEngine

        return GlobeTrackEngine(info)
    if info.engine == "katamino":
        from custom_games.engines.katamino import KataminoEngine

        return KataminoEngine(info)
    if info.engine == "hole_palette":
        from custom_games.engines.hole_palette import HolePaletteEngine

        return HolePaletteEngine(info)
    if info.engine == "gravity_box":
        from custom_games.engines.gravity_box import GravityBoxEngine

        return GravityBoxEngine(info)
    if info.engine == "neighbor_cubes":
        from custom_games.engines.neighbor_cubes import NeighborCubesEngine

        return NeighborCubesEngine(info)
    if info.engine == "polarity":
        from custom_games.engines.polarity import PolarityEngine

        return PolarityEngine(info)
    if info.engine == "elastic_grid":
        from custom_games.engines.elastic_grid import ElasticGridEngine

        return ElasticGridEngine(info)
    if info.engine == "triade":
        from custom_games.engines.triade import TriadeEngine

        return TriadeEngine(info)
    if info.engine == "sequence_lab":
        from custom_games.engines.sequence_lab import SequenceLabEngine

        return SequenceLabEngine(info)
    if info.engine == "combina":
        from custom_games.engines.combina import CombinaEngine

        return CombinaEngine(info)
    if info.engine == "iso_sketch":
        from custom_games.engines.iso_sketch import IsoSketchEngine

        return IsoSketchEngine(info)
    if info.engine == "selene":
        from custom_games.engines.selene import SeleneEngine

        return SeleneEngine(info)
    if info.engine == "rewind":
        from custom_games.engines.rewind import RewindEngine

        return RewindEngine(info)
    if info.engine == "lock_and_key":
        from custom_games.engines.lock_and_key import LockAndKeyEngine

        return LockAndKeyEngine(info)
    if info.engine == "tower_equilibrium":
        from custom_games.engines.tower_equilibrium import TowerEquilibriumEngine

        return TowerEquilibriumEngine(info)
    if info.engine == "graved_map":
        from custom_games.engines.graved_map import GravedMapEngine

        return GravedMapEngine(info)
    if info.engine == "cabbage_goat_wolf":
        from custom_games.engines.cabbage_goat_wolf import CabbageGoatWolfEngine

        return CabbageGoatWolfEngine(info)
    if info.engine == "weave":
        from custom_games.engines.weave import WeaveEngine

        return WeaveEngine(info)
    if info.engine == "grillage":
        from custom_games.engines.grillage import GrillageEngine

        return GrillageEngine(info)
    if info.engine == "dichotomy":
        from custom_games.engines.dichotomy import DichotomyEngine

        return DichotomyEngine(info)
    if info.engine == "evasion":
        from custom_games.engines.evasion import EvasionEngine

        return EvasionEngine(info)
    if info.engine == "simple_klotski":
        from custom_games.engines.simple_klotski import HostedKlotskiEngine

        return HostedKlotskiEngine(info)
    if info.engine == "upset":
        from custom_games.engines.upset import UpsetEngine

        return UpsetEngine(info, animation_frame_reduction=5)
    if info.engine == "thermometers":
        from custom_games.engines.thermometers import ThermometersEngine

        return ThermometersEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "zip":
        from custom_games.engines.zip import ZipEngine

        return ZipEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "arrow_maze":
        from custom_games.engines.arrow_maze import ArrowMazeEngine

        return ArrowMazeEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "pipes":
        from custom_games.engines.pipes import PipesEngine

        return PipesEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "nested_rooms":
        from custom_games.engines.nested_rooms import NestedRoomsEngine

        return NestedRoomsEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "caterpillar_logic":
        from custom_games.engines.caterpillar_logic import CaterpillarLogicEngine

        return CaterpillarLogicEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "portal_chambers":
        from custom_games.engines.portal_chambers import PortalChambersEngine

        return PortalChambersEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "moto_orbit":
        from custom_games.engines.moto_orbit import MotoOrbitEngine

        return MotoOrbitEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "wave_alignment":
        from custom_games.engines.wave_alignment import WaveAlignmentEngine

        return WaveAlignmentEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "sonar_maze":
        from custom_games.engines.sonar_maze import SonarMazeEngine

        return SonarMazeEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "tracing_path":
        from custom_games.engines.tracing_path import TracingPathEngine

        return TracingPathEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "spore_lab":
        from custom_games.engines.spore_lab import SporeLabEngine

        return SporeLabEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "catching_without_seeing":
        from custom_games.engines.catching_without_seeing import CatchingWithoutSeeingEngine

        return CatchingWithoutSeeingEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "knight_maze":
        from custom_games.engines.knight_maze import KnightMazeEngine

        return KnightMazeEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "same_length_path":
        from custom_games.engines.same_length_path import SameLengthPathEngine

        return SameLengthPathEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "checkers_solitaire":
        from custom_games.engines.checkers_solitaire import CheckersSolitaireEngine

        return CheckersSolitaireEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "homogeneous_pair_deletion":
        from custom_games.engines.homogeneous_pair_deletion import HomogeneousPairDeletionEngine

        return HomogeneousPairDeletionEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    if info.engine == "configured_attraction":
        from custom_games.engines.configured_attraction import ConfiguredAttractionEngine

        engine = ConfiguredAttractionEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
        # The standalone engine retains game_id/title but does not expose info.
        # The host catalogue uses this registered identity after game selection.
        engine.info = info
        return engine
    if info.engine == "recruit_army":
        from custom_games.engines.recruit_army import RecruitArmyEngine

        engine = RecruitArmyEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
        engine.info = info  # Registered identity expected by the host catalogue.
        return engine
    if info.engine == "role_swap":
        from custom_games.engines.role_swap import RoleSwapEngine

        return RoleSwapEngine(info, levels_dir=ROOT / "games" / info.engine / "levels")
    raise ValueError(f"unsupported custom engine: {info.engine}")


def build_seeded_engine(game_id: str, *, instance_seed: int) -> Any:
    """Construct a custom episode under its declared reproducible seed."""

    previous_seed = os.environ.get("KEYD_EPISODE_SEED")
    try:
        os.environ["KEYD_EPISODE_SEED"] = str(int(instance_seed))
        return build_engine(game_id)
    finally:
        if previous_seed is None:
            os.environ.pop("KEYD_EPISODE_SEED", None)
        else:
            os.environ["KEYD_EPISODE_SEED"] = previous_seed
