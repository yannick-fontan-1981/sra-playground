import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import test from 'node:test';
import { FramedTransfer } from '../src/logos-engine/v6-framed-transfer.ts';
import { candidates } from '../src/logos-engine/v6-framed-transfer-observation.ts';
import { measureCurrentUniformReceptionQuestions, UNIFORM_RECEPTION_QUESTION_CONTRACT } from '../src/logos-engine/v6-framed-uniform-questions.ts';
import { measureNativeObservation } from '../src/logos-engine/v6-native-observer.ts';

const root = new URL('../', import.meta.url);
const read = (path: string) => readFileSync(new URL(path, root));
// Frozen actual returns from the earlier failed campaign. No host is accessed.
const directory = 'docs/migration/native-campaigns-v52/';
const campaign = JSON.parse(read(`${directory}gare-three-levels.json`).toString());
const trace = JSON.parse(gunzipSync(read(`${directory}gare-public-trace.json.gz`)).toString());
const proposal = campaign.prefixes[16].framedTransfer.proposal;
const session = proposal.binding.observation_ref.split(':epoch:')[0];
const first = trace.packets[16].packet, final = trace.packets[17].packet, command = trace.packets[17].command;
const before = await measureNativeObservation(first, 17, session), after = await measureNativeObservation(final, 18, session);
const options = { currentPointWitnessBinding: true, currentPublicPacketReceptions: true, currentUniformReceptionQuestions: true };
const acquired = await FramedTransfer.create(options); acquired.restore(campaign.prefixes[15].framedAcquisition.sourceState);
await acquired.recordPublicTransition(before, after, command, first.frame_rows, final.frame_rows, proposal, 0, final.frame_packet);
const checkpoint = acquired.nativeState();

async function currentFamily() {
  const family = await FramedTransfer.create(options); family.restoreNative(checkpoint); return family;
}

test('a current source point tests the missing reception prerequisite without claiming its unknown offset', async () => {
  const family = await currentFamily(), state = family.nativeState(), revision = family.nativeRevision;
  const strict = await FramedTransfer.create({ currentPointWitnessBinding: true, currentPublicPacketReceptions: true }); strict.restoreNative(checkpoint);
  const original = await strict.propose(after, final.frame_rows, [], 100);
  const result = await family.propose(after, final.frame_rows, [], 100);
  assert.ok(original); assert.ok(result);
  assert.deepEqual(original.actions, [{ action_ref: 'ACTION6', data: { x: 9, y: 13 } }]);
  assert.deepEqual(result.actions, [{ action_ref: 'ACTION6', data: { x: 51, y: 43 } }]);
  const plan = result.framed_transfer_plan, coordination = plan.native_uniform_reception_question!;
  assert.equal(coordination.question.kind, 'calibration_dependency');
  assert.equal(coordination.question.tasks.length, 2); assert.equal(coordination.current_reception_offer_count, 0);
  assert.equal(coordination.current_calibration_offer_count, 1); assert.equal(coordination.original_physical_candidate, true);
  assert.deepEqual(coordination.source_choice, original.framed_transfer_plan.choice);
  assert.deepEqual(coordination.source_selected_point, [9, 13]); assert.deepEqual(coordination.selected_point, [51, 43]);
  assert.equal(coordination.control_offset_status, 'unknown_until_actual_return');
  assert.equal(coordination.expected_effect_status, 'unknown'); assert.equal(coordination.release_authority, false);
  assert.equal(plan.choice.projection_ref, 'projection.exploration.parallel_solid_band_interface_question');
  assert.notEqual(plan.offer.facts.framed_reception_locus_binding_count, 1);
  assert.equal(plan.offer.facts.candidate_execution_count, 0); assert.equal(result.steps[0]!.expected_after, null);
  const sourceOffers = await candidates(final.frame_rows, after, family.policy, family.spans,
    [...family.receipts, ...family.publicPacketReceptionState().receipts], family.attempts);
  const exact = sourceOffers.filter(offer => offer.candidate_ref === plan.offer.candidate_ref && offer.component_ref === plan.offer.component_ref);
  assert.equal(exact.length, 1); const { native_uniform_reception_question: _native, ...plain } = plan.offer;
  assert.deepEqual(plain, exact[0]);
  for (const task of coordination.question.tasks) {
    assert.equal(task.prototype_status, 'missing_for_required_side_and_current_value');
    assert.equal(task.orientation_preserved, true); assert.equal(task.isometry_applied, false); assert.equal(task.palette_mapping_applied, false);
    assert.equal(task.pending_alignment_is_not_an_action_plan, true); assert.deepEqual(task.prototype_claim_refs, []);
  }
  const sourceGuard = await family.beforeSource(result, 0, final, after), guard = await family.before(result, 0, final, after);
  assert.equal(sourceGuard.admitted, true); assert.equal(guard.admitted, true);
  assert.equal(guard.native_binding_receipt!.rule, 'native.current_uniform_reception_dependency');
  assert.deepEqual(guard.native_binding_receipt!.source_guard, sourceGuard);
  assert.deepEqual(guard.native_binding_receipt!.current_coordination, coordination);
  assert.equal(guard.native_binding_receipt!.expected_effect_status, 'unknown');
  assert.equal(family.nativeRevision, revision); assert.equal(family.nativeState(), state);
});

test('coordination is mandatory even when the source guard recognizes the physical point', async () => {
  const family = await currentFamily(), result = await family.propose(after, final.frame_rows, [], 100); assert.ok(result);
  for (const alter of [
    (changed: any) => { delete changed.framed_transfer_plan.native_uniform_reception_question; },
    (changed: any) => { changed.framed_transfer_plan.native_uniform_reception_question.question.tasks[0].alignment_delta++; },
    (changed: any) => { changed.framed_transfer_plan.native_uniform_reception_question.source_selected_point[0]++; },
    (changed: any) => { changed.steps[0].point_binding.point[0]++; },
    (changed: any) => { changed.framed_transfer_plan.offer.facts.candidate_execution_count++; },
  ]) {
    const changed = structuredClone(result); alter(changed);
    const guard = await family.before(changed, 0, final, after); assert.equal(guard.admitted, false); assert.ok(guard.native_binding_receipt);
  }
  assert.equal((await family.before(result, 0, final, { ...after, available_action_refs: [] })).admitted, false);
  assert.equal((await family.before(result, 0, final, { ...after, level_epoch: after.level_epoch + 1 })).admitted, false);
});

test('an acquired current-context attempt removes the prerequisite question without changing learned mechanics', async () => {
  const family = await currentFamily(), result = await family.propose(after, final.frame_rows, [], 100); assert.ok(result);
  const state = structuredClone(family.nativeState()) as any;
  state.source_state.attempts[result.framed_transfer_plan.offer.candidate_ref] = {
    evidence: [after.observation_ref, 'unit-test:actual-return'], unchanged: true,
  };
  family.restoreNative(state); const retained = family.nativeState(), revision = family.nativeRevision;
  const next = await family.propose(after, final.frame_rows, [], 100);
  assert.notEqual(next?.framed_transfer_plan.offer.candidate_ref, result.framed_transfer_plan.offer.candidate_ref);
  assert.equal((await family.before(result, 0, final, after)).admitted, false);
  assert.equal(family.nativeState(), retained); assert.equal(family.nativeRevision, revision);
  assert.deepEqual(family.spans, state.source_state.spans);
  assert.deepEqual(family.publicPacketReceptionState().receipts, state.public_packet_receptions.receipts);
});

test('receipt scope, literal gap, direction and current source offer must all remain witnessed', async () => {
  const family = await currentFamily(), receipts = family.publicPacketReceptionState().receipts;
  const offers = await candidates(final.frame_rows, after, family.policy, family.spans, receipts, family.attempts);
  const measure = (currentReceipts: readonly any[], currentOffers = offers, attempts = family.attempts) =>
    measureCurrentUniformReceptionQuestions(final.frame_rows, after, family.policy, family.spans, currentReceipts, attempts, currentOffers);
  const valid = await measure(receipts); assert.equal(valid.complete, true); assert.equal(valid.calibrationOffers.length, 1);
  const stale = structuredClone(receipts), reversed = structuredClone(receipts), gapChanged = structuredClone(receipts);
  for (const record of stale) record.context_epoch--;
  for (const record of reversed) [record.source_frame_bbox, record.marker_frame_bbox] = [record.marker_frame_bbox, record.source_frame_bbox];
  for (const record of gapChanged) for (const patch of record.gap_patches) patch[2][0][0] = (patch[2][0][0] + 1) % 256;
  const candidate = valid.calibrationOffers[0]!;
  const staleOffers = structuredClone(offers);
  for (const offer of staleOffers) if (offer.candidate_ref === candidate.candidate_ref) offer.signature = 'stale-public-support';
  for (const sample of [
    await measure([]), await measure(stale), await measure(reversed), await measure(gapChanged), await measure(receipts, staleOffers),
    await measure(receipts, offers, { [candidate.candidate_ref]: { unchanged: false, evidence: [after.observation_ref, 'unit-test:changed-return'] } }),
  ]) {
    assert.equal(sample.complete, true); assert.deepEqual(sample.receptionOffers, []); assert.deepEqual(sample.calibrationOffers, []);
  }
});

test('a bounded measurement refuses the whole native domain rather than a partial question prefix', async () => {
  const family = await currentFamily(), receipts = family.publicPacketReceptionState().receipts;
  const offers = await candidates(final.frame_rows, after, family.policy, family.spans, receipts, family.attempts);
  const limited = { ...family.policy, route: { ...family.policy.route,
    framed_reception_locus_contract: { ...family.policy.route.framed_reception_locus_contract, maximum_tasks: 1 } } };
  const tasks = await measureCurrentUniformReceptionQuestions(final.frame_rows, after, limited, family.spans, receipts, family.attempts, offers);
  assert.equal(tasks.complete, false); assert.equal(tasks.reason, 'uniform_question_task_bound');
  assert.deepEqual(tasks.receptionOffers, []); assert.deepEqual(tasks.calibrationOffers, []);
  const inventory = await measureCurrentUniformReceptionQuestions(final.frame_rows, after, family.policy, family.spans, receipts, family.attempts,
    Array.from({ length: UNIFORM_RECEPTION_QUESTION_CONTRACT.maximum_existing_offers + 1 }, () => offers[0]!));
  assert.equal(inventory.complete, false); assert.equal(inventory.reason, 'uniform_question_inventory_bound');
  assert.equal(inventory.work_count, 0); assert.deepEqual(inventory.receptionOffers, []); assert.deepEqual(inventory.calibrationOffers, []);
});
