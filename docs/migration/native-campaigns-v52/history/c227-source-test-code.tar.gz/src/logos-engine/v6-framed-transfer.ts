/**
 * Standalone FramedTransfer owner from pinned V6 framed_transfer/family.py.
 * propose and analogy share this one memory. Actual public point returns from
 * any selected family can enter recordSource; portable records never authorize
 * a command in a new epoch without current geometric revalidation.
 */
import { FramedPolicy } from './v6-framed-transfer-policy.ts';
import { candidates, transition } from './v6-framed-transfer-observation.ts';
import type { FramedOffer } from './v6-framed-transfer-observation.ts';
import { retainNativeJson } from './v6-native-owned.ts';
import { isJsonObject } from './canonical.ts';
import { pythonEqual as equal, pythonTruthy as truth } from './v6-operations.ts';
import type { ObservedInputDomain } from './v6-native-observer.ts';
import type { NativeAfterResult, NativeBeforeResult, NativeCommand, NativeExecution, NativeFamily,
  NativeObservation, NativeProgramRegistry, NativeProposal, NativePublicObservation, NativeRecord,
  NativeRecordResult, NativeRows } from './v6-native-types.ts';

type R = Record<string, any>;
const FIELDS = ['epoch', 'spans', 'receipts', 'attempts', 'portable', 'last'] as const;
const NATIVE_FORMAT = 'native.public_framed_transfer.v1';
const NATIVE_SRC_ANNOTATIONS = new Set(['all_executed_statements', 'instruction_quantum', 'instructions', 'trace',
  'execution_engine', 'reference_commit', 'reference_semantic_hash', 'native_execution_hash', 'source_definition_hash', 'edited']);
const sourceRecordViews = new WeakMap<object, R>();

/**
 * Source record equality sees its four SRC receipt fields. Exclude only the ten
 * native annotations at this exact path, so an original source checkpoint and
 * the same real native return deduplicate. Unknown fields remain significant;
 * the complete native record is still retained for graph execution evidence.
 */
function sourceRecordView(record: R): R {
  const known = sourceRecordViews.get(record); if (known) return known;
  const derivation = record.derivation;
  if (!isJsonObject(derivation) || !isJsonObject(derivation.workflow)) return record;
  const workflow = Object.fromEntries(Object.entries(derivation.workflow).filter(([key]) => !NATIVE_SRC_ANNOTATIONS.has(key)));
  const result = { ...record, derivation: { ...derivation, workflow } };
  // Only owned immutable records enter this comparison in acquisition.
  sourceRecordViews.set(record, result); return result;
}

export interface NativeFramedTransferOptions {
  /** Native current-witness disambiguation after the exact source guard refuses. */
  readonly currentPointWitnessBinding?: boolean;
}

/** Current native bindings distinguish booleans from measured coordinates. */
function samePublicValue(left: unknown, right: unknown): boolean {
  if (left === right) return true;
  if (Array.isArray(left) || Array.isArray(right)) return Array.isArray(left) && Array.isArray(right)
    && left.length === right.length && left.every((value, index) => samePublicValue(value, right[index]));
  if (!isJsonObject(left) || !isJsonObject(right)) return false;
  return Object.keys(left).length === Object.keys(right).length
    && Object.keys(left).every(key => Object.hasOwn(right, key) && samePublicValue(left[key], right[key]));
}

export interface FramedState extends R {
  readonly epoch: number | null;
  readonly spans: readonly R[];
  readonly receipts: readonly R[];
  readonly attempts: Readonly<Record<string, R>>;
  readonly portable: readonly R[];
  readonly last: R | null;
}
export interface FramedProposal extends NativeProposal {
  readonly kind: 'public_framed_transfer';
  readonly actions: readonly NativeCommand[];
  readonly steps: readonly R[];
  readonly binding: R;
  readonly framed_transfer_plan: { readonly offer: FramedOffer; readonly choice: R; readonly workflow: R; readonly drm_hash: string };
}

/** Shape validation is atomic; mutable caller-owned objects are never retained. */
function ownedState(value: R): FramedState {
  const owned = retainNativeJson(value);
  if (Object.keys(owned).length !== FIELDS.length || FIELDS.some(field => !Object.hasOwn(owned, field))
    || owned.epoch !== null && !Number.isSafeInteger(owned.epoch)
    || !Array.isArray(owned.spans) || !owned.spans.every(isJsonObject)
    || !Array.isArray(owned.receipts) || !owned.receipts.every(isJsonObject)
    || !isJsonObject(owned.attempts) || !Object.values(owned.attempts).every(isJsonObject)
    || !Array.isArray(owned.portable) || !owned.portable.every(isJsonObject)
    || owned.last !== null && !isJsonObject(owned.last)) throw new TypeError('Incompatible framed-transfer source state');
  for (const item of owned.portable as R[]) {
    if (item.authority !== 'historical_not_current_permit' || item.source_epoch !== null && !Number.isSafeInteger(item.source_epoch)
      || !Array.isArray(item.spans) || !item.spans.every(isJsonObject)
      || !Array.isArray(item.receipts) || !item.receipts.every(isJsonObject)) throw new TypeError('Invalid historical framed records');
  }
  return owned as FramedState;
}

export class FramedTransfer implements NativeFamily<FramedProposal> {
  readonly id = 'public_framed_transfer';
  readonly policy: FramedPolicy;
  private current: FramedState = ownedState({ epoch: null, spans: [], receipts: [], attempts: {}, portable: [], last: null });
  private version = 0;
  private checkpoint: NativeRecord | null = null;
  private readonly currentPointWitnessBinding: boolean;
  private constructor(policy: FramedPolicy, options: NativeFramedTransferOptions = {}) {
    this.policy = policy; this.currentPointWitnessBinding = options.currentPointWitnessBinding === true;
  }

  static async create(options: NativeFramedTransferOptions = {}): Promise<FramedTransfer> {
    return new FramedTransfer(await FramedPolicy.create(), options);
  }
  async attachPrograms(registry: NativeProgramRegistry): Promise<void> { await this.policy.attachPrograms(registry); }
  get nativeRevision(): number { return this.version; }
  get epoch(): number | null { return this.current.epoch; }
  get spans(): readonly R[] { return this.current.spans; }
  get receipts(): readonly R[] { return this.current.receipts; }
  get attempts(): Readonly<Record<string, R>> { return this.current.attempts; }
  get portable(): readonly R[] { return this.current.portable; }
  get last(): R | null { return this.current.last; }

  private commit(value: R): void {
    const next = ownedState(value);
    if (next === this.current) return;
    this.current = next; this.version++; this.checkpoint = null;
  }

  /** Exactly the six original source fields, returned as independent JSON. */
  state(): FramedState { return structuredClone(this.current); }

  /** Native graph checkpoints share only validated, deeply immutable branches. */
  nativeState(): NativeRecord {
    this.checkpoint ??= retainNativeJson({ format: NATIVE_FORMAT, source_state: this.current });
    return this.checkpoint;
  }

  /** Preserve source partial-restore semantics, validating the merged value first. */
  restore(state: NativeRecord): void {
    const supplied = retainNativeJson(state);
    if (!isJsonObject(supplied)) throw new TypeError('Framed restore requires a source state mapping');
    const merged: R = { ...this.current };
    for (const key of FIELDS) if (Object.hasOwn(supplied, key)) merged[key] = supplied[key];
    this.commit(merged);
  }

  restoreNative(state: Readonly<NativeRecord>): void {
    if (state === this.checkpoint) return;
    const supplied = retainNativeJson(state);
    if (!isJsonObject(supplied) || supplied.format !== NATIVE_FORMAT || !isJsonObject(supplied.source_state)
      || Object.keys(supplied).length !== 2) throw new TypeError('Incompatible native framed-transfer checkpoint');
    const next = ownedState(supplied.source_state);
    this.commit(next);
    this.checkpoint = supplied;
  }

  scope(observation: Pick<NativeObservation, 'level_epoch'>): void {
    if (this.epoch === observation.level_epoch) return;
    const portable = this.spans.length || this.receipts.length
      ? [...this.portable, { source_epoch: this.epoch, spans: this.spans, receipts: this.receipts, authority: 'historical_not_current_permit' }]
      : this.portable;
    this.commit({ epoch: observation.level_epoch, spans: [], receipts: [], attempts: {}, portable, last: null });
  }

  async propose(observation: NativeObservation, rows: NativeRows, _inputs: readonly NativeCommand[], remaining: number,
    _execution?: NativeExecution): Promise<FramedProposal | null> {
    this.scope(observation);
    const actionRef = this.policy.config.point_action as string;
    if (remaining < 1 || !observation.available_action_refs.includes(actionRef)) return null;
    const offers = await candidates(rows, observation, this.policy, this.spans, this.receipts, this.attempts);
    if (!offers.length) return null;
    const [choice, workflow] = await this.policy.choose(offers);
    if (choice.status !== 'selected') return null;
    const selected = offers[choice.index]!;
    const action: NativeCommand = { action_ref: actionRef, data: { x: selected.point_x, y: selected.point_y } };
    const facts = { framed_interface_current: true };
    const evidence = [observation.observation_ref, ...(choice.projected.premise_claim_refs ?? [])];
    const focus = `composition:framed:${selected.candidate_ref}`;
    const purpose = Object.hasOwn(choice.projected, 'subgoal_ref') ? choice.projected.subgoal_ref : 'test_current_framed_relation';
    const pointBinding = { observation_ref: observation.observation_ref, entity_ref: selected.component_ref,
      signature: selected.signature, bbox: selected.bbox, level_epoch: observation.level_epoch, frame_hash: observation.frame_hash,
      point: [selected.point_x, selected.point_y], palette_value: selected.point_value, source: 'measured_parallel_support_pair' };
    return {
      status: 'proposed', kind: 'public_framed_transfer', actions: [action],
      steps: [{ action, expected_after: null, point_binding: pointBinding }], facts,
      binding: { observation_ref: observation.observation_ref, level_epoch: observation.level_epoch,
        frame_hash: observation.frame_hash, levels_completed: observation.levels_completed },
      framed_transfer_plan: { offer: selected, choice, workflow, drm_hash: this.policy.loaded.source_hash },
      compositions: [{ id: focus, role: 'conditional_framed_relation', observed: false, things: [selected.component_ref],
        properties: { current_measurement: selected.facts, projected: choice.projected,
          unknown: ['control_effect', 'interior_rigidity', 'cargo_role', 'terminal_role'], portable_records_not_current: this.portable.length },
        relations: [`contributes_to:${this.policy.config.goal}`], open_question: purpose }],
      question: { reason: purpose, hypothesis_refs: [choice.projection_ref] }, route_refs: evidence,
      bundle_template: { operation_key: 'OP18', composition_ref: focus, objective_ref: this.policy.config.goal,
        purpose, preconditions: facts, evidence, actions: [action], preserve_refs: [], preservation_evidence: {},
        outcome_guard: { path: ['value'], contains: focus } },
    };
  }

  async analogy(observation: NativeObservation, rows: NativeRows, inputs: readonly NativeCommand[], remaining: number,
    execution?: NativeExecution): Promise<FramedProposal | null> {
    const proposal = await this.propose(observation, rows, inputs, remaining, execution);
    if (proposal) {
      const choice = proposal.framed_transfer_plan.choice;
      const conditions = this.policy.config.early_continuation_by_projection[choice.projection_ref];
      if (truth(conditions) && this.policy.holds(conditions, choice.projected)) return proposal;
    }
    return null;
  }

  /** Two ordered caller entries retain one epoch, one history and one last return. */
  async proposeInSubquestion(group: string, subquestion: string, observation: NativeObservation, rows: NativeRows,
    inputs: readonly NativeCommand[], remaining: number, execution?: NativeExecution): Promise<FramedProposal | null> {
    if (group === 'factored_material_return' && subquestion === 'observed_framed_transfer') {
      const proposal = await this.propose(observation, rows, inputs, remaining, execution);
      return proposal === null ? null : { ...proposal, material_access_subquestion: subquestion };
    }
    if (group === 'window_constraints' && subquestion === 'observed_framed_analogy') {
      const proposal = await this.analogy(observation, rows, inputs, remaining, execution);
      return proposal === null ? null : { ...proposal, field_subquestion: subquestion };
    }
    return null;
  }

  bind(proposal: FramedProposal, _preserve?: ObservedInputDomain | null): void {
    if (proposal.actions.length !== 1 || !equal(proposal.actions, proposal.steps.map(step => step.action ?? null))) {
      throw new TypeError('framed action set changed');
    }
  }

  /** Unchanged source guard, including refusal of multiple equal descriptions. */
  async beforeSource(proposal: FramedProposal, index: number, publicPacket: NativePublicObservation,
    observation: NativeObservation): Promise<NativeBeforeResult> {
    if (index !== 0 || ['observation_ref', 'level_epoch', 'frame_hash'].some(key => !equal(observation[key], proposal.binding[key]))) {
      return { admitted: false, reason: 'scope_or_observation_changed' };
    }
    this.bind(proposal, null);
    const offer = proposal.framed_transfer_plan.offer, action = proposal.actions[0]!;
    if (!equal(action, { action_ref: this.policy.config.point_action, data: { x: offer.point_x, y: offer.point_y } })) {
      return { admitted: false, reason: 'payload_changed' };
    }
    const current = await candidates(publicPacket.frame_rows, observation, this.policy, this.spans, this.receipts, {});
    const matches = current.filter(row => row.candidate_ref === offer.candidate_ref && equal(row.patches, offer.patches));
    return { admitted: matches.length === 1 && observation.available_action_refs.includes(action.action_ref),
      reason: 'current_parallel_support_and_payload' };
  }

  /**
   * The default remains the source guard. The opt-in extension only resolves
   * multiple current descriptions of one physical point by the proposal's
   * already selected, uniquely present component witness. It changes neither
   * offer selection nor acquired mechanics and makes no prediction of effect.
   */
  async before(proposal: FramedProposal, index: number, publicPacket: NativePublicObservation,
    observation: NativeObservation): Promise<NativeBeforeResult & { native_binding_receipt?: R }> {
    const source = await this.beforeSource(proposal, index, publicPacket, observation);
    if (source.admitted || !this.currentPointWitnessBinding || source.reason !== 'current_parallel_support_and_payload') return source;
    const action = proposal.actions[0]!;
    if (!observation.available_action_refs.includes(action.action_ref)) return source;
    const offer = proposal.framed_transfer_plan.offer;
    const current = await candidates(publicPacket.frame_rows, observation, this.policy, this.spans, this.receipts, {});
    const matches = current.filter(row => row.candidate_ref === offer.candidate_ref && equal(row.patches, offer.patches));
    if (matches.length <= 1) return source;

    const fields = ['candidate_ref', 'patches', 'point', 'point_x', 'point_y', 'point_value', 'bbox', 'signature'] as const;
    const samePhysicalPoint = matches.every(row => fields.every(field => samePublicValue(row[field], offer[field])))
      && samePublicValue(offer.point, [offer.point_y, offer.point_x]);
    const selected = matches.filter(row => row.component_ref === offer.component_ref);
    const binding = proposal.steps[0]?.point_binding;
    const pointBindingCurrent = isJsonObject(binding)
      && binding.entity_ref === offer.component_ref && binding.signature === offer.signature
      && samePublicValue(binding.bbox, offer.bbox) && samePublicValue(binding.point, [offer.point_x, offer.point_y])
      && binding.palette_value === offer.point_value && binding.observation_ref === observation.observation_ref
      && binding.level_epoch === observation.level_epoch && binding.frame_hash === observation.frame_hash;
    const admitted = samePhysicalPoint && selected.length === 1 && pointBindingCurrent;
    return { admitted, reason: admitted ? 'native_current_framed_point_witness_bound' : 'native_current_framed_point_witness_not_bound',
      native_binding_receipt: {
        schema: 'logos-engine.native.current-point-binding.v1', rule: 'native.current_framed_point_witness',
        source_guard: source, observation_ref: observation.observation_ref, level_epoch: observation.level_epoch,
        frame_hash: observation.frame_hash, current_description_count: matches.length,
        current_component_refs: matches.map(row => row.component_ref), selected_component_ref: offer.component_ref,
        selected_current_bindings: selected.length, same_physical_point: samePhysicalPoint,
        point_binding_current: pointBindingCurrent, physical_command: action,
        release_authority: false, expected_effect_status: 'unknown',
        qualification: 'current_public_binding_only_no_effect_claim',
      } };
  }

  after(_proposal: FramedProposal, _index: number, _before: NativeObservation, _after: NativeObservation,
    _first: NativeRows, _second: NativeRows): NativeAfterResult & { preservation_matched: null } {
    return { matched: null, preservation_matched: null, seal_prefix: true,
      reason: 'reconcile_complete_point_transition_without_assumed_mechanics' };
  }

  /** Exact source return, including null for an irrelevant public transition. */
  async recordSource(before: NativeObservation, after: NativeObservation, command: NativeCommand,
    first: NativeRows, second: NativeRows, proposal: NativeProposal | null = null, _index = 0): Promise<R | null> {
    this.scope(before);
    if (command.action_ref !== this.policy.config.point_action || !truth(command.data)) return null;
    const refs = [before.observation_ref, after.observation_ref];
    if (before.level_epoch !== after.level_epoch) {
      this.scope(after); return { status: 'boundary', evidence: refs, portable_not_revalidated: true };
    }
    const relevant = proposal !== null && Object.hasOwn(proposal, 'framed_transfer_plan');
    if (!relevant && !this.spans.length && !(await candidates(first, before, this.policy, [], [], {})).length) return null;
    const version = this.version;
    const [spanFacts, replacementFacts] = await transition(first, second, before, after, command, this.policy, this.spans);
    const spans = [...this.spans], receipts = [...this.receipts], derived: R[] = [];
    const sources: readonly [string, readonly R[], R[]][] = [
      ['policy.record_observed_point_motion_span', spanFacts.point_motion_span_rows, spans],
      ['policy.record_observed_framed_replacement', replacementFacts.framed_replacement_rows, receipts],
    ];
    for (const [key, rows, target] of sources) for (const row of rows) {
      const [result, workflow] = await this.policy.record(key, row);
      if (result.status === 'derived') {
        const record = retainNativeJson({ ...result.record, evidence: refs,
          derivation: { policy: result.policy_ref, rule: result.rule_ref, event: result.event_ref, workflow } });
        if (!target.some(existing => equal(sourceRecordView(existing), sourceRecordView(record)))) target.push(record);
        derived.push(record);
      }
    }
    const unchanged = equal(first, second);
    const attempts = relevant ? { ...this.attempts,
      [(proposal!.framed_transfer_plan as R).offer.candidate_ref]: { evidence: refs, unchanged } } : this.attempts;
    const last = { status: derived.length ? 'observed_records' : 'no_supported_record', evidence: refs,
      spans: spanFacts.point_motion_span_rows.length, replacements: replacementFacts.framed_replacement_rows.length,
      derived, scene_changed: !unchanged, temporal_correspondence: spanFacts.temporal_correspondence ?? null,
      unresolved: 'reception_or_coupled_state_change' };
    if (this.version !== version) throw new Error('Framed state changed during asynchronous acquisition');
    this.commit({ ...this.current, spans, receipts, attempts, last });
    return structuredClone(last);
  }

  async record(before: NativeObservation, after: NativeObservation, command: NativeCommand,
    first: NativeRows, second: NativeRows, proposal: FramedProposal, index: number,
    _frames: readonly NativeRows[]): Promise<NativeRecordResult> {
    const result = await this.recordSource(before, after, command, first, second, proposal, index);
    return { events: result === null ? [] : [result] };
  }
}
