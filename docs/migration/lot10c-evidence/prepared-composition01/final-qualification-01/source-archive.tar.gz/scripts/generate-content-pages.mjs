import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { renderSiteHeader } from '../src/site-header.ts';
import { GAME_CATALOG } from '../src/games/catalog.ts';

const root = fileURLToPath(new URL('../', import.meta.url));
const architecture = JSON.parse(await readFile(resolve(root, 'content/architecture.json'), 'utf8'));
const catalog = JSON.parse(await readFile(resolve(root, 'content/videos.json'), 'utf8'));
const benchmark = JSON.parse(await readFile(resolve(root, 'content/arc-agi-3.json'), 'utf8'));
const symbolic = JSON.parse(await readFile(resolve(root, 'content/symbolic-reasoning.json'), 'utf8'));
const motivation = JSON.parse(await readFile(resolve(root, 'content/motivation.json'), 'utf8'));
const contact = JSON.parse(await readFile(resolve(root, 'content/contact.json'), 'utf8'));
const pages = architecture.pages;
const videos = [...catalog.videos].sort((a, b) => a.episode - b.episode);
const siteOrigin = 'https://sra-playground.yannick-fontan.chatgpt.site';
const repo = 'https://github.com/yannick-fontan-1981/sra-playground';
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const anchor = value => value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const number = value => String(value).padStart(2, '0');
const displayDate = value => new Intl.DateTimeFormat('en', { day:'numeric', month:'long', year:'numeric', timeZone:'UTC' }).format(new Date(`${value}T00:00:00Z`));
const arrow = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>';
const external = '<svg class="icon small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M7 17 17 7M7 7h10v10"/></svg>';
const play = '<svg viewBox="0 0 28 28" fill="currentColor" aria-hidden="true"><path d="M10 6 23 14 10 22Z"/></svg>';
const archPath = page => page.slug === 'introduction' ? '/architecture.html' : `/architecture/${page.slug}.html`;
const videoPath = video => `/videos/${video.slug}.html`;
const paragraphs = values => (values ?? []).map(value => `<p>${escape(value)}</p>`).join('\n');
function validatePublicReference(url) {
  if (/^https:\/\/(?:github\.com|raw\.githubusercontent\.com)\/yannick-fontan-1981\/ARC-AGI-3-Yannick-Fontan(?:\/|$)/i.test(url)) {
    throw new Error('A visitor-facing reference points to the private source repository. Copy the cited resource into sra-playground first.');
  }
  const prefix = `${repo}/blob/main/`;
  if (url.startsWith(prefix)) {
    const path = decodeURIComponent(url.slice(prefix.length).split(/[?#]/)[0]);
    if (path.split('/').includes('..') || !existsSync(resolve(root, path))) throw new Error(`Missing public reference copy: ${path}`);
  }
}
const externalLink = (url, label, cls = '') => {
  if (!url.startsWith('https://')) throw new Error(`Unsupported external URL: ${url}`);
  validatePublicReference(url);
  return `<a${cls ? ` class="${cls}"` : ''} href="${escape(url)}" target="_blank" rel="noopener noreferrer">${escape(label)}${external}</a>`;
};
const sources = values => !values?.length ? '' : `<div class="reading-sources">${values.map(item => {
  const url = item.url ?? `${item.path.startsWith('docs/') ? architecture.linkBuilder.repoBase : architecture.linkBuilder.agentBase}${item.path}`;
  return externalLink(url, item.label);
}).join('')}</div>`;

if (new Set(pages.map(page => page.slug)).size !== pages.length) throw new Error('Duplicate chapter slug.');
for (const game of GAME_CATALOG) validatePublicReference(game.sourceUrl);
if (new Set(videos.map(video => video.id)).size !== videos.length) throw new Error('Duplicate video ID.');
if (new Set(videos.map(video => video.slug)).size !== videos.length) throw new Error('Duplicate video slug.');
for (const entry of [...pages, ...videos]) if (!/^[a-z0-9-]+$/.test(entry.slug)) throw new Error(`Invalid page slug: ${entry.slug}`);
for (const video of videos) {
  if (!/^[A-Za-z0-9_-]{11}$/.test(video.id)) throw new Error(`Invalid YouTube ID: ${video.id}`);
  if (!video.thumbnail.startsWith('/videos/')) throw new Error('Video thumbnail must be served locally.');
  if (video.fullText?.kind !== 'youtube-description' || typeof video.fullText.text !== 'string' || !video.fullText.text.trim()) throw new Error(`Missing original episode text: ${video.id}`);
  if (video.fullText.sourceUrl !== video.sourceUrl || video.fullText.language !== 'en' || !video.fullText.author) throw new Error(`Invalid episode text attribution: ${video.id}`);
  for (const slug of video.relatedArchitecture) if (!pages.some(page => page.slug === slug)) throw new Error(`Missing related chapter: ${slug}`);
}

function documentPage({ title, description, path, active, body, script = '/src/reading.ts' }) {
  return `<!doctype html>
<!-- Generated by scripts/generate-content-pages.mjs. Edit content/*.json or the template. -->
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="theme-color" content="#0e0c0c" />
    <meta name="color-scheme" content="dark" />
    <meta name="description" content="${escape(description)}" />
    <title>${escape(title)} · SRA Playground</title>
    <link rel="canonical" href="${siteOrigin}${path}" />
    <link rel="icon" type="image/svg+xml" href="/favicon.svg?v=green-blue-yellow" />
  </head>
  <body class="reading-document">
    <a class="skip-link" href="#content">Skip to content</a>
    ${renderSiteHeader(active)}
    ${body}
    <footer class="site-footer wrap"><span><strong>SRA Playground</strong><span class="footer-separator">/</span>Yannick Fontan</span><div><a href="/">Play the games ${arrow}</a><a href="/contact.html">Contact ${arrow}</a>${externalLink(catalog.channelUrl, 'Yanik_AI')}${externalLink(`${repo}/blob/main/THIRD_PARTY_NOTICES.md`, 'Licenses & notices')}</div></footer>
    <script type="module" src="${script}"></script>
  </body>
</html>
`;
}
function motivationTable(table) {
  if (!table) return '';
  return `<div class="motivation-commitments"><table role="table">
    <caption>${escape(table.caption)}</caption>
    <thead role="rowgroup"><tr role="row">${table.headers.map(header => `<th scope="col" role="columnheader">${escape(header)}</th>`).join('')}</tr></thead>
    <tbody role="rowgroup">${table.rows.map(row => `<tr role="row">${row.map((cell, index) => index === 0
      ? `<th scope="row" role="rowheader">${escape(cell)}</th>`
      : `<td role="cell"><span class="motivation-cell-label" aria-hidden="true">${escape(table.headers[index])}</span>${escape(cell)}</td>`).join('')}</tr>`).join('')}</tbody>
  </table></div>`;
}
function motivationPath(stages) {
  if (!stages?.length) return '';
  return `<ol class="motivation-path">${stages.map((stage, index) => `<li>
    <span class="motivation-path-number" aria-hidden="true">${number(index + 1)}</span>
    <div><p class="motivation-path-status">${escape(stage.status)}</p><h4>${escape(stage.title)}</h4>
      <p>${escape(stage.text)}</p><p class="motivation-path-evidence"><strong>Milestone</strong>${escape(stage.evidence)}</p>
      ${stage.link ? `<div class="reading-sources"><a href="${escape(stage.link.href)}">${escape(stage.link.label)}${arrow}</a></div>` : ''}
    </div>
  </li>`).join('')}</ol>`;
}
function renderMotivation() {
  let stepNumber = 0;
  const parts = motivation.parts.map(part => ({ ...part, steps: part.steps.map(step => ({ ...step, number: ++stepNumber })) }));
  return documentPage({title:motivation.title,description:motivation.description,path:'/motivation.html',active:'motivation',body:`
    <main class="reading-layout motivation-layout wrap">
      <aside class="reading-sidebar motivation-sidebar">
        <a class="sidebar-heading" href="#content">Start with Motivation</a>
        <nav aria-label="Motivation steps">${parts.map(part => `
          <a class="motivation-nav-part" href="#${escape(part.id)}">${escape(part.label)} · ${escape(part.title)}</a>
          ${part.steps.map(step => `<a href="#${escape(step.id)}"><span>${number(step.number)}</span>${escape(step.navTitle)}</a>`).join('')}
        `).join('')}</nav>
        <a class="sidebar-series" href="/symbolic-reasoning.html">Continue: the method ${arrow}</a>
      </aside>
      <article class="reading-article motivation-article" id="content">
        <header class="reading-header">
          <p class="reading-breadcrumb">The beginning <span>/</span> ${escape(motivation.breadcrumb)}</p>
          <h1>${escape(motivation.title)}</h1>
          <p class="reading-deck">${escape(motivation.deck)}</p>
          <p class="motivation-byline">A personal statement by ${escape(motivation.author)}</p>
        </header>
        <p class="motivation-pitch">${escape(motivation.pitch)}</p>
        <div class="reading-intro">${paragraphs(motivation.intro)}</div>
        <nav class="motivation-route" aria-label="The three parts of this motivation">${parts.map(part => `
          <a href="#${escape(part.id)}"><span>Steps ${number(part.steps[0].number)}–${number(part.steps.at(-1).number)}</span><strong>${escape(part.title)}</strong>${arrow}</a>
        `).join('')}</nav>
        ${parts.map(part => `
          <section class="motivation-part" id="${escape(part.id)}" aria-labelledby="${escape(part.id)}-heading">
            <header class="motivation-part-heading"><p>${escape(part.label)}</p><h2 id="${escape(part.id)}-heading">${escape(part.title)}</h2><p>${escape(part.description)}</p></header>
            ${part.steps.map(step => `
              <section class="motivation-step" id="${escape(step.id)}" aria-labelledby="${escape(step.id)}-heading">
                <div class="motivation-step-heading"><span class="motivation-step-number" aria-label="Step ${step.number}">${number(step.number)}</span><h3 id="${escape(step.id)}-heading">${escape(step.title)}</h3></div>
                <div class="motivation-step-body">
                  ${paragraphs(step.paragraphs)}
                  ${motivationTable(step.table)}
                  ${step.items?.length ? `<ul>${step.items.map(item => `<li>${escape(item)}</li>`).join('')}</ul>` : ''}
                  ${motivationPath(step.stages)}
                  ${paragraphs(step.after)}
                  ${step.consequence ? `<div class="motivation-consequence"><p class="motivation-consequence-label">${escape(step.consequenceLabel ?? 'The consequence')}</p><p>${escape(step.consequence)}</p></div>` : ''}
                  ${sources(step.sources)}
                  ${step.links?.length ? `<div class="reading-sources">${step.links.map(link => `<a href="${escape(link.href)}">${escape(link.label)}${arrow}</a>`).join('')}</div>` : ''}
                </div>
              </section>
            `).join('')}
          </section>
        `).join('')}
        <section class="motivation-closing" aria-labelledby="motivation-closing-title">
          <h2 id="motivation-closing-title">${escape(motivation.closing.title)}</h2>
          <p>${escape(motivation.closing.text)}</p>
          <nav class="motivation-next" aria-label="Continue exploring SRA">${motivation.closing.links.map(link => `<a href="${escape(link.href)}"><small>${escape(link.label)}</small><span>${escape(link.title)}${arrow}</span></a>`).join('')}</nav>
          <a class="motivation-back" href="#content">Back to the beginning ↑</a>
        </section>
      </article>
    </main>`});
}
function renderContact() {
  const envelope = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/></svg>';
  return documentPage({title:contact.title,description:contact.description,path:'/contact.html',active:'contact',body:`
    <main class="contact-page wrap" id="content">
      <header class="reading-header contact-header">
        <p class="reading-breadcrumb">SRA Playground <span>/</span> Get in touch</p>
        <h1>${escape(contact.title)}</h1>
        <p class="reading-deck">${escape(contact.deck)}</p>
      </header>
      <div class="contact-layout">
        <section class="contact-about" aria-labelledby="contact-name">
          <p class="contact-kicker">About me</p>
          <h2 id="contact-name">${escape(contact.name)}</h2>
          <p class="contact-role">${escape(contact.role)}</p>
          ${paragraphs(contact.bio)}
        </section>
        <aside class="contact-card" aria-labelledby="contact-email-heading">
          <p class="contact-kicker">Get in touch</p>
          <h2 id="contact-email-heading">Let’s talk.</h2>
          <p>${escape(contact.invitation)}</p>
          <a class="contact-email" href="mailto:${escape(contact.email)}">${envelope}<span>${escape(contact.email)}</span>${arrow}</a>
          <div class="contact-links">${externalLink(repo, 'GitHub')}${externalLink(catalog.channelUrl, 'Yanik_AI on YouTube')}</div>
        </aside>
      </div>
    </main>`});
}
function chapterNav(current) {
  return `<aside class="reading-sidebar"><a class="sidebar-heading" href="/architecture.html">Architecture</a><nav aria-label="Architecture chapters">${pages.map((page, index) => `<a href="${archPath(page)}"${page.slug === current ? ' class="is-current" aria-current="page"' : ''}><span>${number(index)}</span>${escape(page.navTitle)}</a>`).join('')}</nav><a class="sidebar-series" href="/videos.html">Video series ${arrow}</a></aside>`;
}
function videoNav(current) {
  return `<aside class="reading-sidebar video-sidebar"><a class="sidebar-heading" href="/videos.html">Video series</a><nav aria-label="Video episodes">${videos.map(video => `<a href="${videoPath(video)}"${video.slug === current ? ' class="is-current" aria-current="page"' : ''}><span>${number(video.episode)}</span>${escape(video.displayTitle)}</a>`).join('')}</nav>${externalLink(catalog.channelUrl, 'YouTube channel', 'sidebar-series')}</aside>`;
}
function section(section) {
  return `<section class="reading-section" id="${anchor(section.title)}">
    <h2>${escape(section.title)}</h2>
    ${section.label ? `<p class="example-label">${escape(section.label)}</p>` : ''}
    ${paragraphs(section.paragraphs)}
    ${section.items?.length ? `<${section.ordered ? 'ol' : 'ul'}>${section.items.map(item => `<li>${escape(item)}</li>`).join('')}</${section.ordered ? 'ol' : 'ul'}>` : ''}
    ${section.table ? `<div class="reading-table" role="region" aria-label="${escape(section.title)}" tabindex="0"><table><thead><tr>${section.table.headers.map(header => `<th scope="col">${escape(header)}</th>`).join('')}</tr></thead><tbody>${section.table.rows.map(row => `<tr>${row.map((cell, index) => index === 0 ? `<th scope="row">${escape(cell)}</th>` : `<td>${escape(cell)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : ''}
    ${section.code ? `<figure class="reading-code"><pre tabindex="0"><code>${escape(section.code)}</code></pre>${section.codeCaption ? `<figcaption>${escape(section.codeCaption)}</figcaption>` : ''}</figure>` : ''}
    ${section.example ? symbolicExample() : ''}
    ${section.timeline ? `<ol class="symbolic-timeline">${section.timeline.map(item=>`<li><span class="timeline-date">${escape(item.date)}</span><div><h3>${escape(item.title)}</h3><p>${escape(item.text)}</p>${sources([item.source])}</div></li>`).join('')}</ol>` : ''}
    ${paragraphs(section.after)}
    ${section.links?.length ? `<div class="reading-sources chapter-links">${section.links.map(item => {
      if (!/^\/(?!\/)[a-z0-9/.-]+(?:#[a-z0-9-]+)?$/.test(item.href)) throw new Error(`Invalid chapter link: ${item.href}`);
      return `<a href="${escape(item.href)}">${escape(item.label)}${arrow}</a>`;
    }).join('')}</div>` : ''}
    ${sources(section.sources)}
  </section>`;
}
function pager(previous, next, path, label) {
  return `<nav class="reading-pager" aria-label="${label}">${previous ? `<a href="${path(previous)}"><small>Previous</small><span>${escape(previous.navTitle ?? previous.displayTitle)}</span></a>` : '<span></span>'}${next ? `<a class="pager-next" href="${path(next)}"><small>Next</small><span>${escape(next.navTitle ?? next.displayTitle)}${arrow}</span></a>` : '<a class="pager-next" href="/">Playground '+arrow+'</a>'}</nav>`;
}
function relatedVideos(page) {
  const selected = videos.filter(video => video.relatedArchitecture.includes(page.slug));
  if (!selected.length) return '';
  return `<section class="related-reading"><h2>Related videos</h2><div>${selected.map(video => `<a href="${videoPath(video)}"><span>Episode ${number(video.episode)}</span><strong>${escape(video.displayTitle)}</strong>${arrow}</a>`).join('')}</div></section>`;
}
function renderChapter(page, index) {
  const directory = page.slug !== 'introduction' ? '' : `<section class="chapter-directory" aria-labelledby="chapters-heading"><h2 id="chapters-heading">Chapters</h2>${pages.slice(1).map((chapter, offset) => `<a href="${archPath(chapter)}"><span>${number(offset + 1)}</span><div><h3>${escape(chapter.navTitle)}</h3><p>${escape(chapter.description)}</p></div>${arrow}</a>`).join('')}</section>`;
  return documentPage({title:page.title,description:page.description,path:archPath(page),active:'architecture',body:`
    <main class="reading-layout wrap">
      ${chapterNav(page.slug)}
      <article class="reading-article" id="content">
        <header class="reading-header"><p class="reading-breadcrumb">Architecture <span>/</span> ${escape(page.navTitle)}</p><h1>${escape(page.title)}</h1><p class="reading-deck">${escape(page.description)}</p></header>
        <div class="reading-intro">${paragraphs(page.intro)}${sources(page.sources)}</div>
        ${page.sections.map(section).join('\n')}
        ${directory}
        ${relatedVideos(page)}
        <p class="source-snapshot">Source reference: ${externalLink(architecture.sourceSnapshotUrl, `${architecture.sourceCommit.slice(0,12)} · public copies`)}</p>
        ${pager(pages[index-1],pages[index+1],archPath,'Chapter navigation')}
      </article>
    </main>`});
}
function renderBenchmark() {
  const path = '/arc-agi-3.html';
  return documentPage({title:benchmark.title,description:benchmark.description,path,active:'arc-agi-3',body:`
    <main class="reading-layout wrap">
      <aside class="reading-sidebar benchmark-sidebar"><a class="sidebar-heading" href="${path}">ARC-AGI-3</a><nav aria-label="On this page">${benchmark.sections.map((item,index)=>`<a href="#${anchor(item.title)}"><span>${number(index+1)}</span>${escape(item.navTitle)}</a>`).join('')}</nav>${externalLink('https://arcprize.org/arc-agi/3','Official benchmark','sidebar-series')}</aside>
      <article class="reading-article benchmark-article" id="content">
        <header class="reading-header"><p class="reading-breadcrumb">ARC-AGI-3 <span>/</span> An introduction</p><h1>${escape(benchmark.title)}</h1><p class="reading-deck">${escape(benchmark.description)}</p></header>
        <div class="reading-intro">${paragraphs(benchmark.intro)}${sources(benchmark.sources)}</div>
        ${benchmark.sections.map(section).join('\n')}
        <section class="related-reading"><h2>Try it for yourself</h2><div class="benchmark-actions"><a class="reading-button" href="/?game=LS20">Play LS20 · official ${arrow}</a><a class="reading-button" href="/?game=CASC">Play CASC · custom ${arrow}</a><a class="reading-button" href="/architecture.html">How SRA is designed ${arrow}</a></div></section>
        <p class="source-snapshot">Official sources checked ${escape(displayDate(benchmark.reviewedDate))}.</p>
      </article>
    </main>`});
}
function symbolicExample() {
  const facts = ['At(agent,door)', 'Locked(door)', 'Closed(door)', 'WithinReach(key)', 'Matches(key,door)'];
  const rules = [
    ['Take the key', 'At(agent,door) + WithinReach(key)', 'Has(agent,key)', 'WithinReach(key)'],
    ['Unlock the door', 'At(agent,door) + Has(agent,key) + Matches(key,door) + Locked(door)', 'Unlocked(door)', 'Locked(door)'],
    ['Open the door', 'At(agent,door) + Unlocked(door) + Closed(door)', 'Open(door)', 'Closed(door)'],
    ['Pass through', 'At(agent,door) + Open(door)', 'Reached(exit)', 'At(agent,door)'],
  ];
  const line = (label,value)=>`<span class="symbolic-rule-line"><span>${escape(label)}</span><code>${escape(value)}</code></span>`;
  return `<div id="symbolic-example" data-outcome="reached">
    <p class="symbolic-demo-label">Illustrative rule system</p>
    <div class="symbolic-scenario-control"><label for="symbolic-scenario">Change the starting facts</label><select id="symbolic-scenario" data-symbolic-scenario disabled><option value="reachable">Matching key within reach</option><option value="held">Matching key already held</option><option value="unknown">Key compatibility unknown</option><option value="unreachable">Matching key out of reach</option></select></div>
    <div class="symbolic-demo-columns">
      <section aria-labelledby="symbolic-facts-heading"><h3 id="symbolic-facts-heading">Starting facts</h3><div data-symbolic-facts><ul class="symbolic-fact-list">${facts.map(fact=>`<li><code>${escape(fact)}</code></li>`).join('')}</ul></div></section>
      <section aria-labelledby="symbolic-plan-heading"><h3 id="symbolic-plan-heading">Plan for <code>Reached(exit)</code></h3><ol data-symbolic-plan>${rules.map(([name,,adds,removes])=>`<li><strong>${name}</strong>${line('Now true',adds)}${line('No longer true',removes)}</li>`).join('')}</ol></section>
    </div>
    <p data-symbolic-result role="status" aria-live="polite">Goal reached in model · 4 actions</p>
    <p data-symbolic-missing>Each action is justified by the current facts. Its effects update the state used by the next action.</p>
    <details class="symbolic-rules"><summary>The four action rules</summary><ul data-symbolic-rules>${rules.map(([name,requires,adds,removes])=>`<li><strong>${name}</strong>${line('Requires',requires)}${line('Adds',adds)}${line('Removes',removes)}</li>`).join('')}</ul></details>
    <p class="symbolic-demo-note">The agent starts at the door. The key remains held after unlocking. These four actions succeed whenever their stated conditions hold; every other fact stays unchanged. The rules are supplied for this teaching example. An ARC agent would first have to discover and test the relevant mechanisms. This demonstration is separate from SRA.</p>
  </div>`;
}
function renderSymbolicReasoning() {
  const path = '/symbolic-reasoning.html';
  return documentPage({title:symbolic.title,description:symbolic.description,path,active:'symbolic-reasoning',script:'/src/symbolic-reasoning.ts',body:`
    <main class="reading-layout wrap">
      <aside class="reading-sidebar benchmark-sidebar"><a class="sidebar-heading" href="${path}">Symbolic Reasoning</a><nav aria-label="On this page">${symbolic.sections.map((item,index)=>`<a href="#${anchor(item.title)}"><span>${number(index+1)}</span>${escape(item.navTitle)}</a>`).join('')}</nav><a class="sidebar-series" href="/architecture.html">SRA architecture ${arrow}</a></aside>
      <article class="reading-article symbolic-article" id="content">
        <header class="reading-header"><p class="reading-breadcrumb">Ideas <span>/</span> An introduction</p><h1>${escape(symbolic.title)}</h1><p class="reading-deck">${escape(symbolic.description)}</p></header>
        <div class="symbolic-definition"><p class="definition-label">A definition</p><p>${escape(symbolic.definition)}</p></div>
        <div class="reading-intro">${paragraphs(symbolic.intro)}</div>
        ${symbolic.sections.map(section).join('\n')}
        <section class="related-reading"><h2>Explore the project</h2><div class="benchmark-actions"><a class="reading-button" href="/architecture.html">SRA architecture ${arrow}</a><a class="reading-button" href="/arc-agi-3.html">What is ARC-AGI-3? ${arrow}</a><a class="reading-button" href="/gallery.html">75 New Games ${arrow}</a></div></section>
        <p class="source-snapshot">Primary sources linked beside the relevant sections. Reviewed ${escape(displayDate(symbolic.reviewedDate))}.</p>
      </article>
    </main>`});
}
function videoCard(video) {
  return `<a class="video-card" href="${videoPath(video)}"><div class="video-thumb"><img src="${video.thumbnail}" alt="" width="1280" height="720" loading="lazy"/><span class="video-duration">${escape(video.duration)}</span><span class="video-card-play">${play}</span></div><div class="video-card-meta"><span>Episode ${number(video.episode)}</span><span>${escape(video.games.join(' / '))}${video.gameVersion === 'Legacy' ? ' · Legacy' : ''}</span></div><h2>${escape(video.displayTitle)}</h2><p>${escape(video.topics.slice(0,2).join(' · '))}</p></a>`;
}
function renderVideoIndex() {
  return documentPage({title:'Videos',description:'Yanik_AI: game runs and development notes about the Symbolic Reasoning Agent.',path:'/videos.html',active:'videos',body:`
    <main class="video-index wrap" id="content">
      <header class="video-index-header"><div><p class="reading-breadcrumb">Yanik_AI <span>/</span> Video series</p><h1>Building SRA</h1><p>Game runs and notes on the development of the Symbolic Reasoning Agent.</p></div>${externalLink(catalog.channelUrl, 'Watch the channel', 'reading-button')}</header>
      <div class="video-index-count"><span>${videos.length} episodes</span><span>Yannick Fontan</span></div>
      <div class="video-grid">${videos.map(videoCard).join('')}</div>
      <p class="video-index-note">Each episode includes the full original text published by Yannick Fontan in its YouTube description.</p>
    </main>`});
}
function renderVideo(video, index) {
  const related = video.relatedArchitecture.map(slug=>pages.find(page=>page.slug===slug));
  const gameLinks = video.games.map(code=>`<a class="reading-button" href="/?game=${encodeURIComponent(code)}">Play ${escape(code)}${video.gameVersion === 'Legacy' ? ' (current official version)' : ''}${arrow}</a>`).join('');
  const fullText = video.fullText.text.split(/\n\s*\n/).map(block=>`<p>${escape(block)}</p>`).join('\n');
  const body = `
    <main class="reading-layout wrap">
      ${videoNav(video.slug)}
      <article class="reading-article video-article" id="content">
        <header class="reading-header"><p class="reading-breadcrumb"><a href="/videos.html">Videos</a><span>/</span> Episode ${number(video.episode)}</p><h1>${escape(video.displayTitle)}</h1><div class="video-meta"><span>${escape(video.duration)}</span><span>${escape(video.games.join(' / '))}${video.gameVersion ? ` · ${escape(video.gameVersion)}` : ''}</span><time datetime="${escape(video.date)}">${escape(displayDate(video.date))}</time><a href="#full-text">Read full text ↓</a></div></header>
        <div class="video-player" data-video-id="${escape(video.id)}" data-video-title="${escape(video.displayTitle)}"><button type="button" class="video-launch" aria-label="Play Episode ${number(video.episode)}: ${escape(video.displayTitle)}"><img src="${video.thumbnail}" alt="" width="1280" height="720"/><span class="video-play-label">${play}<span>Play video</span></span></button></div>
        <div class="video-watch-link">${externalLink(video.sourceUrl, 'Watch on YouTube')}${externalLink(catalog.channelUrl, 'Yanik_AI channel')}</div>
        <section class="reading-section episode-text" id="full-text" aria-label="Episode text"><p class="video-source-note">${escape(video.fullText.author)} · Original text from the ${externalLink(video.fullText.sourceUrl, 'YouTube description')}.</p><div class="episode-full-text" lang="${escape(video.fullText.language)}">${fullText}</div></section>
        <section class="related-reading"><h2>Related pages</h2><div>${related.map(page=>`<a href="${archPath(page)}"><span>Architecture</span><strong>${escape(page.navTitle)}</strong>${arrow}</a>`).join('')}</div></section>
        <div class="episode-games">${gameLinks}</div>
        ${pager(videos[index-1],videos[index+1],videoPath,'Episode navigation')}
      </article>
    </main>`;
  return documentPage({title:`Episode ${number(video.episode)} — ${video.displayTitle}`,description:video.summary.slice(0,160),path:videoPath(video),active:'videos',body});
}
async function save(path, html) {
  const target = resolve(root, `.${path}`);
  await mkdir(dirname(target), { recursive:true });
  await writeFile(target, html.replace(/[\t ]+$/gm, ''));
}
for (const [index,page] of pages.entries()) await save(archPath(page),renderChapter(page,index));
await save('/motivation.html',renderMotivation());
await save('/arc-agi-3.html',renderBenchmark());
await save('/symbolic-reasoning.html',renderSymbolicReasoning());
await save('/videos.html',renderVideoIndex());
await save('/contact.html',renderContact());
for (const [index,video] of videos.entries()) await save(videoPath(video),renderVideo(video,index));
console.log(`Generated Motivation, the ARC-AGI-3 and Symbolic Reasoning introductions, ${pages.length} architecture pages, ${videos.length} episode pages, the video index, and the Contact page.`);
