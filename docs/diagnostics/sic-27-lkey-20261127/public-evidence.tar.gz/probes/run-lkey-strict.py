"""Run one frozen, uninstrumented chronological candidate with the archived caps."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

root = Path('/workspace/scratch/082336907086/sic-27-work/profile')
out = Path('/workspace/scratch/082336907086/sic-27-work/lkey-candidate-165991ec')
expected = '165991ececa2f02dfbe8950882fbb3851910a14e'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert git('rev-parse', 'HEAD') == expected
assert not git('status', '--porcelain')
assert not out.exists(), 'A candidate run is immutable; use a new output directory for any separate run.'
out.mkdir()
reference = 'docs/architecture/sic-replay-reference-levels-20261126.json'
files = ['src/sic/profile-transfer.ts', 'src/sic/profile-rank-order.ts', 'src/sic/standalone-families.ts',
         'src/sic/experiment-selection-groups.ts', 'src/logos-engine/v6-native-runtime.ts',
         'src/runtime/v6-agent-service.ts', 'scripts/check-sic-chronological.mjs',
         'scripts/sic-replay-budgets.mjs', reference, 'docs/architecture/sic-v8-level6-campaign-7bb9f152.json']
command = ['node', 'scripts/check-sic-chronological.mjs', 'LKEY', '6', str(out / 'results.jsonl'), '1', 'sic']
manifest = {'startedAt': now(), 'sourceCommit': expected, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
            'sourceHashes': {name: digest(root / name) for name in files}, 'instrumented': False,
            'workers': 1, 'startLevel': 1, 'targetLevels': 6, 'game': 'LKEY', 'cwd': str(root),
            'command': command, 'environment': {'SIC_REPLAY_REFERENCES': reference}}
(out / 'run-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'startedAt': manifest['startedAt'], 'sourceCommit': expected, 'output': str(out)}), flush=True)
with (out / 'runner.log').open('w') as stream:
    result = subprocess.run(command, cwd=root, env={**os.environ, 'SIC_REPLAY_REFERENCES': reference},
                            stdout=stream, stderr=subprocess.STDOUT)
end = {'observedEndAt': now(), 'exitCode': result.returncode, 'sourceCommit': git('rev-parse', 'HEAD'),
       'clean': not git('status', '--porcelain'), 'sourceHashes': {name: digest(root / name) for name in files},
       'resultsSha256': digest(out / 'results.jsonl') if (out / 'results.jsonl').exists() else None}
end['sourceUnchanged'] = end['sourceCommit'] == expected and end['sourceHashes'] == manifest['sourceHashes'] and end['clean']
(out / 'run-end.json').write_text(json.dumps(end, indent=2) + '\n')
print(json.dumps(end), flush=True)
assert end['sourceUnchanged'], 'Frozen candidate changed during the run'
sys.exit(result.returncode)
