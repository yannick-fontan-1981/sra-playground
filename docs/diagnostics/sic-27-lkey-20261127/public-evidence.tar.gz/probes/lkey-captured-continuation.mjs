// Re-proposal and guard checks over already recorded public returns; no game is loaded.
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
const load = file => import(pathToFileURL(resolve(file)));
const [{ createSicVerifyProfileTransfer }, { NativeKnowledgeStore }] = await Promise.all([
  load('src/sic/profile-transfer.ts'), load('src/logos-engine/v6-knowledge-store.ts'),
]);
const path = process.argv[2] ?? '/workspace/scratch/082336907086/sic-27-work/lkey-profile-8e432107/lkey-family-37.jsonl';
const output = process.argv[3] ?? '/workspace/scratch/082336907086/sic-27-work/lkey-profile-8e432107/captured-continuation.json';
const bytes = readFileSync(path);
const events = bytes.toString('utf8').trim().split('\n').map(JSON.parse);
const captures = events.filter(event => event.kind === 'admission-input' && event.level === 6);
const at = new Map(captures.map(capture => [capture.levelActions, capture]));
const commands = new Map(events.filter(event => event.kind === 'command-applied' && event.level === 6)
  .map(event => [event.levelActions - 1, event.command]));
const rowsOf = capture => capture.publicRowsRle.map(row => row.flatMap((value, index) => index % 2 ? [] : Array(row[index + 1]).fill(value)));
const checked = [];
for (const planNumber of [1, 5, 7, 10, 12]) {
  const capture = captures.find(event => event.planNumber === planNumber);
  if (!capture) throw new Error('Missing public admission ' + planNumber);
  const family = createSicVerifyProfileTransfer();
  family.restore(capture.familyStates.find(item => item.id === family.id).state);
  await family.attachPrograms(new NativeKnowledgeStore('captured-profile-' + planNumber, 'captured-profile'));
  const proposal = await family.propose(capture.observation, rowsOf(capture), capture.inputs, 36 - capture.levelActions,
    { yieldControl: async () => {}, reasoningMode: capture.execution?.reasoningMode ?? 'solving' });
  const steps = [];
  for (let index = 0; index < (proposal?.actions.length ?? 0); index++) {
    const action = proposal.actions[index], actionNumber = capture.levelActions + index;
    const before = at.get(actionNumber), after = at.get(actionNumber + 1), actual = commands.get(actionNumber);
    if (!before || !actual) { steps.push({ index, captured: false }); break; }
    const sameAction = action.action_ref === 'ACTION' + actual.id
      && (!action.data || Object.keys(action.data).length === 0);
    const guardBefore = family.before(proposal, index, { frame_rows: rowsOf(before) }, before.observation);
    const guardAfter = after ? family.after(proposal, index, before.observation, after.observation, rowsOf(before), rowsOf(after)) : null;
    let stateMatchesBaseline = null;
    if (sameAction && guardBefore.admitted && guardAfter?.matched) {
      family.record(before.observation, after.observation, action, rowsOf(before), rowsOf(after), proposal, index);
      const expected = after.familyStates.find(item => item.id === family.id).state;
      stateMatchesBaseline = isDeepStrictEqual(JSON.parse(JSON.stringify(family.state())), expected);
    }
    steps.push({ index, actionNumber: actionNumber + 1, action, actual, sameAction, guardBefore, guardAfter, stateMatchesBaseline });
    if (!sameAction || !guardBefore.admitted || guardAfter?.matched === false) break;
  }
  checked.push({ planNumber, levelActions: capture.levelActions, observationRef: capture.observation.observation_ref,
    proposed: !!proposal, strategy: proposal?.sicSituationCard?.strategy, phase: proposal?.strategy,
    actionCount: proposal?.actions.length, actions: proposal?.actions,
    steps });
}
const result = { capturedSource: events.find(event => event.kind === 'profile-start')?.sourceCommit,
  captureSha256: createHash('sha256').update(bytes).digest('hex'),
  candidateProfileSha256: createHash('sha256').update(readFileSync(resolve('src/sic/profile-transfer.ts'))).digest('hex'),
  limitation: 'Pure family re-proposal, per-return guard evaluation and record-state comparison on public baseline frames. It does not run the game or prove native tickets, timing, runtime graph publication or future returns.', checked };
writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(checked.map(item => ({ planNumber: item.planNumber, actionCount: item.actionCount,
  phase: item.phase, checkedReturns: item.steps.filter(step => step.guardAfter).length,
  uncapturedSteps: item.steps.filter(step => step.captured === false).length,
  sameCommands: item.steps.filter(step => step.captured !== false).every(step => step.sameAction),
  admitted: item.steps.filter(step => step.captured !== false).every(step => step.guardBefore?.admitted),
  matched: item.steps.every(step => !step.guardAfter || step.guardAfter.matched),
  acquiredStateMatches: item.steps.every(step => step.stateMatchesBaseline !== false) })), null, 2));
