"""Collect actual native tickets in one frozen L1-to-L6 SIC session."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

root = Path('/workspace/scratch/082336907086/sic-27-work/profile')
out = Path('/workspace/scratch/082336907086/sic-27-work/lkey-continuity-165991ec')
expected = '165991ececa2f02dfbe8950882fbb3851910a14e'
git = lambda *args: subprocess.check_output(['git', *args], cwd=root, text=True).strip()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git('rev-parse', 'HEAD') == expected
assert not git('status', '--porcelain')
assert not out.exists(), 'Do not overwrite a prior collector run'
out.mkdir()
files = ['src/sic/profile-transfer.ts', 'src/logos-engine/v6-native-runtime.ts', 'src/runtime/v6-agent-service.ts',
         'scripts/compare-source100.mjs', 'scripts/sic-continuity-evidence.mjs']
settings = {'SIC_STUDY_CONTINUITY': '1', 'SIC_STUDY_WORKERS': '1', 'SIC_STUDY_SOLVER': 'sic',
            'SIC_STUDY_RECORD_COMMANDS': '1', 'SIC_STUDY_PROGRESS': '1'}
command = ['node', 'scripts/compare-source100.mjs', '.', '.', str(out / 'results.jsonl'), 'source:LKEY', '1', '6', '36']
manifest = {'startedAt': now(), 'sourceCommit': expected, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
            'sourceHashes': {name: digest(root / name) for name in files}, 'workers': 1,
            'startLevel': 1, 'targetLevels': 6, 'game': 'LKEY', 'cap': 36,
            'purpose': 'Executed continuity evidence; strict per-level timing qualification is recorded separately.',
            'command': command, 'environment': settings, 'cwd': str(root)}
(out / 'run-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'startedAt': manifest['startedAt'], 'sourceCommit': expected, 'output': str(out)}), flush=True)
with (out / 'runner.log').open('w') as stream:
    result = subprocess.run(command, cwd=root, env={**os.environ, **settings}, stdout=stream, stderr=subprocess.STDOUT)
end = {'observedEndAt': now(), 'exitCode': result.returncode, 'sourceCommit': git('rev-parse', 'HEAD'),
       'clean': not git('status', '--porcelain'), 'sourceHashes': {name: digest(root / name) for name in files},
       'resultsSha256': digest(out / 'results.jsonl') if (out / 'results.jsonl').exists() else None}
end['sourceUnchanged'] = end['sourceCommit'] == expected and end['sourceHashes'] == manifest['sourceHashes'] and end['clean']
(out / 'run-end.json').write_text(json.dumps(end, indent=2) + '\n')
print(json.dumps(end), flush=True)
assert end['sourceUnchanged'], 'Frozen source changed during the collector run'
sys.exit(result.returncode)
