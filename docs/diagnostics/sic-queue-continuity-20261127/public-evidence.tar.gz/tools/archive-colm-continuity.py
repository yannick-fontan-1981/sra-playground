"""Preserve the frozen strict run, native receipt collector and calibrated gate."""
from pathlib import Path
import collections
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

work = Path('/workspace/scratch/082336907086/sic-27-work')
root = work / 'queue-gate'
strict_dir = work / 'colm-integrated-b653fada'
collector_dir = work / 'colm-continuity-b653fada'
out = root / 'docs/diagnostics/sic-queue-continuity-20261127'
sha256 = lambda value: hashlib.sha256(value).hexdigest()
read_json = lambda path: json.loads(path.read_text())
strict = read_json(strict_dir / 'results.jsonl')
collector = read_json(collector_dir / 'results.jsonl')
validation = read_json(work / 'queue-gate-validation.json')
assert validation['testsExitCode'] == validation['typecheckExitCode'] == 0
assert strict['levels'] == 6 and strict['reason'] == 'target_levels_completed'
assert all(level['won'] for level in collector['levels'])
assert strict['actions'] == collector['issued'] == collector['sic'] == 103
assert strict['trace'] == collector['trajectory']
assert strict['recoveries'] == {'reset': 0, 'undo': 0} and collector['resets'] == 0
manifests = {}
for phase, path in [('strict', strict_dir), ('collector', collector_dir)]:
    start, end = read_json(path / 'run-manifest.json'), read_json(path / 'run-end.json')
    assert start['sourceCommit'] == end['sourceCommit'] == 'b653fada3b29ce085eb80a7a04bbdc6598913a69'
    assert start['sourceHashes'] == end['sourceHashes'] and end['clean'] and end['sourceUnchanged']
    assert end['resultsSha256'] == sha256((path / 'results.jsonl').read_bytes())
    manifests[phase] = {'start': start, 'end': end}
assert manifests['strict']['start']['sourceHashes'] == manifests['collector']['start']['sourceHashes']

rows = []
for level, score in enumerate(strict['levelStats'], 1):
    tickets = [ticket for ticket in collector['executedTickets'] if ticket['level'] == level]
    groups = collections.defaultdict(list)
    for ticket in tickets:
        groups[ticket['decisionRevision']].append(ticket)
    series = [group for group in groups.values() if len(group) > 1]
    preparations = collections.Counter(ticket['queued']['role'] for group in series for ticket in group[:-1])
    receives = [ticket for ticket in tickets if ticket.get('queued', {}).get('role') == 'receive']
    revalidated = [ticket for ticket in receives if ticket['queued'].get('acquisition', {}).get('evidence')
                   == [ticket['queued']['beforeRef'], ticket['queued']['afterRef']]]
    official = [ticket for ticket in receives if ticket['outcome']['reason'] == 'official_boundary']
    assert score['actions'] == len(tickets) <= score['budget']['actions']
    assert score['scoredMs'] <= score['budget']['activeTimeMs']
    assert len(official) == 1
    rows.append({'level': level, 'commands': len(tickets), 'budget': score['budget'],
                 'scoredMs': score['scoredMs'], 'activeMs': score['activeMs'], 'settlementMs': score['settlementMs'],
                 'prefixHash': score['prefixHash'], 'acquiredRecordsCumulative': score['acquiredRecords'],
                 'decisions': len(groups), 'continued': sum(len(group) - 1 for group in series),
                 'preparedReceives': len(series), 'preparations': dict(sorted(preparations.items())),
                 'seriesLengths': [len(group) for group in series], 'knownReceives': len(receives),
                 'currentReacquisitions': len(revalidated), 'officialReceiveScores': len(official)})

members = {}
for prefix, folder in [('strict', strict_dir), ('collector', collector_dir)]:
    for path in sorted(folder.iterdir()):
        if path.is_file():
            members[f'{prefix}/{path.name}'] = path.read_bytes()
for name in ['queue-gate-tests.log', 'queue-gate-typecheck.log', 'queue-gate-final-tests.log',
             'queue-gate-final-typecheck.log', 'queue-gate-validation.json', 'queue-gate-colm-report.json']:
    members['validation/' + name] = (work / name).read_bytes()
for name in ['run-colm-integrated.py', 'archive-colm-continuity.py']:
    members['tools/' + name] = (work / 'probes' / name).read_bytes()
member_manifest = {name: {'bytes': len(value), 'sha256': sha256(value)} for name, value in sorted(members.items())}
members['member-manifest.json'] = (json.dumps(member_manifest, indent=2) + '\n').encode()
tar_bytes = io.BytesIO()
with tarfile.open(fileobj=tar_bytes, mode='w', format=tarfile.USTAR_FORMAT) as tar:
    for name, value in sorted(members.items()):
        item = tarfile.TarInfo(name)
        item.size = len(value)
        item.mode = 0o644
        item.mtime = item.uid = item.gid = 0
        tar.addfile(item, io.BytesIO(value))
archive = gzip.compress(tar_bytes.getvalue(), mtime=0)
out.mkdir(parents=True, exist_ok=True)
(out / 'public-evidence.tar.gz').write_bytes(archive)
gate_files = ['scripts/verify-sic-continuity.mjs', '.github/workflows/sic-continuity.yml',
              'tests/sic-queue-continuity-contract.test.mjs', 'tests/fixtures/sic-queue-continuity-public.json.gz']
summary = {'schema': 'sic.queue-continuity.v1', 'game': 'COLM', 'sourceCommit': manifests['strict']['start']['sourceCommit'],
           'sourceTree': manifests['strict']['start']['sourceTree'],
           'sourceHashes': manifests['strict']['start']['sourceHashes'],
           'sourceUnchangedDuringRuns': True, 'strictResultSha256': manifests['strict']['end']['resultsSha256'],
           'collectorResultSha256': manifests['collector']['end']['resultsSha256'],
           'samePublicCommandReturnTrajectory': True, 'publicTrajectorySha256': strict['trace'],
           'levelsWon': 6, 'commands': 103, 'acquiredRecords': 103, 'reset': 0, 'undo': 0,
           'decisions': sum(row['decisions'] for row in rows),
           'continued': sum(row['continued'] for row in rows),
           'preparedReceives': sum(row['preparedReceives'] for row in rows),
           'knownReceives': sum(row['knownReceives'] for row in rows),
           'currentReacquisitions': sum(row['currentReacquisitions'] for row in rows),
           'officialReceiveScores': sum(row['officialReceiveScores'] for row in rows),
           'perLevel': rows, 'validation': validation,
           'gateFilesSha256': {name: sha256((root / name).read_bytes()) for name in gate_files},
           'continuityCoverage': {'games': 15, 'levels': 90, 'cohorts': 13,
                                  'previousGames': 14, 'previousLevels': 84, 'previousThresholdsUnchanged': True},
           'limitations': ['The full 90-level gate must run on the final integrated SHA in CI.',
                           'The published Site COLM replay remains a separate delivery check.',
                           'Official boundary receipts are not counted as current owner reacquisition.',
                           'Collector wall time is not used as strict timing qualification.'],
           'archive': {'file': 'public-evidence.tar.gz', 'bytes': len(archive), 'sha256': sha256(archive)}}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
table = '\n'.join('| {level} | {commands}/{cap} | {score:.3f}/{time:.0f} | {contacts} | {translate} | {reorder} | {revalidated} + {boundary} |'.format(
    level=row['level'], commands=row['commands'], cap=row['budget']['actions'], score=row['scoredMs']/1000,
    time=row['budget']['activeTimeMs']/1000, contacts=row['preparedReceives'],
    translate=row['preparations']['translate'], reorder=row['preparations']['reorder'],
    revalidated=row['currentReacquisitions'], boundary=row['officialReceiveScores']) for row in rows)
readme = f'''# COLM — continuité des préparations et réception exécutée

Le 27 novembre 2026, deux sessions SIC distinctes, chacune depuis le niveau 1 avec un seul worker, ont gagné les six niveaux de COLM en **103 commandes** sur la source figée `{summary['sourceCommit']}`. Le premier passage applique les plafonds chronométriques historiques ; le second enregistre les tickets natifs et les réacquisitions. Leur empreinte des commandes et retours publics est identique : `{strict['trace']}`. Les deux manifestes confirment une source propre et inchangée avant/après.

## Résultat strict et préparations avant réception

| Niveau | Commandes/plafond | Score/plafond (s) | Réceptions après préparation continue | Translations préparatoires | Réordonnancements préparatoires | Réacquisitions courantes + scores officiels |
|---|---:|---:|---:|---:|---:|---:|
{table}

Les **29 séries** exécutent **57 préparations**, puis la commande `receive` déjà connue, dans la même décision. Elles contiennent au plus quatre commandes ; le moteur conserve sa limite générale de seize. Le collecteur mesure **46 décisions**, **103 tickets** et **103 effets**, sans reset ni undo. Les 32 réceptions connues comprennent trois contacts unitaires ; 26 réceptions sont réacquises sur les observations courantes et six terminent un niveau par son score officiel. La toute première expérience qui apprend `receive` reste une acquisition, pas un réemploi inventé. Neuf tickets d'autres familles conservent leurs retours natifs sans fausse attribution à la famille des files.

Les budgets stricts restent **22/34/63/32/69/26 commandes** et **20/24/43/19/43/13 secondes**. `scoredMs` mesure l'arrivée au score, `settlementMs` la clôture ultérieure ; les deux sont conservés dans `summary.json`. Le collecteur utilise le maximum historique de 69 pour collecter les six niveaux, puis le contrat vérifie les plafonds propres à chaque niveau. Cette collecte ne remplace pas le passage strict.

## Ce que le nouveau contrat protège

Le helper partagé `requireExecutedPrefix` garde à l'identique les assertions LKEY : chaque ticket possède un seul retour de même plan et index, les retours intermédiaires sont confirmés et ouverts, puis une seule réconciliation couvre exactement les commandes exécutées. COLM l'applique aussi à ses retours.

Le contrôle COLM lie les rôles connus avant la commande à leurs preuves, l'action au ticket, les observations aux empreintes des effets physiques et les retours successifs à la même série. Chaque préparation doit produire un changement physique confirmé ; le dernier geste doit être une réception. Une réception ordinaire exige une réacquisition du rôle sur les deux observations exactes et l'époque courante. Une réception qui gagne exige son retour natif `official_boundary` et le score correspondant ; une réacquisition antérieure n'est pas présentée comme une preuve nouvelle.

Les seuils par niveau sont les couples **préparations/réceptions préparées** observés : **7/4, 11/5, 9/5, 13/6, 7/3, 10/6**. Comme les contrats de continuité existants, leur minimum est proportionnel au nombre de commandes du niveau, arrondi vers le haut par rapport au témoin **17,17,20,23,10,16**. Seules les séries terminées par une réception qualifiée contribuent ; de la marche ailleurs ne compense pas leur disparition. Les seuils des 14 jeux et 84 niveaux précédents restent inchangés.

Les contre-épreuves conservent les commandes publiques gagnantes puis retirent une propriété : séries découpées, réception omise, rôle inconnu avant le geste, preuve périmée ou mal liée, absence de score natif, substitution par une autre famille, pixels inchangés, contradiction, clôture prématurée, réconciliation doublée et départ hors niveau 1. Un cas positif conserve les six scores avec acquisition courante absente, conformément au retour réel de frontière. Les tests natifs de transfert de la correction de production restent dans la CI, avec leurs deux variantes et refus.

## Sources et validation

- Source réelle des deux passages : `{summary['sourceCommit']}`, arbre `{summary['sourceTree']}`.
- Bruts stricts SHA-256 : `{summary['strictResultSha256']}`.
- Bruts du collecteur SHA-256 : `{summary['collectorResultSha256']}`.
- La calibration et ses tests sont postérieurs aux deux captures ; leurs empreintes de fichiers figurent dans `summary.json`. Aucun code de production n'a changé après la source exécutée.
- Tests ciblés et typecheck : voir `validation` dans `summary.json` et les journaux complets dans l'archive.
- Le contrôle complet devient **15 jeux, 90 niveaux, 13 cohortes**. La CI rejoue chaque cohorte depuis le niveau 1 avec un worker, lie les artefacts au même SHA, puis exécute l'agrégateur obligatoire `Executed series and final reconciliation`.

L'archive conserve les résultats complets, la progression du strict, les manifestes avant/après, les journaux, la commande reproductible, les validations et un manifeste interne SHA-256 de chaque membre. Elle est reproductible (ordre fixe, dates et propriétaires normalisés). Les premières captures de perte, deux corrections génériques et tests de transfert sont déjà sauvegardés dans `../sic-queue-control-and-contact-20261127/`.

Le passage global des 90 niveaux sur le SHA final et le rejeu COLM dans le Site livré restent des contrôles d'intégration/publication distincts. Cette archive qualifie les deux sessions exécutées et le contrat local ; elle n'annonce pas ces deux contrôles ultérieurs comme terminés.

Archive : `public-evidence.tar.gz`, **{len(archive):,} octets**, SHA-256 `{sha256(archive)}`.
'''
(out / 'README.md').write_text(readme)
print(json.dumps({'archive': str(out), 'bytes': len(archive), 'sha256': sha256(archive),
                  'commands': summary['commands'], 'preparedReceives': summary['preparedReceives'],
                  'continued': summary['continued']}, indent=2))
