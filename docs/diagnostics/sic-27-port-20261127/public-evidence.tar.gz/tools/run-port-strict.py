"""Strict qualification on one frozen source with original per-level budgets."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

root = Path('/workspace/scratch/082336907086/sic-27-work/passage')
work = root.parent
expected = '1f5f03f08e36ba0f375ebaaa9398bee770bcf485'
git = lambda *args: subprocess.check_output(['git', *args], cwd=root, text=True).strip()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
files = ['src/sic/paired-passage.ts', 'tests/helpers/sic-paired-passage-room.ts',
         'tests/sic-paired-passage-continuity.test.ts', 'src/sic/standalone-families.ts',
         'src/sic/experiment-selection-groups.ts', 'src/logos-engine/v6-native-runtime.ts',
         'src/runtime/v6-agent-service.ts', 'scripts/check-sic-chronological.mjs',
         'scripts/compare-source100.mjs', 'scripts/sic-continuity-evidence.mjs',
         'scripts/verify-sic-continuity.mjs', 'scripts/sic-replay-budgets.mjs',
         'docs/architecture/sic-replay-reference-levels-20261126.json',
         'docs/architecture/sic-v8-level6-campaign-7bb9f152.json']
assert git('rev-parse', 'HEAD') == expected
assert not git('status', '--porcelain')

for phase, name in [('strict', 'port-strict-1f5f03f0')]:
    out = work / name
    assert not out.exists(), 'A separate run requires a separate immutable directory'
    out.mkdir()
    settings = {'SIC_REPLAY_REFERENCES': 'docs/architecture/sic-replay-reference-levels-20261126.json'} if phase == 'strict' else {
        'SIC_STUDY_CONTINUITY': '1', 'SIC_STUDY_WORKERS': '1', 'SIC_STUDY_SOLVER': 'sic',
        'SIC_STUDY_RECORD_COMMANDS': '1', 'SIC_STUDY_PROGRESS': '1'}
    command = ['node', 'scripts/check-sic-chronological.mjs', 'PORT', '6', str(out / 'results.jsonl'), '1', 'sic'] if phase == 'strict' else [
        'node', 'scripts/compare-source100.mjs', '.', '.', str(out / 'results.jsonl'), 'source:PORT', '1', '6', '69']
    manifest = {'startedAt': now(), 'sourceCommit': expected, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
                'sourceHashes': {name: digest(root / name) for name in files}, 'game': 'PORT', 'startLevel': 1,
                'targetLevels': 6, 'workers': 1, 'phase': phase, 'command': command, 'environment': settings,
                'qualification': 'Strict original per-level budgets' if phase == 'strict' else 'Actual native tickets and reacquired receipt proof; timing qualification is separate',
                'cwd': str(root)}
    (out / 'run-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'phase': phase, 'startedAt': manifest['startedAt'], 'sourceCommit': expected, 'output': str(out)}), flush=True)
    with (out / 'runner.log').open('w') as stream:
        result = subprocess.run(command, cwd=root, env={**os.environ, **settings}, stdout=stream, stderr=subprocess.STDOUT)
    end = {'observedEndAt': now(), 'exitCode': result.returncode, 'sourceCommit': git('rev-parse', 'HEAD'),
           'clean': not git('status', '--porcelain'), 'sourceHashes': {name: digest(root / name) for name in files},
           'resultsSha256': digest(out / 'results.jsonl') if (out / 'results.jsonl').exists() else None}
    end['sourceUnchanged'] = end['sourceCommit'] == expected and end['sourceHashes'] == manifest['sourceHashes'] and end['clean']
    (out / 'run-end.json').write_text(json.dumps(end, indent=2) + '\n')
    assert end['sourceUnchanged'], 'Frozen source changed during qualification'
    assert result.returncode == 0, 'Harness failed'
    verdict = json.loads((out / 'results.jsonl').read_text())
    print(json.dumps({'phase': phase, 'endedAt': end['observedEndAt'], 'levels': verdict.get('levels'),
                      'actions': verdict.get('actions', verdict.get('issued')), 'reason': verdict.get('reason'),
                      'resultsSha256': end['resultsSha256']}), flush=True)
    if phase == 'strict' and (verdict.get('levels') != 6 or verdict.get('reason') != 'target_levels_completed'):
        print('Strict qualification is incomplete; no continuity replay was started.', flush=True)
        sys.exit(0)
