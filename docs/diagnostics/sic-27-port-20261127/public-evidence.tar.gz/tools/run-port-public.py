"""Capture PORT's guarded route decisions from one native L1 session."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

work = Path('/workspace/scratch/082336907086/sic-27-work')
root = work / 'passage'
out = work / 'port-public-51e5bffc'
expected = '51e5bffc9a4670766431633c7b24af094ab5d480'
probe = work / 'probes/passage-family-profile.mjs'
git = lambda *args: subprocess.check_output(['git', *args], cwd=root, text=True).strip()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git('rev-parse', 'HEAD') == expected
assert not git('status', '--porcelain')
assert not out.exists(), 'A diagnostic directory is immutable; choose a new name for another run'
out.mkdir()
files = ['src/sic/paired-passage.ts', 'src/sic/coverage-route.ts', 'src/sic/standalone-families.ts',
         'src/sic/experiment-selection-groups.ts', 'src/logos-engine/v6-native-runtime.ts',
         'src/runtime/v6-agent-service.ts', 'scripts/check-sic-chronological.mjs', 'scripts/sic-replay-budgets.mjs',
         'docs/architecture/sic-replay-reference-levels-20261126.json',
         'docs/architecture/sic-v8-level6-campaign-7bb9f152.json']
environment = {'SIC_REPLAY_REFERENCES': 'docs/architecture/sic-replay-reference-levels-20261126.json',
               'SIC_PASSAGE_PROFILE_DIR': str(out), 'SIC_PASSAGE_PROFILE_EXPECTED_SHA': expected,
               'SIC_PASSAGE_PROFILE_LEVEL': '6'}
command = ['node', '--import', str(probe), 'scripts/check-sic-chronological.mjs',
           'PORT', '6', str(out / 'results.jsonl'), '1', 'sic']
manifest = {'startedAt': now(), 'sourceCommit': expected, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
            'sourceHashes': {name: digest(root / name) for name in files}, 'code': 'PORT',
            'startLevel': 1, 'targetLevels': 6, 'parallelWorkers': 1,
            'command': command, 'environment': environment, 'probeSha256': digest(probe),
            'qualification': 'Passive public diagnostic; original per-level budgets unchanged. Timings include observer overhead.'}
(out / 'run-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(out / 'passage-family-profile.mjs').write_bytes(probe.read_bytes())
print(json.dumps({'startedAt': manifest['startedAt'], 'sourceCommit': expected, 'output': str(out)}), flush=True)
with (out / 'runner.log').open('w') as log:
    result = subprocess.run(command, cwd=root, env={**os.environ, **environment}, stdout=log, stderr=subprocess.STDOUT)
end = {'observedEndAt': now(), 'exitCode': result.returncode, 'sourceCommit': git('rev-parse', 'HEAD'),
       'clean': not git('status', '--porcelain'), 'sourceHashes': {name: digest(root / name) for name in files},
       'resultsSha256': digest(out / 'results.jsonl') if (out / 'results.jsonl').exists() else None}
end['sourceUnchanged'] = end['sourceCommit'] == expected and end['sourceHashes'] == manifest['sourceHashes'] and end['clean']
(out / 'run-end.json').write_text(json.dumps(end, indent=2) + '\n')
assert end['sourceUnchanged'], 'Frozen source changed'
assert result.returncode == 0, 'Harness failed'
verdict = json.loads((out / 'results.jsonl').read_text())
print(json.dumps({'endedAt': end['observedEndAt'], 'levels': verdict.get('levels'),
                  'actions': verdict.get('actions'), 'reason': verdict.get('reason'),
                  'resultsSha256': end['resultsSha256']}), flush=True)
