"""Preserve the public first-loss capture and frozen strict PORT qualification."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

work = Path('/workspace/scratch/082336907086/sic-27-work')
root = work / 'passage'
public = work / 'port-public-51e5bffc'
strict_dir = work / 'port-strict-1f5f03f0'
out = root / 'docs/diagnostics/sic-27-port-20261127'
read = lambda path: json.loads(path.read_text())
sha = lambda value: hashlib.sha256(value).hexdigest()
strict = read(strict_dir / 'results.jsonl')
baseline = next(json.loads(line) for line in (work / 'baseline-results.jsonl').read_text().splitlines()
                if json.loads(line).get('code') == 'PORT')
start, end = read(strict_dir / 'run-manifest.json'), read(strict_dir / 'run-end.json')
assert start['sourceCommit'] == end['sourceCommit'] == '1f5f03f08e36ba0f375ebaaa9398bee770bcf485'
assert end['clean'] and end['sourceUnchanged'] and start['sourceHashes'] == end['sourceHashes']
assert strict['levels'] == 6 and strict['actions'] == 116 and strict['reason'] == 'target_levels_completed'
assert strict['recoveries'] == {'reset': 0, 'undo': 0}
assert end['resultsSha256'] == sha((strict_dir / 'results.jsonl').read_bytes())
assert all(a['prefixHash'] == b['prefixHash'] for a, b in zip(strict['levelStats'][:5], baseline['levelStats'][:5]))
rows = [{key: level[key] for key in ['level', 'actions', 'scoredMs', 'activeMs', 'settlementMs', 'budget', 'prefixHash', 'acquiredRecords']}
        for level in strict['levelStats']]
assert all(row['actions'] <= row['budget']['actions'] and row['scoredMs'] <= row['budget']['activeTimeMs'] for row in rows)
members = {}
for prefix, folder in [('public-diagnostic', public), ('strict', strict_dir)]:
    for file in sorted(folder.iterdir()):
        if file.is_file(): members[prefix + '/' + file.name] = file.read_bytes()
for name in ['port-first-continuity-loss.json', 'port-captured-walking.json', 'port-captured-walking.log',
             'port-native-final.log', 'port-typecheck-final.log']:
    members['validation/' + name] = (work / name).read_bytes()
members['baseline/PORT-4a546a13.json'] = (json.dumps(baseline, indent=2) + '\n').encode()
for name in ['run-port-public.py', 'run-port-strict.py', 'port-captured-walking.mjs', 'archive-port-strict.py']:
    members['tools/' + name] = (work / 'probes' / name).read_bytes()
members['member-manifest.json'] = (json.dumps({name: {'bytes': len(value), 'sha256': sha(value)}
    for name, value in sorted(members.items())}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as tar:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(data), 0o644
        info.mtime = info.uid = info.gid = 0
        tar.addfile(info, io.BytesIO(data))
archive = gzip.compress(buffer.getvalue(), mtime=0)
out.mkdir(parents=True, exist_ok=True)
(out / 'public-evidence.tar.gz').write_bytes(archive)
summary = {'schema': 'sic.passage-continuity-strict.v1', 'game': 'PORT', 'sourceCommit': start['sourceCommit'],
    'sourceTree': start['sourceTree'], 'sourceHashes': start['sourceHashes'], 'sourceUnchangedDuringRun': True,
    'strictResultSha256': end['resultsSha256'], 'publicTrajectorySha256': strict['trace'],
    'levelsWon': 6, 'commands': 116, 'acquiredRecords': rows[-1]['acquiredRecords'], 'reset': 0, 'undo': 0,
    'initialFivePublicPrefixesIdenticalToCampaign': True, 'perLevel': rows,
    'firstLoss': read(work / 'port-first-continuity-loss.json')['firstLostPrefix'],
    'validation': {'nativeTests': 11, 'nativeTestsPassed': 11, 'nativeTestExitCode': 0, 'typecheckExitCode': 0,
                   'capturedActualReturnsChecked': 3, 'capturedReturnProbeExitCode': 0},
    'limitations': ['The diagnostic capture includes instrumentation overhead and is not a timing comparison.',
        'The executed-ticket collector and PORT gate contract remain a separate integration check.',
        'The full continuity gate and the published Site replay remain to be run on the final integration.'],
    'archive': {'file': 'public-evidence.tar.gz', 'bytes': len(archive), 'sha256': sha(archive)}}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
table = '\n'.join(f"| {r['level']} | {r['actions']}/{r['budget']['actions']} | {r['scoredMs']/1000:.3f}/{r['budget']['activeTimeMs']/1000:.0f} | {r['settlementMs']/1000:.3f} |"
                  for r in rows)
(out / 'README.md').write_text(f'''# PORT — marche connue entre les passages

Le 27 novembre 2026, une session SIC depuis le niveau 1 gagne les **six niveaux en 116 commandes**, sans reset ni undo, sur la source propre et figée `{start['sourceCommit']}`. Le niveau 6 marque le score en **8,691 secondes**, sous son plafond inchangé de 12 secondes. Les 116 effets ont été acquis.

## Qualification chronométrique

| Niveau | Commandes/plafond | Score/plafond (s) | Réconciliation après score (s) |
|---|---:|---:|---:|
{table}

Les budgets historiques restent **21/23/32/22/22/21 commandes** et **12/15/20/15/14/12 secondes**. Le score public et la réconciliation sont conservés séparément. Les cinq empreintes de préfixe des commandes et retours L1–5 sont strictement identiques à celles de la campagne `{baseline.get('sourceCommit', '4a546a139f9064422c078ef5f40b8c22133c39a8')}`. Le parcours gagnant complet porte l'empreinte `{strict['trace']}`. Le témoin de cette campagne s'arrêtait au niveau 6 après 16 commandes sous 12 secondes.

## Première continuité perdue et correction

La capture publique sur `51e5bffc9a4670766431633c7b24af094ab5d480` reproduit les cinq mêmes préfixes gagnants et l'arrêt au niveau 6. Dès sa troisième décision, le propriétaire calcule une route de quatre gestes : trois marches déjà justifiées, puis un contact. Il n'en expose qu'un. Le filtre excluait toute scène de passages à motifs ou d'interrupteurs, même pour la portion de marche précédant le prochain contact.

La correction expose uniquement cette marche connue. Elle coupe le préfixe avant le premier passage ou interrupteur, conserve la limite de seize et le budget restant, puis remesure l'acteur, les ouvertures, leurs partenaires, les indicateurs, les sorties, le sol et les commandes avant chaque continuation. Les contacts restent unitaires et l'acquisition traite chaque retour exécuté dans l'ordre. Les comparaisons de géométrie utilisent les valeurs normalisées, y compris celles du but, afin de rester équivalentes après restauration.

La capture initiale est instrumentée : ses durées ne servent pas à annoncer un pourcentage d'accélération. Un probe hors jeu repropose la décision originale avec le correctif, puis valide les trois gardes et les trois retours publics réellement capturés (`ACTION2`, `ACTION2`, `ACTION4`). Le quatrième geste de contact reste séparé et un budget restant de deux borne la proposition à deux.

## Transferts et refus

Les **11 tests ciblés passent**, ainsi que le typecheck. Deux simulateurs raster natifs apprennent les passages sur trois niveaux successifs. Le second change la taille, les positions par réflexion, les couleurs et le sens des commandes. Tous deux observent les sorties, réemploient deux marches dans la même décision, exécutent ensuite l'interrupteur seul et gagnent les trois niveaux.

Les contre-épreuves changent l'acteur, un indicateur, une sortie, un interrupteur ou la disponibilité d'une commande ; elles ferment le préfixe après le seul geste exécuté. Un déplacement contredit produit son retour `matched=false`, sans effacer les preuves précédentes. Sans témoin appris des passages et sorties, la scène à motifs n'est pas admise.

## Sources conservées et contrôles suivants

L'archive contient la capture publique complète, ses manifestes, le diagnostic de première perte, les vrais retours reproposés, le strict et ses préfixes, les journaux de tests/typecheck, le témoin extrait de la campagne, les commandes reproductibles et un manifeste SHA-256 de chaque membre. Les manifestes du strict confirment le même SHA, les mêmes empreintes et un checkout propre avant et après.

Le collecteur de tickets exécutés, son contrat PORT, le gate complet sur l'intégration finale et le rejeu dans le Site livré sont des contrôles ultérieurs distincts ; cette archive n'annonce pas leur achèvement.

Archive : `public-evidence.tar.gz`, **{len(archive):,} octets**, SHA-256 `{sha(archive)}`.
''')
print(json.dumps({'archive': str(out), 'bytes': len(archive), 'sha256': sha(archive)}, indent=2))
