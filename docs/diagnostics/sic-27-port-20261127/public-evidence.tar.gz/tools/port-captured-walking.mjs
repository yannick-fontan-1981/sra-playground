// Re-evaluate a captured public decision without starting or advancing a game.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const work = '/workspace/scratch/082336907086/sic-27-work';
const file = resolve(work, 'port-public-51e5bffc/passage-family-36.jsonl');
const records = readFileSync(file, 'utf8').trim().split('\n').map(JSON.parse);
const { createSicPairedPassage } = await import(pathToFileURL(resolve('src/sic/paired-passage.ts')));
const decode = rows => rows.map(row => {
  const result = [];
  for (let i = 0; i < row.length; i += 2) result.push(...Array(row[i + 1]).fill(row[i]));
  return result;
});
const calls = records.filter(record => record.kind === 'family-call' && record.family === 'sic_paired_passage'
  && record.method === 'propose');
const first = calls.find(record => record.levelActions === 2);
const original = records.find(record => record.kind === 'family-return' && record.call === first.call).proposal;
assert.equal(original.actions.length, 1);
assert.equal(original.route.steps.length, 4);
const family = createSicPairedPassage();
family.restore(first.stateBefore);
const proposal = await family.propose(first.observation, decode(first.publicRowsRle), first.inputs, first.remaining,
  { ...first.execution, deadlineMs: Infinity });
assert.ok(proposal);
assert.equal(proposal.actions.length, 3);
assert.ok(proposal.route.steps.slice(0, 3).every(step => !step.crossing));
assert.ok(proposal.route.steps[3].crossing);
const steps = [];
for (let index = 0; index < proposal.actions.length; index++) {
  const before = calls.find(record => record.levelActions === 2 + index);
  const after = calls.find(record => record.levelActions === 3 + index);
  const firstRows = decode(before.publicRowsRle), secondRows = decode(after.publicRowsRle);
  const actual = records.find(record => record.kind === 'command-applied' && record.levelActions === 3 + index);
  assert.equal('ACTION' + actual.command.id, proposal.actions[index].action_ref);
  const admitted = family.before(proposal, index, { frame_rows: firstRows }, before.observation);
  assert.equal(admitted.admitted, true);
  const outcome = family.after(proposal, index, before.observation, after.observation, firstRows, secondRows);
  assert.equal(outcome.matched, true);
  assert.equal(outcome.seal_prefix, index === proposal.actions.length - 1);
  steps.push({ index, action: proposal.actions[index].action_ref, before: before.observation.observation_ref,
    after: after.observation.observation_ref, admitted, outcome });
}
const limited = await family.propose(first.observation, decode(first.publicRowsRle), first.inputs, 2,
  { ...first.execution, deadlineMs: Infinity });
assert.equal(limited.actions.length, 2);
const report = { schema: 'sic.passage-captured-walk.v1', sourceCapture: '51e5bffc9a4670766431633c7b24af094ab5d480',
  level: 6, decisionAfterCommands: 2, originalExposed: 1, candidateExposed: proposal.actions.length,
  remainingBudgetCheck: limited.actions.length, contactKeptSeparate: true, steps };
writeFileSync(resolve(work, 'port-captured-walking.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
