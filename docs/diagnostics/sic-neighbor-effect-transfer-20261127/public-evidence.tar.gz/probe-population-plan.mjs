import { readFile } from 'node:fs/promises';
import { stripTypeScriptTypes } from 'node:module';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const root=process.cwd(), base=pathToFileURL(resolve('src/sic/population-placement.ts'));
let source=await readFile(base,'utf8');
source=source.replace(/from (['"])([^'"]+)\1/g,(_,quote,path)=>`from ${quote}${new URL(path,base).href}${quote}`);
source+='\nexport { planSupport, planInMeasuredZone, orderReferencePlacements };';
const module=await import('data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(source)).toString('base64'));
const {measureReferencePopulation}=await import(pathToFileURL(resolve('src/logos-engine/v6-reference-population-observation.ts')));
const {readPopulationZones,populationZoneTargets}=await import(pathToFileURL(resolve('src/sic/population-zones.ts')));
const document=JSON.parse(await readFile('/workspace/scratch/082336907086/sic-27-work/vois-l6-public-fe822410.json','utf8'));
const event=document.publicEvidence[125], saved=event.populationFamilies.sic_learn_reference_placement;
const rows=event.publicBefore.frame, scene=measureReferencePopulation(rows,null,{allowSurplus:true});
const local={epoch:event.nativeObservation.level_epoch,scene,selection:null,active:false,controls:saved.witness.controls,tried:[],evidence:saved.witness.evidence,frame:event.nativeObservation.frame_hash,stopped:false,neighborhood:saved.witness.neighborhood};
const zones=readPopulationZones(rows,scene), start=performance.now();
const candidates=[...populationZoneTargets(scene.target,zones)].map(({positions,zone})=>{
 const next={...scene,target:positions,zone_box:zone.box,comparisonCells:zone.cells};
 const before=performance.now();
 const support=module.planSupport({...local,scene:next},local.controls,performance.now()+300,true);
 const retained=module.planSupport({...local,scene:next,neighborEffectRef:saved.state.neighborEffectRef},local.controls,performance.now()+300,true);
 return {zone:zone.box,cells:zone.cells,target:positions,support,supportMs:performance.now()-before,
  observedNeighborEffect:saved.state.neighborEffectRef,
  retainedEffectPlan:retained?{support:retained.support,orderedLength:retained.ordered.length,first:retained.ordered[0]}:null};
});
console.log(JSON.stringify({source:document.source,index:event.index,observation:event.nativeObservation.observation_ref,scene,zones,candidates,totalMs:performance.now()-start},null,2));
