import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const load = p => import(pathToFileURL(resolve(p)));
const [{ createSicVerifyOrderedFeedback }, { NativeKnowledgeStore }, { initialFeedbackLayout }] = await Promise.all([
  load('src/sic/feedback-trial.ts'), load('src/logos-engine/v6-knowledge-store.ts'), load('src/logos-engine/v6-feedback-sequences-visual.ts'),
]);
const records = readFileSync(process.argv[2] ?? '/workspace/scratch/082336907086/sic-27-work/mind-profile-ee9dad5f/mind-family-13.jsonl', 'utf8').trim().split('\n').map(JSON.parse);
const captured = records.find(r => r.kind === 'admission-input' && r.planNumber === 1);
const raw = captured.familyStates.find(f => f.id === 'sic_verify_ordered_feedback').state;
const rows = captured.publicRowsRle.map(row => row.flatMap((value, index) => index % 2 === 0 ? Array(row[index + 1]).fill(value) : []));
const family = createSicVerifyOrderedFeedback();
family.restore(raw);
await family.attachPrograms(new NativeKnowledgeStore('captured-public-entry', 'captured-public-entry'));
const result = await family.proposeInGroup('reuse_observed_mechanics', captured.observation, rows, captured.inputs, 20,
  { yieldControl: async () => {}, reasoningMode: 'assimilation' });
const firstCalls = records.filter(r => r.kind === 'family-call' && r.planNumber === 1).map(r => ({family:r.family,method:r.method,groups:r.groups}));
const out = { observationRef: captured.observation.observation_ref, sourceState: raw, currentLayout: initialFeedbackLayout(captured.observation),
  proposed: result !== null, actions: result?.actions, local: result?.local, before: result ? family.before(result, 0, {}, captured.observation) : null,
  strategy: result?.sicSituationCard?.strategy, choice: result?.choice, route_refs: result?.route_refs, actualFirstCalls: firstCalls,
  limitation: 'Pure re-proposal from the recorded public observation and acquired family state, not a game replay or full-runtime checkpoint.' };
writeFileSync(process.argv[3] ?? '/workspace/scratch/082336907086/sic-27-work/mind-candidate-a53189de/captured-entry.json', JSON.stringify(out, null, 2) + '\n');
console.log(JSON.stringify({ proposed: out.proposed, before: out.before, actions: out.actions, strategy: out.strategy, active: out.local?.active,
  submission: out.local?.submission, actualFirstCalls: firstCalls }, null, 2));
