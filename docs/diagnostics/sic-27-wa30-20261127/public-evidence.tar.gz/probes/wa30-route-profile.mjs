// Diagnostic preload only. No solver inputs, limits, decisions, or signal handlers are changed.
// Run from a frozen checkout; --import is inherited by the chronological runner's child.
import { appendFileSync, mkdirSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

if (process.env.SIC_REPLAY_CHILD === '1' && typeof process.send === 'function') {
  const directory = process.env.SIC_ROUTE_PROFILE_DIR;
  if (!directory) throw new Error('SIC_ROUTE_PROFILE_DIR is required for this diagnostic preload');
  const tag = process.env.SIC_ROUTE_PROFILE_TAG ?? 'wa30-baseline';
  if (!/^[a-zA-Z0-9_.-]+$/.test(tag)) throw new Error('Invalid diagnostic tag');
  const sourceCommit = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  if (process.env.SIC_ROUTE_PROFILE_EXPECTED_SHA && sourceCommit !== process.env.SIC_ROUTE_PROFILE_EXPECTED_SHA)
    throw new Error('The frozen diagnostic source commit changed');
  const detailedLevel = Number(process.env.SIC_ROUTE_PROFILE_LEVEL ?? 8);
  if (!Number.isSafeInteger(detailedLevel) || detailedLevel < 1) throw new Error('Invalid diagnostic level');
  mkdirSync(directory, { recursive: true });
  const output = resolve(directory, `${tag}-${process.pid}.jsonl`);
  const origin = performance.now();
  let activeLevel = 0, levelActions = 0, completedServices = 0, logError = false;
  const metrics = new Map(), wrapped = new WeakMap(), observedFamilies = new WeakSet();
  const io = { writes: 0, ms: 0 };
  const rounded = value => Math.round(value * 1000) / 1000;
  function emit(record) {
    const started = performance.now();
    try {
      appendFileSync(output, JSON.stringify({ atMs: rounded(started - origin), activeLevel, ...record }) + '\n');
      io.writes++;
    } catch (error) {
      if (!logError) process.stderr.write(`SIC diagnostic output unavailable: ${String(error)}\n`);
      logError = true;
    } finally { io.ms += performance.now() - started; }
  }
  function account(level, name, elapsed) {
    const values = metrics.get(level) ?? new Map();
    const stat = values.get(name) ?? { count: 0, ms: 0, maxMs: 0 };
    stat.count++; stat.ms += elapsed; stat.maxMs = Math.max(stat.maxMs, elapsed);
    values.set(name, stat); metrics.set(level, values);
  }
  function snapshot(kind, level = activeLevel) {
    const stats = Object.fromEntries([...(metrics.get(level) ?? [])].filter(([, stat]) => stat.ms >= 0.5)
      .sort((a, b) => b[1].ms - a[1].ms)
      .map(([name, stat]) => [name, { count: stat.count, ms: rounded(stat.ms), maxMs: rounded(stat.maxMs) }]));
    emit({ kind, level, levelActions, completedServices, stats, io: { writes: io.writes, ms: rounded(io.ms) },
      accounting: 'Inclusive durations overlap; absent sub-0.5ms buckets do not imply zero calls.' });
  }
  function safely(callback) {
    try { callback(); } catch (error) { emit({ kind: 'observer-error', message: String(error) }); }
  }
  function wrap(target, key, name, hook) {
    if (!target || typeof target[key] !== 'function') return;
    const keys = wrapped.get(target) ?? new Set();
    if (keys.has(key)) return;
    const original = target[key];
    const replacement = function (...args) {
      const level = activeLevel, started = performance.now();
      const label = typeof name === 'function' ? name(args) : name;
      const done = value => {
        account(level, label, performance.now() - started);
        if (hook) safely(() => hook.call(this, value, args, level));
        return value;
      };
      const failed = error => { account(level, label, performance.now() - started); throw error; };
      let result;
      try { result = Reflect.apply(original, this, args); } catch (error) { return failed(error); }
      return result && typeof result.then === 'function' ? result.then(done, failed) : done(result);
    };
    if (Reflect.set(target, key, replacement)) { keys.add(key); wrapped.set(target, keys); }
    else emit({ kind: 'unwrapped-method', method: key, name: String(name) });
  }
  function rle(rows) {
    return rows?.map(row => {
      const encoded = [];
      for (const ink of row) {
        if (encoded.length && encoded[encoded.length - 2] === ink) encoded[encoded.length - 1]++;
        else encoded.push(ink, 1);
      }
      return encoded;
    });
  }
  function instrumentFamilies(runtime) {
    for (const family of runtime.families ?? []) {
      if (observedFamilies.has(family)) continue;
      observedFamilies.add(family);
      for (const method of ['propose', 'proposeForGroup', 'record', 'state', 'nativeState', 'restore', 'restoreNative'])
        wrap(family, method, `family.${family.id}.${method}`);
      for (const method of ['before', 'after']) wrap(family, method, `family.${family.id}.${method}`,
        function (value, args, level) {
          if (level !== detailedLevel || !family.id.includes('oriented_delivery')) return;
          const [proposal, index] = args;
          emit({ kind: 'route-guard', method, family: family.id, index, result: value,
            binding: proposal?.binding, walkLength: proposal?.walk?.length ?? 0, parallel: !!proposal?.local?.parallel });
        });
    }
  }
  const originalSend = process.send;
  process.send = function (message, ...args) {
    safely(() => {
      if (message?.kind === 'level-started') {
        activeLevel = message.level; levelActions = 0; completedServices = 0;
        emit({ kind: 'level-started', target: message.target, budget: message.budget });
      } else if (message?.kind === 'command-applied') {
        levelActions++;
        if (activeLevel === detailedLevel) {
          emit({ kind: 'command-applied', levelActions, command: message.command, levelsCompleted: message.levelsCompleted });
          if (levelActions % 8 === 0) snapshot('partial-costs-before-current-acquisition');
        }
      } else if (message?.kind === 'level-finished') {
        emit({ kind: 'level-finished', level: message.level }); snapshot('level-costs');
      } else if (message?.kind === 'result') {
        emit({ kind: 'result', code: message.result?.code, status: message.result?.status, reason: message.result?.reason,
          levels: message.result?.levels, actions: message.result?.actions }); snapshot('result-costs');
      }
    });
    return Reflect.apply(originalSend, this, [message, ...args]);
  };
  const load = file => import(pathToFileURL(resolve(file)));
  const [{ NativeV6Runtime }, { NativeKnowledgeStore }, { V6AgentService }] = await Promise.all([
    load('src/logos-engine/v6-native-runtime.ts'), load('src/logos-engine/v6-knowledge-store.ts'), load('src/runtime/v6-agent-service.ts'),
  ]);
  const sourceFiles = ['src/sic/oriented-delivery.ts', 'src/logos-engine/v6-native-runtime.ts',
    'src/logos-engine/v6-knowledge-store.ts', 'src/runtime/v6-agent-service.ts', 'scripts/sic-replay-budgets.mjs'];
  emit({ kind: 'profile-start', sourceCommit, code: process.argv[2], detailedLevel, pid: process.pid,
    sourceHashes: Object.fromEntries(sourceFiles.map(file => [file, createHash('sha256').update(readFileSync(resolve(file))).digest('hex')])),
    note: 'Diagnostic wrappers only. No SIGTERM handler: the original watchdog terminates the child normally.' });
  wrap(NativeV6Runtime.prototype, 'plan', 'runtime.plan', function (_, _args, level) {
    if (level !== detailedLevel) return;
    const prefix = this.prefix, proposal = prefix?.proposal;
    if (!proposal || !prefix.family.id.includes('oriented_delivery')) return;
    const local = proposal.local;
    emit({ kind: 'oriented-plan', revision: this.revision, totalActions: this.actions, family: prefix.family.id,
      actions: proposal.actions, walkLength: proposal.walk?.length ?? 0, peerGuard: proposal.peerGuard ?? null,
      step: proposal.step, scene: proposal.scene, local: { count: local.count, held: local.held, color: local.color,
        free: local.free, loaded: local.loaded, geometry: local.geometry, sharedEvidence: local.sharedEvidence,
        interference: local.interference, transportCarriers: local.transportCarriers, transports: local.transports,
        parallel: local.parallel ? { ink: local.parallel.ink, track: local.parallel.track, approach: local.parallel.approach,
          learnedReturns: Object.keys(local.parallel.returns).length, probedWorlds: Object.keys(local.parallel.probes).length } : null },
      binding: proposal.binding, publicFrame: { level: this.current?.level, levelsCompleted: this.current?.levels_completed,
        frameHash: this.current?.frame_hash, rowsRle: rle(this.current?.frame_rows) } });
  });
  const wrappedPlan = NativeV6Runtime.prototype.plan;
  NativeV6Runtime.prototype.plan = function (...args) {
    safely(() => instrumentFamilies(this));
    return Reflect.apply(wrappedPlan, this, args);
  };
  for (const method of ['seal', 'restoreFamilies', 'selectAdmittedFamily', 'authorize'])
    wrap(NativeV6Runtime.prototype, method, `runtime.${method}`);
  wrap(NativeV6Runtime.prototype, 'persistFamilies', args => `runtime.persistFamilies.${args[0]?.statement ?? 'unknown'}`);
  wrap(NativeKnowledgeStore.prototype, 'commit', args => `knowledge.commit.${args[1]?.statement ?? 'unknown'}`);
  wrap(NativeKnowledgeStore.prototype, 'stateValue', 'knowledge.stateValue');
  const originalExecution = V6AgentService.prototype.execution;
  V6AgentService.prototype.execution = function (...args) {
    const execution = Reflect.apply(originalExecution, this, args);
    wrap(execution, 'yieldControl', 'scheduler.yieldControl');
    return execution;
  };
  wrap(V6AgentService.prototype, 'handle', args => `service.${args[0]?.type ?? 'unknown'}`, function (_, args, level) {
    completedServices++;
    if (level === detailedLevel && args[0]?.type === 'advance') {
      const observed = args[0].observation;
      emit({ kind: 'public-return-acquired', levelActions, publicReturn: { level: observed?.level,
        levelsCompleted: observed?.levelsCompleted, state: observed?.state, rowsRle: rle(observed?.frame),
        framesRle: observed?.frames?.map(rle) } });
      if (levelActions % 8 === 0) snapshot('partial-costs-after-acquisition');
    }
  });
}
