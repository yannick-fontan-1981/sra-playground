// Offline comparison of captured public frames; this script never loads a game.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = resolve(process.argv[2] ?? '../routes');
const source = resolve(process.argv[3] ?? '../wa30-profile-baseline/wa30-baseline-13.jsonl');
const records = readFileSync(source, 'utf8').trim().split('\n').map(line => JSON.parse(line));
async function diagnose(totalActions, compact = false) {
const captured = records.find(row => row.kind === 'oriented-plan' && row.totalActions === totalActions);
const returned = records.find(row => row.kind === 'public-return-acquired' && row.levelActions === totalActions - 411);
assert.ok(captured && returned);
const unpack = rows => rows.map(row => row.flatMap((value, i) => i % 2 ? [] : Array(row[i + 1]).fill(value)));
const first = unpack(captured.publicFrame.rowsRle), second = unpack(returned.publicReturn.rowsRle);
const load = file => import(pathToFileURL(resolve(root, file)));
const [{ createSicVerifyOrientedDelivery }, { measureNativeObservation }, { orientedCouplingScene }] = await Promise.all([
  load('src/sic/oriented-delivery.ts'), load('src/logos-engine/v6-native-observer.ts'), load('src/logos-engine/v6-oriented-coupling.ts'),
]);
const packet = (rows, hash) => ({ frame_rows: rows, frame_hash: hash, state: 'NOT_FINISHED', level: 8,
  levels_completed: 7, available_action_refs: ['ACTION1', 'ACTION2', 'ACTION3', 'ACTION4', 'ACTION5'] });
const before = await measureNativeObservation(packet(first, captured.publicFrame.frameHash), 474, 'captured-wa30');
const after = await measureNativeObservation(packet(second, 'captured-return-62'), 475, 'captured-wa30');
const family = createSicVerifyOrientedDelivery();
await family.attachPrograms({ registerProgram: async () => ({ run: async ({ situation }) =>
  ({ result: situation.routeSupported ? 'P07' : situation.knownInteraction ? 'P02' : 'P05', receipt: {} }) }) });
// The capture retained every planning/guard field used after the forms disappear.
// Reference arrays and interception history were not captured; they cannot affect
// this non-intercepting plan. Do not describe this as a full runtime restoration.
family.restore({ state: { ...captured.local, epoch: 8, invitation: null, tried: [], refs: [before.observation_ref],
  parallel: { ...captured.local.parallel, ref: 'captured-interception-context', returns: {}, probes: {}, waits: {} } } });
const proposal = await family.propose(before, first, packet(first, '').available_action_refs.map(action_ref => ({ action_ref, data: {} })), 105);
assert.ok(proposal);
assert.deepEqual(proposal.step, captured.step, 'The captured planning input must reproduce the exact same route');
const guardBefore = await family.before(proposal, 0, packet(first, captured.publicFrame.frameHash), before);
const guardAfter = await family.after(proposal, 0, before, after, first, second);
const { geometry, color } = proposal.local;
const old = orientedCouplingScene(first, geometry, color), next = orientedCouplingScene(second, geometry, color);
const carriers = observation => {
  const groups = {};
  for (const part of observation.entities) {
    const [x, y, r, b] = part.bbox;
    if (part.area !== geometry.pitch ** 2 || r - x + 1 !== geometry.pitch || b - y + 1 !== geometry.pitch
      || [geometry.background, geometry.core, color].includes(part.palette_value)
      || (x - geometry.phase[0]) % geometry.pitch || (y - geometry.phase[1]) % geometry.pitch) continue;
    (groups[part.signature] ??= []).push([(x - geometry.phase[0]) / geometry.pitch, (y - geometry.phase[1]) / geometry.pitch]);
  }
  return groups;
};
const origins = carriers(before), destinations = carriers(after);
const distance = (a, b) => Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]);
const matching = Object.entries(origins).map(([signature, sites]) => ({ signature,
  learned: proposal.local.transportCarriers.includes(signature), origins: sites, destinations: destinations[signature],
  candidateCounts: sites.map(site => destinations[signature]?.filter(target => distance(site, target) <= 1).length ?? 0),
  reverseCounts: destinations[signature]?.map(site => sites.filter(origin => distance(site, origin) <= 1).length),
}));
// Diagnostic counterfactual ONLY: the existing sector gate enables the identical
// spatial matching procedure. No command is executed and no state is persisted.
const existingMatchingEnabled = structuredClone(proposal);
existingMatchingEnabled.local.sectorNetwork = { localTargets: [geometry.targets[0]] };
const guardWithExistingMatching = await family.after(existingMatchingEnabled, 0, before, after, first, second);
const result = { reproducedRoute: proposal.step.route, actions: proposal.actions, walkLength: proposal.walk?.length,
  peerGuard: proposal.peerGuard, guardBefore, guardAfter, guardWithExistingMatching,
  ownBefore: old.pose, ownAfter: next.pose, boxesBefore: old.boxes, boxesAfter: next.boxes, matching,
  limitation: 'Observed planning/guard inputs reconstructed, not a complete runtime checkpoint; no game execution.' };
return compact ? { command: totalActions - 411, actions: proposal.actions.length, walkLength: proposal.walk?.length ?? 0,
  before: guardBefore, after: guardAfter, afterExistingMatching: guardWithExistingMatching,
  protectedChanges: proposal.peerGuard?.protectedCells.filter(point => old.boxes[point.join(',')] !== next.boxes[point.join(',')]) ?? [],
  shellChanges: Object.entries(old.boxes).flatMap(([site, value]) => next.boxes[site] !== undefined && next.boxes[site] !== value
    ? [{ site, from: value, to: next.boxes[site], protected: proposal.peerGuard?.protectedCells.some(point => point.join(',') === site) ?? false }] : []),
  removed: Object.keys(old.boxes).filter(site => !Object.hasOwn(next.boxes, site)),
  added: Object.keys(next.boxes).filter(site => !Object.hasOwn(old.boxes, site)), matching } : result;
}
if (process.argv[4] === '--all') {
  const summaries = [];
  for (const row of records.filter(row => row.kind === 'oriented-plan' && row.totalActions >= 473 && row.totalActions < 511))
    summaries.push(await diagnose(row.totalActions, true));
  console.log(JSON.stringify(summaries, null, 2));
} else console.log(JSON.stringify(await diagnose(473), null, 2));
