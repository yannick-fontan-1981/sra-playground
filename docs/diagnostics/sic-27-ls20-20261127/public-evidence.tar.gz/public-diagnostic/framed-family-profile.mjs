// Read-only diagnostic preload. No game, action, budget or signal handling changes.
import { appendFileSync, mkdirSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

if (process.env.SIC_REPLAY_CHILD === '1' && typeof process.send === 'function') {
  const outputDir = process.env.SIC_FRAMED_PROFILE_DIR;
  if (!outputDir) throw new Error('SIC_FRAMED_PROFILE_DIR is required');
  const sourceCommit = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  if (sourceCommit !== process.env.SIC_FRAMED_PROFILE_EXPECTED_SHA) throw new Error('Frozen diagnostic source changed');
  const levelToCapture = Number(process.env.SIC_FRAMED_PROFILE_LEVEL ?? 6);
  mkdirSync(outputDir, { recursive: true });
  const output = resolve(outputDir, `framed-family-${process.pid}.jsonl`);
  const origin = performance.now();
  let level = 0, levelActions = 0, planNumber = 0, serial = 0, ioMs = 0;
  const wrappedFamilies = new WeakSet();
  const watched = new Set(['sic_framed_contact', 'sic_learn_pattern_access']);
  const maximumCapturedCommands = Number(process.env.SIC_FRAMED_PROFILE_COMMANDS ?? 32);
  let firstInterruption = null, complete = false;
  const round = value => Math.round(value * 1000) / 1000;
  function emit(record) {
    const start = performance.now();
    try { appendFileSync(output, JSON.stringify({ atMs: round(start - origin), level, levelActions, planNumber, ...record }) + '\n'); }
    catch (error) { process.stderr.write(`Diagnostic write failed: ${String(error)}\n`); }
    finally { ioMs += performance.now() - start; }
  }
  function inspect(callback) {
    try { callback(); } catch (error) { emit({ kind: 'observer-error', error: String(error) }); }
  }
  const rle = rows => rows?.map(row => {
    const encoded = [];
    for (const value of row) {
      if (encoded.length && encoded[encoded.length - 2] === value) encoded[encoded.length - 1]++;
      else encoded.push(value, 1);
    }
    return encoded;
  });
  const executionSummary = execution => execution && ({ reasoningMode: execution.reasoningMode,
    remainingLevelActions: execution.remainingLevelActions, deadlineMs: execution.deadlineMs,
    aborted: execution.signal?.aborted, hasPriorDirectionalReader: typeof execution.readPriorDirectionalScene === 'function' });
  function instrumentFamilies(runtime) {
    for (const family of runtime.families ?? []) {
      if (wrappedFamilies.has(family)) continue;
      wrappedFamilies.add(family);
      for (const method of ['propose', 'proposeInGroup', 'proposeInSubquestion']) {
        const original = family[method];
        if (typeof original !== 'function') continue;
        family[method] = function (...args) {
          if (level !== levelToCapture) return Reflect.apply(original, this, args);
          const call = ++serial, offset = method === 'propose' ? 0 : method === 'proposeInGroup' ? 1 : 2;
          const [observation, rows, inputs, remaining, execution] = args.slice(offset);
          inspect(() => emit({ kind: 'family-call', call, family: family.id, method,
            groups: args.slice(0, offset), observationRef: observation?.observation_ref, remaining,
            ...(watched.has(family.id) ? { stateBefore: family.state(), observation,
              publicRowsRle: rle(rows), inputs, execution: executionSummary(execution) } : {}) }));
          const start = performance.now();
          const done = result => {
            const elapsedMs = performance.now() - start;
            inspect(() => emit({ kind: 'family-return', call, family: family.id, method, elapsedMs: round(elapsedMs),
              offered: result !== null && result !== undefined, status: result?.status, actionCount: result?.actions?.length ?? 0,
              strategy: result?.sicSituationCard?.strategy, situation: result?.sicSituationCard?.situation,
              ...(watched.has(family.id) ? { proposal: result, stateAfter: family.state(), workshopSummary: result?.glyphWorkshop && {
                cycleLength: result.glyphWorkshop.local.cycle?.length ?? 0, planned: result.actions?.length,
                retainedWalk: result.glyphWorkshop.step.walk?.length ?? 0, purpose: result.glyphWorkshop.step.purpose,
                at: result.glyphWorkshop.local.at, acquiredGoals: result.glyphWorkshop.local.acquired,
                shapeEffects: result.glyphWorkshop.local.shapes.length, colorEffects: result.glyphWorkshop.local.colors.length,
              } } : {}) }));
            return result;
          };
          const fail = error => { emit({ kind: 'family-error', call, family: family.id, method,
            elapsedMs: round(performance.now() - start), error: String(error) }); throw error; };
          let result;
          try { result = Reflect.apply(original, this, args); } catch (error) { return fail(error); }
          return result && typeof result.then === 'function' ? result.then(done, fail) : done(result);
        };
      }
      for (const method of ['before', 'after']) {
        const original = family[method];
        if (typeof original !== 'function') continue;
        family[method] = function (...args) {
          if (level !== levelToCapture || !watched.has(family.id)) return Reflect.apply(original, this, args);
          const call = ++serial, [proposal, index] = args;
          inspect(() => emit({ kind: 'guard-input', call, family: family.id, method, index, proposal,
            stateBefore: family.state(), ...(method === 'after' ? { before: args[2], after: args[3],
              firstRowsRle: rle(args[4]), secondRowsRle: rle(args[5]) }
              : { observation: args[3], publicRowsRle: rle(args[2]?.frame_rows) }) }));
          const done = result => {
            inspect(() => {
              emit({ kind: 'family-guard', call, family: family.id, method, index,
                observationRef: proposal?.binding?.observation_ref, result });
              if (!firstInterruption && index > 0 && proposal?.glyphWorkshop
                && (method === 'after' ? result?.matched === false : result?.admitted === false)) {
                firstInterruption = { call, method, index, family: family.id, planned: proposal.actions.length,
                  reason: result.reason, levelActions };
              }
            });
            return result;
          };
          const result = Reflect.apply(original, this, args);
          return result && typeof result.then === 'function' ? result.then(done) : done(result);
        };
      }
    }
  }
  const originalSend = process.send;
  process.send = function (message, ...args) {
    inspect(() => {
      if (message?.kind === 'level-started') {
        level = message.level; levelActions = 0; planNumber = 0;
        emit({ kind: 'level-started', budget: message.budget, target: message.target });
      } else if (message?.kind === 'command-applied') {
        levelActions++;
        if (level === levelToCapture) emit({ kind: 'command-applied', command: message.command, levelsCompleted: message.levelsCompleted });
      } else if (message?.kind === 'level-finished') emit({ kind: 'level-finished', finishedLevel: message.level, ioMs: round(ioMs) });
      else if (message?.kind === 'result') emit({ kind: 'result', result: message.result, ioMs: round(ioMs) });
    });
    return Reflect.apply(originalSend, this, [message, ...args]);
  };
  const load = file => import(pathToFileURL(resolve(file)));
  const [{ NativeV6Runtime }, { V6AgentService }] = await Promise.all([
    load('src/logos-engine/v6-native-runtime.ts'), load('src/runtime/v6-agent-service.ts'),
  ]);
  const sourceFiles = ['src/sic/framed-contact.ts', 'src/sic/managed-glyph-workshop.ts', 'src/sic/managed-glyph-access.ts', 'src/sic/inset-cycle-route.ts', 'src/sic/standalone-families.ts', 'src/sic/experiment-selection-groups.ts',
    'src/logos-engine/v6-native-runtime.ts', 'src/runtime/v6-agent-service.ts', 'scripts/sic-replay-budgets.mjs'];
  emit({ kind: 'profile-start', sourceCommit, levelToCapture, pid: process.pid,
    sourceHashes: Object.fromEntries(sourceFiles.map(file => [file, createHash('sha256').update(readFileSync(resolve(file))).digest('hex')])),
    limitation: 'Diagnostic observer only; timings include observation overhead. Nested family method times overlap. No SIGTERM handler.' });
  const originalPlan = NativeV6Runtime.prototype.plan;
  NativeV6Runtime.prototype.plan = function (...args) {
    inspect(() => {
      instrumentFamilies(this);
      if (level !== levelToCapture) return;
      planNumber++;
      emit({ kind: 'plan-input', revision: this.revision, totalActions: this.actions, observation: this.observation,
        publicPacket: this.current && { ...this.current, frame_rows: undefined, rowsRle: rle(this.current.frame_rows) },
        execution: executionSummary(args[0]) });
    });
    const start = performance.now();
    const done = result => {
      if (level === levelToCapture) inspect(() => emit({ kind: 'plan-result', elapsedMs: round(performance.now() - start),
        selectedFamily: this.prefix?.family?.id, proposal: this.prefix?.proposal, ioMs: round(ioMs) }));
      return result;
    };
    const result = Reflect.apply(originalPlan, this, args);
    return result && typeof result.then === 'function' ? result.then(done) : done(result);
  };
  const originalSelect = NativeV6Runtime.prototype.selectAdmittedFamily;
  NativeV6Runtime.prototype.selectAdmittedFamily = function (...args) {
    if (level === levelToCapture) inspect(() => emit({ kind: 'admission-input', revision: this.revision,
      totalActions: this.actions, observation: this.observation, publicRowsRle: rle(this.current?.frame_rows),
      familyStates: (this.families ?? []).filter(family => watched.has(family.id)).map(family => ({ id: family.id, state: family.state() })),
      inputs: args[1], execution: executionSummary(args[0]) }));
    return Reflect.apply(originalSelect, this, args);
  };
  const originalHandle = V6AgentService.prototype.handle;
  V6AgentService.prototype.handle = function (...args) {
    const request = args[0];
    if (level === levelToCapture || request?.observation?.level === levelToCapture) inspect(() => {
      const observation = request?.observation;
      emit({ kind: 'service-input', request: { ...request,
        ...(observation ? { observation: { ...observation, frame: undefined, frames: undefined,
          rowsRle: rle(observation.frame), framesRle: observation.frames?.map(rle) } } : {}) } });
    });
    const start = performance.now();
    const done = result => {
      if (level === levelToCapture) inspect(() => emit({ kind: 'service-result', method: request?.type,
        elapsedMs: round(performance.now() - start), ticket: result?.ticket, resultKind: result?.kind,
        actualOutcomes: result?.snapshot?.trace?.filter(event => ['actual_outcome', 'sealed_prefix'].includes(event.kind)), ioMs: round(ioMs) }));
      if (!complete && level === levelToCapture && (firstInterruption || levelActions >= maximumCapturedCommands)) {
        complete = true;
        emit({ kind: 'diagnostic-complete', firstInterruption, maximumCapturedCommands, afterNativeServiceReturn: true });
      }
      return result;
    };
    const result = Reflect.apply(originalHandle, this, args);
    return result && typeof result.then === 'function' ? result.then(done) : done(result);
  };
}
