// Pure replay of captured public returns; never creates or advances a game.
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
const [sourceRoot, outputDirectory] = process.argv.slice(2);
const { createSicFramedContact } = await import(pathToFileURL(resolve(sourceRoot, 'src/sic/framed-contact.ts')));
const { observeGlyphWorkshop } = await import(pathToFileURL(resolve(sourceRoot, 'src/sic/managed-glyph-workshop.ts')));
const decode = rows => rows.map(row => row.flatMap((value, index) => index % 2 ? [] : Array(row[index + 1]).fill(value)));
const files = readdirSync(outputDirectory).filter(name => /^framed-family-.*\.jsonl$/.test(name));
assert.equal(files.length, 1);
const records = readFileSync(join(outputDirectory, files[0]), 'utf8').trim().split('\n').flatMap(line => {
  try { return [JSON.parse(line)]; } catch { return []; }
});
const stop = records.find(record => record.kind === 'diagnostic-complete');
assert.ok(stop?.firstInterruption, 'Capture did not contain an interrupted workshop series');
const failed = records.find(record => record.kind === 'guard-input' && record.call === stop.firstInterruption.call);
assert.equal(failed.method, 'after', 'The first refusal was before dispatch; inspect the landing before replaying outcomes');
const original = records.find(record => record.kind === 'family-guard' && record.call === failed.call).result;
const owner = createSicFramedContact(failed.family);
owner.restore(failed.stateBefore);
const reproduced = await owner.after(failed.proposal, failed.index, failed.before, failed.after,
  decode(failed.firstRowsRle), decode(failed.secondRowsRle));
assert.deepEqual(reproduced, original);
const inputs = records.filter(record => record.kind === 'guard-input' && record.family === failed.family
  && record.method === 'after' && record.proposal.binding.observation_ref === failed.proposal.binding.observation_ref
  && record.index <= failed.index).sort((a, b) => a.index - b.index);
assert.equal(inputs.length, failed.index + 1);
let state = structuredClone(inputs[0].proposal.glyphWorkshop.local);
const rows = [];
for (const input of inputs) {
  const step = input.proposal.glyphWorkshop.step, leg = step.walk?.[input.index];
  const currentStep = leg ? { ...step, ...leg, effect: null } : step;
  const result = observeGlyphWorkshop(decode(input.firstRowsRle), decode(input.secondRowsRle), state,
    currentStep, input.after.observation_ref);
  const actual = records.find(record => record.kind === 'family-guard' && record.call === input.call).result;
  rows.push({ index: input.index, before: input.before.observation_ref, after: input.after.observation_ref,
    previousActualRef: rows.at(-1)?.after ?? null, previousActualMatched: rows.at(-1)?.actual.matched ?? null,
    actual, sequentialObservation: result ? { matched: result.matched, reason: result.reason, at: result.state.at,
      phaseBefore: state.cycle?.[0], phaseAfter: result.state.cycle?.[0] } : null });
  if (!result) break;
  state = result.state;
}
const report = { schema: 'sic.framed-prefix-diagnosis.v1',
  sourceCommit: records.find(record => record.kind === 'profile-start').sourceCommit,
  interruption: stop.firstInterruption, sourceReproducedExactReturn: true,
  actualReturnsReplayedInOrder: rows, allSequentialReturnsMatch: rows.length === inputs.length
    && rows.every(row => row.sequentialObservation?.matched === true),
  acquisitionStillDeferredAtInterruptedReturn: JSON.stringify(failed.stateBefore.glyphWorkshop?.at)
    === JSON.stringify(inputs[0].proposal.glyphWorkshop.local.at),
  qualification: 'No production mutation; compares the original guard with the pure ordered acquisition of the same captured physical returns.' };
writeFileSync(join(outputDirectory, 'first-series-diagnosis.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
