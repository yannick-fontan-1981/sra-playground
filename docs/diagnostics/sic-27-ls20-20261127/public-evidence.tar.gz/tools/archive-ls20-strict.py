"""Preserve LS20's public first loss, ordered-return check and frozen strict run."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

work = Path('/workspace/scratch/082336907086/sic-27-work')
root = work / 'framed-cycle'
public = work / 'ls20-public-4b611313'
strict_dir = work / 'ls20-strict-af3e957f'
out = root / 'docs/diagnostics/sic-27-ls20-20261127'
source = 'af3e957f512a43548102992f9ac812c38fca33cc'
read = lambda path: json.loads(path.read_text())
sha = lambda value: hashlib.sha256(value).hexdigest()
strict = read(strict_dir / 'results.jsonl')
baseline = next(json.loads(line) for line in (work / 'baseline-results.jsonl').read_text().splitlines()
                if json.loads(line).get('code') == 'LS20')
start, end = read(strict_dir / 'run-manifest.json'), read(strict_dir / 'run-end.json')
assert start['sourceCommit'] == end['sourceCommit'] == source
assert end['clean'] and end['sourceUnchanged'] and start['sourceHashes'] == end['sourceHashes']
assert strict['levels'] == 7 and strict['actions'] == strict['authority'] == 393
assert strict['reason'] == 'target_levels_completed' and strict['recoveries'] == {'reset': 0, 'undo': 0}
assert end['resultsSha256'] == sha((strict_dir / 'results.jsonl').read_bytes())
assert all(a['prefixHash'] == b['prefixHash'] for a, b in zip(strict['levelStats'][:5], baseline['levelStats'][:5]))
rows = [{key: level[key] for key in ['level', 'actions', 'scoredMs', 'activeMs', 'settlementMs', 'budget', 'prefixHash', 'acquiredRecords']}
        for level in strict['levelStats']]
assert [row['actions'] for row in rows] == [15, 45, 41, 43, 48, 94, 107]
assert [row['budget']['actions'] for row in rows] == [20, 54, 50, 52, 58, 113, 129]
assert [row['budget']['activeTimeMs'] for row in rows] == [12000, 20000, 26000, 23000, 27000, 50000, 67000]
assert all(row['actions'] <= row['budget']['actions'] and row['scoredMs'] <= row['budget']['activeTimeMs'] for row in rows)
check = read(work / 'ls20-ordered-return-candidate.json')
for key in ['sameRecordedPublicReturns', 'noAcquisitionBeforeSeal', 'repeatedGuardIsStable',
            'missingOrForeignPredecessorRefused', 'acquiredStateEqualsSequentialObservation']:
    assert check[key]
members = {}
for prefix, folder in [('public-diagnostic', public), ('strict', strict_dir)]:
    for file in sorted(folder.iterdir()):
        if file.is_file(): members[prefix + '/' + file.name] = file.read_bytes()
for name in ['ls20-native-tests.log', 'ls20-typecheck.log', 'ls20-ordered-return-candidate.json', 'ls20-ordered-return-candidate.log']:
    members['validation/' + name] = (work / name).read_bytes()
members['baseline/LS20-4a546a13.json'] = (json.dumps(baseline, indent=2) + '\n').encode()
members['source/framed-contact.patch'] = subprocess.check_output(['git', 'diff', source + '^', source, '--', 'src/sic/framed-contact.ts'], cwd=root)
for name in ['framed-family-profile.mjs', 'run-ls20-public.py', 'diagnose-framed-series.mjs',
             'check-framed-ordered-returns.mjs', 'run-ls20-strict.py', 'archive-ls20-strict.py']:
    members['tools/' + name] = (work / 'probes' / name).read_bytes()
members['member-manifest.json'] = (json.dumps({name: {'bytes': len(value), 'sha256': sha(value)}
    for name, value in sorted(members.items())}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as tar:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(data), 0o644
        info.mtime = info.uid = info.gid = 0
        tar.addfile(info, io.BytesIO(data))
archive = gzip.compress(buffer.getvalue(), mtime=0)
out.mkdir(parents=True, exist_ok=True)
(out / 'public-evidence.tar.gz').write_bytes(archive)
summary = {'schema': 'sic.workshop-phase-strict.v1', 'game': 'LS20', 'sourceCommit': source,
    'sourceTree': start['sourceTree'], 'sourceHashes': start['sourceHashes'], 'sourceUnchangedDuringRun': True,
    'strictResultSha256': end['resultsSha256'], 'publicTrajectorySha256': strict['trace'],
    'levelsWon': 7, 'commands': 393, 'acquiredRecords': rows[-1]['acquiredRecords'], 'reset': 0, 'undo': 0,
    'initialFivePublicPrefixesIdenticalToCampaign': True, 'perLevel': rows,
    'firstLoss': read(public / 'first-series-diagnosis.json')['interruption'],
    'strictSeriesCount': len(strict['series']), 'strictContinuedCommands': strict['gaps']['continued']['count'],
    'validation': {'targetedTests': 10, 'targetedTestsPassed': 10, 'nativeVariants': 2, 'nativeContradictions': 4,
        'targetedTestExitCode': 0, 'typecheckExitCode': 0, 'capturedActualReturnsChecked': 2, 'capturedReturnProbeExitCode': 0},
    'qualification': ['The native fixture declares the initial geometry, then learns the period through actual returns; it does not test full geometry recognition.',
        'The public diagnostic has instrumentation overhead and is not a timing comparison.',
        'The executed-ticket collector, physical phase contract, full integration gate and published Site replay are subsequent checks.'],
    'archive': {'file': 'public-evidence.tar.gz', 'bytes': len(archive), 'sha256': sha(archive)}}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
table = '\n'.join(f"| {r['level']} | {r['actions']}/{r['budget']['actions']} | {r['scoredMs']/1000:.3f}/{r['budget']['activeTimeMs']/1000:.0f} | {r['settlementMs']/1000:.3f} |"
                  for r in rows)
(out / 'README.md').write_text(f'''# LS20 — contrôle ordonné des phases observées

Le 27 novembre 2026, le banc strict obtient les **sept scores officiels en 393 commandes**, dans une seule session SIC depuis le niveau 1, sans reset ni undo. La source propre `{source}` reste identique avant et après le passage. Les 393 retours sont acquis.

## Qualification chronométrique

| Niveau | Commandes/plafond | Score/plafond (s) | Réconciliation après score (s) |
|---|---:|---:|---:|
{table}

Les plafonds proviennent des mêmes archives et n'ont pas changé. Le niveau 6 marque à **48,956 secondes sous 50 secondes**, puis sa réconciliation prend 0,524 seconde. Le niveau 7 marque à **58,454 secondes sous 67 secondes**, puis sa réconciliation prend 0,402 seconde. Le score public est distingué de sa réconciliation.

Les cinq empreintes de commandes et retours L1–5 sont strictement identiques au bilan `4a546a139f9064422c078ef5f40b8c22133c39a8`. Ce témoin gagnait cinq niveaux, puis s'arrêtait à 72 commandes au niveau 6 sous son plafond de 50 secondes. Le nouveau parcours complet porte l'empreinte `{strict['trace']}`. Aucune parité complète des graphes n'est déduite de ces empreintes publiques.

## Première perte publique et correction

La capture depuis le niveau 1, sur `4b611313f0e445c2a9c6d7c1e1ce02c3224db1f5`, reproduit les 192 gestes des cinq premiers niveaux. Au vingtième geste du niveau 6, le deuxième retour d'une série de cinq est rejeté avec `station_phase_changed`. Les deux retours physiques, relus dans leur ordre réel, correspondent pourtant à la période apprise. Le garde utilisait encore la phase précédant toute la série, car l'acquisition native reste différée jusqu'à sa clôture.

La correction conserve les états observés successifs dans une WeakMap liée à la proposition. Chaque continuation exige le retour précédent confirmé, sa référence exacte et son époque. Les gardes ne publient aucun nouvel état de famille. À la clôture, `record` applique une seule fois les retours exécutés, dans l'ordre, avec les mêmes preuves et les mêmes règles de révision de phase. Le plan, les plafonds et l'arbitrage restent inchangés.

La capture est arrêtée explicitement après le retour natif du premier refus : sa sortie SIGTERM est un arrêt de diagnostic, pas un verdict du jeu. Elle contient un surcoût d'instrumentation ; elle ne sert pas à annoncer un pourcentage d'accélération.

## Variantes, contradictions et réévaluation

Les **dix tests ciblés passent**, ainsi que le typecheck. Les deux nouveaux scénarios natifs changent les formes, la palette, le pas, les positions et le sens des commandes. Ils déclarent leur géométrie initiale, sans fournir de cycle, puis exécutent les dix déplacements nécessaires à deux répétitions physiques avant la première série. Les gardes continuent cette série, sa clôture acquiert chaque retour une fois, le contact suivant conserve une décision séparée et le scénario atteint son score.

Quatre contre-épreuves décalent la phase, changent la position atteinte ou rendent l'acteur ambigu ou absent. Elles clôturent seulement les deux commandes réellement exécutées et conservent les autres connaissances. La phase contredite est retirée, tandis que les preuves de transfert précédentes restent présentes.

La réévaluation hors jeu utilise les **deux mêmes retours publics** qui ont interrompu le témoin. Tous deux sont confirmés en ordre, avec un état de famille inchangé jusqu'à `record`. Répéter un garde ne décale pas deux fois le cycle ; un prédécesseur absent ou étranger est refusé. L'état finalement acquis égale l'application séquentielle des observations effectives.

## Preuves conservées et intégration

L'archive contient le diagnostic public complet, ses manifestes, le probe initial et la réévaluation du candidat, le strict complet et ses empreintes, les journaux de tests/typecheck, le témoin extrait du bilan, le diff de production et les outils reproductibles. Le manifeste interne donne la taille et le SHA-256 de chaque membre. Le probe a été exécuté avant commit sur le même contenu ensuite poussé ; le strict fixe explicitement le SHA ci-dessus.

Le collecteur détaillé des tickets, le contrat de continuité physique des phases, le gate complet de l'intégration et le rejeu dans le Site livré restent des étapes distinctes. Cette archive constate le résultat du banc strict, sans annoncer leur achèvement.

Archive : `public-evidence.tar.gz`, **{len(archive):,} octets**, SHA-256 `{sha(archive)}`.
''')
print(json.dumps({'archive': str(out), 'bytes': len(archive), 'sha256': sha(archive)}, indent=2))
