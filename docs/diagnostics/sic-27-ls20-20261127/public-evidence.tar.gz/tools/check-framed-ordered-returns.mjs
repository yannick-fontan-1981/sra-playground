// Pure replay of recorded public returns. No game is created or advanced.
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';

const [sourceRoot, captureDirectory, reportPath] = process.argv.slice(2);
const { createSicFramedContact } = await import(pathToFileURL(resolve(sourceRoot, 'src/sic/framed-contact.ts')));
const { observeGlyphWorkshop } = await import(pathToFileURL(resolve(sourceRoot, 'src/sic/managed-glyph-workshop.ts')));
const decode = rows => rows.map(row => row.flatMap((value, index) => index % 2 ? [] : Array(row[index + 1]).fill(value)));
const files = readdirSync(captureDirectory).filter(name => /^framed-family-.*\.jsonl$/.test(name));
assert.equal(files.length, 1);
const records = readFileSync(join(captureDirectory, files[0]), 'utf8').trim().split('\n').flatMap(line => {
  try { return [JSON.parse(line)]; } catch { return []; }
});
const interrupted = records.find(record => record.kind === 'diagnostic-complete')?.firstInterruption;
assert.ok(interrupted);
const failed = records.find(record => record.kind === 'guard-input' && record.call === interrupted.call);
assert.equal(failed.method, 'after');
const inputs = records.filter(record => record.kind === 'guard-input' && record.family === failed.family
  && record.method === 'after' && record.proposal.binding.observation_ref === failed.proposal.binding.observation_ref
  && record.index <= failed.index).sort((a, b) => a.index - b.index);
assert.equal(inputs.length, failed.index + 1);
const owner = createSicFramedContact(failed.family), proposal = inputs[0].proposal;
owner.restore(inputs[0].stateBefore);
const retained = structuredClone(owner.state());
let ordered = structuredClone(proposal.glyphWorkshop.local);
const transitions = [], rows = [];
for (const input of inputs) {
  const first = decode(input.firstRowsRle), second = decode(input.secondRowsRle);
  const step = proposal.glyphWorkshop.step, leg = step.walk?.[input.index];
  const currentStep = leg ? { ...step, ...leg, effect: null } : step;
  if (input.index > 0) {
    assert.equal(owner.before(proposal, input.index, { frame_rows: first }, input.before).admitted, true);
    assert.equal(owner.before(proposal, input.index, { frame_rows: first }, {
      ...input.before, observation_ref: 'different-scope:' + input.before.observation_ref,
    }).admitted, false);
  }
  const expected = observeGlyphWorkshop(first, second, ordered, currentStep, input.after.observation_ref);
  assert.ok(expected?.matched);
  const result = await owner.after(proposal, input.index, input.before, input.after, first, second, [second]);
  assert.equal(result.matched, true);
  assert.equal(result.seal_prefix, false);
  assert.deepEqual(owner.state(), retained, 'The guard cannot publish unsealed observations');
  const repeated = await owner.after(proposal, input.index, input.before, input.after, first, second, [second]);
  assert.deepEqual(repeated, result, 'Repeating the same guard must not advance the phase twice');
  ordered = expected.state;
  transitions.push({ input, first, second, expected: ordered });
  rows.push({ index: input.index, before: input.before.observation_ref, after: input.after.observation_ref,
    result, phaseAfter: ordered.cycle?.[0] });
}
const missing = createSicFramedContact(failed.family);
missing.restore(retained);
assert.equal((await missing.after(proposal, failed.index, failed.before, failed.after,
  decode(failed.firstRowsRle), decode(failed.secondRowsRle))).reason, 'workshop_prefix_return_not_bound');
for (const { input, first, second, expected } of transitions) {
  await owner.record(input.before, input.after, proposal.actions[input.index], first, second,
    proposal, input.index, [second]);
  assert.deepEqual(owner.state().glyphWorkshop, expected, 'The acquired state equals the ordered actual returns');
}
const report = { schema: 'sic.framed-ordered-return-check.v1',
  captureSourceCommit: records.find(record => record.kind === 'profile-start').sourceCommit,
  candidateBaseCommit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: sourceRoot, encoding: 'utf8' }).trim(),
  candidateDirty: execFileSync('git', ['status', '--porcelain'], { cwd: sourceRoot, encoding: 'utf8' }).trim() !== '',
  interrupted, orderedReturns: rows, sameRecordedPublicReturns: true, noAcquisitionBeforeSeal: true,
  repeatedGuardIsStable: true, missingOrForeignPredecessorRefused: true, acquiredStateEqualsSequentialObservation: true,
  qualification: 'No game replay. The two real returns that interrupted the baseline prefix now pass in order, with publication still deferred.' };
writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
