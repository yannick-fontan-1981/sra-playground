"""Bounded chronological public capture; no budget, game or solver mutation."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

root, expected, out = Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve()
probe = Path(__file__).with_name('framed-family-profile.mjs')
git = lambda *args: subprocess.check_output(['git', *args], cwd=root, text=True).strip()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
files = ['src/sic/framed-contact.ts', 'src/sic/managed-glyph-workshop.ts', 'src/sic/managed-glyph-access.ts',
         'src/sic/inset-cycle-route.ts', 'src/sic/standalone-families.ts', 'src/sic/experiment-selection-groups.ts',
         'src/logos-engine/v6-native-runtime.ts', 'src/runtime/v6-agent-service.ts',
         'scripts/check-sic-chronological.mjs', 'scripts/sic-replay-budgets.mjs',
         'docs/architecture/sic-replay-reference-levels-20261126.json',
         'docs/architecture/sic-v8-level6-campaign-7bb9f152.json']
assert git('rev-parse', 'HEAD') == expected and not git('status', '--porcelain')
assert not out.exists(), 'Each capture needs an immutable output directory'
out.mkdir()
(out / probe.name).write_bytes(probe.read_bytes())
settings = {'SIC_REPLAY_REFERENCES': 'docs/architecture/sic-replay-reference-levels-20261126.json',
            'SIC_FRAMED_PROFILE_DIR': str(out), 'SIC_FRAMED_PROFILE_EXPECTED_SHA': expected,
            'SIC_FRAMED_PROFILE_LEVEL': '6', 'SIC_FRAMED_PROFILE_COMMANDS': '32'}
command = ['node', '--import', str(probe), 'scripts/check-sic-chronological.mjs', 'LS20', '6',
           str(out / 'results.jsonl'), '1', 'sic']
manifest = {'startedAt': now(), 'sourceCommit': expected, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
            'sourceHashes': {name: digest(root / name) for name in files}, 'game': 'LS20', 'startLevel': 1,
            'targetLevels': 6, 'workers': 1, 'command': command, 'environment': settings,
            'probeSha256': digest(probe), 'cwd': str(root),
            'qualification': 'Public diagnostic only; original per-level budgets. Stop after the native reply for the first interrupted workshop series, otherwise after 32 commands in level6.'}
(out / 'run-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'startedAt': manifest['startedAt'], 'sourceCommit': expected, 'output': str(out)}), flush=True)
positions, pending = {}, {}
marker = None
with (out / 'runner.log').open('w') as log:
    process = subprocess.Popen(command, cwd=root, env={**os.environ, **settings}, stdout=log,
                               stderr=subprocess.STDOUT, start_new_session=True)
    while process.poll() is None:
        for file in out.glob('framed-family-*.jsonl'):
            with file.open() as stream:
                stream.seek(positions.get(file, 0))
                text = pending.get(file, '') + stream.read()
                positions[file] = stream.tell()
            lines = text.split('\n')
            pending[file] = lines.pop()
            for line in lines:
                if '"kind":"diagnostic-complete"' in line:
                    marker = json.loads(line)
        if marker:
            (out / 'capture-stop.json').write_text(json.dumps({'observedAt': now(), 'marker': marker,
                'termination': 'SIGTERM after native service returned; no fabricated game verdict'}, indent=2) + '\n')
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            break
        time.sleep(0.1)
    exit_code = process.wait()
end = {'observedEndAt': now(), 'exitCode': exit_code, 'sourceCommit': git('rev-parse', 'HEAD'),
       'clean': not git('status', '--porcelain'), 'sourceHashes': {name: digest(root / name) for name in files},
       'diagnosticStoppedAtMarker': marker is not None,
       'resultsSha256': digest(out / 'results.jsonl') if (out / 'results.jsonl').exists() else None,
       'publicLogs': {file.name: {'bytes': file.stat().st_size, 'sha256': digest(file)} for file in out.glob('framed-family-*.jsonl')}}
end['sourceUnchanged'] = end['sourceCommit'] == expected and end['clean'] and end['sourceHashes'] == manifest['sourceHashes']
(out / 'run-end.json').write_text(json.dumps(end, indent=2) + '\n')
assert end['sourceUnchanged'], 'Source changed during diagnostic'
assert exit_code == 0 or marker is not None, 'Harness failed before diagnostic boundary'
print(json.dumps({'endedAt': end['observedEndAt'], 'exitCode': exit_code,
                  'marker': marker, 'sourceUnchanged': end['sourceUnchanged']}), flush=True)
