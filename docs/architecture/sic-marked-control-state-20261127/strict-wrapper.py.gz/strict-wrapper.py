"""Run the unchanged chronological runner on the saved SPOR candidate once."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/082336907086/sic-27-work')
checkout = root / 'compositions'
output = root / 'spor-strict-aebdb01a'
expected = '0b89cca08d13dff424d30a55811813e4d170a1cf'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=checkout, text=True).strip()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
if head != expected or git('status', '--porcelain'):
    raise SystemExit('The saved SPOR source must be unchanged and clean before replay')
result_path = output.with_suffix('.jsonl')
if result_path.exists():
    raise SystemExit('Refusing to append to an existing qualification result')
references = checkout / 'docs/architecture/sic-replay-reference-levels-20261126.json'
runner = checkout / 'scripts/check-sic-chronological.mjs'
command = ['node', str(runner), 'SPOR', '6', str(result_path), '1']
manifest = {'startedAt': now(), 'local': head,
    'remote': '053889f8f3a6023787be3d4ed3c392b94f4d5f01', 'tree': tree,
    'productionLocal': 'aebdb01a9f45436b4d7e1210db4f57e19a1c30fd',
    'productionRemote': 'e447b19328e3e31f1eb19e4e1fd8bf3f7616c676',
    'checkout': str(checkout), 'command': command, 'startLevel': 1,
    'targetLevels': 6, 'workers': 1, 'references': str(references),
    'referencesSha256': hashlib.sha256(references.read_bytes()).hexdigest(),
    'runnerSha256': hashlib.sha256(runner.read_bytes()).hexdigest(),
    'budgetsChanged': False, 'result': str(result_path)}
output.with_suffix('.start.json').write_text(json.dumps(manifest, indent=2) + '\n')
environment = os.environ.copy()
environment['SIC_REPLAY_REFERENCES'] = str(references)
with output.with_suffix('.log').open('w') as log:
    completed = subprocess.run(command, cwd=checkout, env=environment, stdout=log, stderr=subprocess.STDOUT)
manifest.update({'endedAt': now(), 'exitCode': completed.returncode,
    'finalLocal': git('rev-parse', 'HEAD'), 'finalTree': git('rev-parse', 'HEAD^{tree}'),
    'finalStatus': git('status', '--porcelain')})
manifest['sourceUnchanged'] = manifest['finalLocal'] == head and manifest['finalTree'] == tree and not manifest['finalStatus']
output.with_suffix('.end.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in ['endedAt', 'exitCode', 'sourceUnchanged', 'result']}), flush=True)
raise SystemExit(completed.returncode)
