import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const load = file => import(pathToFileURL(resolve(file)));
const { measureNativeObservation } = await load('src/logos-engine/v6-native-observer.ts');
const { measureContextualCompartments } = await load('src/logos-engine/v6-contextual-compartments.ts');
const { createSicMarkedCompartmentFlow, projectRecalledOutlet } = await load('src/sic/marked-compartment-flow.ts');
const capture = JSON.parse(await readFile(process.argv[2], 'utf8'));
const target = Number(process.argv[4] ?? 4), owner = 'sic_follow_observed_compartment_readiness';
const fingerprint = rows => createHash('sha256').update(JSON.stringify(rows)).digest('hex').slice(0, 16);
const observe = (packet, revision, scope) => measureNativeObservation({ frame_rows: packet.frame,
  frame_hash: fingerprint(packet.frame), level: packet.level, levels_completed: packet.levelsCompleted,
  state: packet.state, available_action_refs: packet.availableActionIds.map(id => 'ACTION' + id) }, revision, scope);
const sceneSummary = scene => scene && ({ key: scene.key, mark: scene.mark, normal: scene.normal,
  background: scene.background, frames: scene.frames, marked: scene.marked });
const regionPopulation = (rows, box) => {
  if (!box) return null;
  const [left, top, right, bottom] = box, counts = new Map();
  for (let y = top + 1; y < bottom; y++) for (let x = left + 1; x < right; x++) {
    const ink = rows[y]?.[x]; counts.set(ink, (counts.get(ink) ?? 0) + 1);
  }
  return Object.fromEntries([...counts].sort((a, b) => a[0] - b[0]));
};
const rows = [];
for (const sample of capture.samples.filter(sample => sample.before.level === target)) {
  const prior = sample.states[owner], witness = prior?.witness;
  const beforeScene = witness ? await measureContextualCompartments(sample.before.frame, witness.mark) : null;
  const afterScene = witness && sample.after.level === sample.before.level
    ? await measureContextualCompartments(sample.after.frame, witness.mark) : null;
  const beforeRef = sample.proposal?.binding?.observation_ref
    ?? sample.trace.findLast(event => event.kind === 'sic_native_plan')?.observationRef;
  const scope = beforeRef?.split(':epoch:')[0], revision = Number(beforeRef?.match(/:revision:(\d+)/)?.[1]);
  const retained = sample.returnStates?.[owner];
  let ownAfter = null, fallbackAfter = null;
  if (retained && scope && Number.isSafeInteger(revision)) {
    const after = await observe(sample.after, revision + 1, scope), family = createSicMarkedCompartmentFlow();
    family.restore(structuredClone(retained));
    ownAfter = await family.propose(after, sample.after.frame, [], 2);
    fallbackAfter = retained.witness && await projectRecalledOutlet(retained.witness, after,
      sample.after.frame, retained.attempted ?? []);
  }
  rows.push({ ordinal: sample.ordinal, action: sample.action, family: sample.proposal?.kind,
    strategy: sample.proposal?.sicSituationCard?.strategy, beforeRef,
    completedBefore: sample.before.levelsCompleted, completedAfter: sample.after.levelsCompleted,
    before: sceneSummary(beforeScene), after: sceneSummary(afterScene),
    outletPopulationBefore: regionPopulation(sample.before.frame, witness?.outlet),
    outletPopulationAfter: regionPopulation(sample.after.frame, witness?.outlet),
    changedRegion: sample.proposal?.changedRegion, release: sample.proposal?.release ?? null,
    stateBefore: prior, stateAfter: retained ?? null,
    ownAfter: ownAfter && { choice: ownAfter.actions, strategy: ownAfter.sicSituationCard?.strategy,
      region: ownAfter.changedRegion, release: ownAfter.release, flow: ownAfter.flow, evidence: ownAfter.route_refs },
    fallbackAfter, nativeReturn: sample.replyTrace?.filter(event => ['actual_outcome', 'sealed_prefix'].includes(event.kind)).slice(-2),
  });
}
const stop = capture.diagnosticStop;
const report = { source: process.cwd(), diagnostic: true, target, rows,
  nextDecision: stop && { kind: stop.kind, afterOrdinal: stop.afterOrdinal, ticket: stop.ticket,
    proposal: stop.proposal, states: stop.states, offers: stop.offers } };
await writeFile(process.argv[3], JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ count: rows.length, last: rows.slice(-3).map(row => ({ ordinal: row.ordinal,
  family: row.family, strategy: row.strategy, before: row.outletPopulationBefore, after: row.outletPopulationAfter,
  scoreChanged: row.completedAfter > row.completedBefore, ownAfter: row.ownAfter?.strategy ?? null,
  fallbackAfter: !!row.fallbackAfter, markedAfter: row.after?.marked.map(chamber => ({ box: chamber.box, filled: chamber.filled })) })),
  next: stop && { family: stop.proposal?.kind, strategy: stop.proposal?.sicSituationCard?.strategy,
    offers: stop.offers.map(offer => ({ family: offer.family, group: offer.group, admitted: !!offer.proposal })) } }));
