// Offline projections of captured public scenes. No game is created or advanced.
import { readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { stripTypeScriptTypes } from 'node:module';

const sourceURL = pathToFileURL(resolve('src/sic/navigate-revealed-grid.ts'));
const source = (await readFile(sourceURL, 'utf8')).replace(/from (['"])(\.\.?\/[^'"]+)\1/g,
  (_, quote, spec) => 'from ' + quote + new URL(spec, sourceURL).href + quote);
const code = stripTypeScriptTypes(source + '\nexport { measure as diagnosticMeasure, read as diagnosticRead, route as diagnosticRoute };\n');
const { createSicNavigateRevealedGrid, diagnosticMeasure, diagnosticRead, diagnosticRoute } =
  await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
const { measureNativeObservation } = await import(pathToFileURL(resolve('src/logos-engine/v6-native-observer.ts')));
const capture = JSON.parse(await readFile(process.argv[2], 'utf8'));
const level = Number(process.argv[4] ?? 5), actionCap = Number(process.argv[5] ?? 42);
const samples = capture.samples.filter(sample => sample.before.level === level), rows = [];
for (const [index, sample] of samples.entries()) {
  const ref = sample.ticket?.observationRef;
  if (!ref) throw Error('An actual current ticket observation reference is required');
  const scope = ref.split(':epoch:')[0], revision = Number(ref.match(/:revision:(\d+)/)?.[1]);
  if (!scope || !Number.isSafeInteger(revision)) throw Error('Invalid captured observation reference');
  const observation = await measureNativeObservation({ frame_rows: sample.before.frame,
    frame_hash: sample.ticket.frameHash, level: sample.before.level,
    levels_completed: sample.before.levelsCompleted, state: sample.before.state,
    available_action_refs: sample.before.availableActionIds.map(id => 'ACTION' + id) }, revision, scope);
  if (observation.observation_ref !== ref) throw Error('The public scene does not reproduce its ticket reference');
  const family = createSicNavigateRevealedGrid(), saved = sample.states[family.id], prior = saved?.state;
  if (saved) family.restore(structuredClone(saved));
  const normal = diagnosticMeasure(sample.before.frame);
  const rebound = prior ? diagnosticMeasure(sample.before.frame, prior.grid) : null;
  const grid = normal ?? rebound, reading = grid ? diagnosticRead(sample.before.frame, grid) : null;
  const proposal = await family.propose(observation, sample.before.frame, [], Math.max(0, actionCap - index));
  rows.push({ ordinal: sample.ordinal, levelAction: index + 1, ticket: sample.ticket,
    actualFamily: sample.proposal?.kind, actualStrategy: sample.proposal?.sicSituationCard?.strategy,
    actualCommand: sample.action, actualProposal: sample.proposal, actualOffers: sample.offers,
    selectionTrace: sample.selectionTrace, inherited: saved,
    measurement: { normal, rebound, reading, route: reading ? diagnosticRoute(reading, grid) : null,
      afterWithBeforeGrid: grid ? diagnosticRead(sample.after.frame, grid, reading) : null },
    independentProjection: proposal, publicObservers: sample.publicObservers ?? [],
    returnStates: sample.returnStates ?? null, checks: sample.checks ?? [], replyTrace: sample.replyTrace ?? [],
    scoreBefore: sample.before.levelsCompleted, scoreAfter: sample.after.levelsCompleted });
}
const report = { source: process.cwd(), diagnostic: true, level, actionCap,
  note: 'Independent proposals are offline projections of each captured public scene and retained state. They are not executed decisions.',
  rows, unexecutedStop: capture.diagnosticStop };
await writeFile(process.argv[3], JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ level, count: rows.length, rows: rows.map(row => ({ ordinal: row.ordinal,
  actual: row.actualFamily, command: row.actualCommand, normal: !!row.measurement.normal,
  rebound: !!row.measurement.rebound, projectedActions: row.independentProjection?.actions.length ?? 0,
  projectedChoice: row.independentProjection?.choice ?? null,
  seals: row.replyTrace.filter(event => event.kind === 'sealed_prefix').length })),
  stop: capture.diagnosticStop?.kind ?? null }));
