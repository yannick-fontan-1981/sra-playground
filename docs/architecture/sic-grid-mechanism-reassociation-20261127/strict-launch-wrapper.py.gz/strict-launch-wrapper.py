"""Run the unchanged chronological runner on the saved SNAR candidate once."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/082336907086/sic-27-work')
checkout = root / 'grid-continuity'
output = root / 'snar-strict-7f45cf18'
expected = '7f45cf182c5d9e0f9506f5d2fb07af64f3ae2def'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=checkout, text=True).strip()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
if head != expected or git('status', '--porcelain'):
    raise SystemExit('The saved SNAR source must be unchanged and clean before replay')
result_path = output.with_suffix('.jsonl')
if result_path.exists():
    raise SystemExit('Refusing to append to an existing qualification result')
references = checkout / 'docs/architecture/sic-replay-reference-levels-20261126.json'
runner = checkout / 'scripts/check-sic-chronological.mjs'
command = ['node', str(runner), 'SNAR', '6', str(result_path), '1']
manifest = {'startedAt': now(), 'local': head,
    'remote': '56df4eab7b6701f65d5189913e61acb27865567b', 'tree': tree,
    'productionLocal': '7f45cf182c5d9e0f9506f5d2fb07af64f3ae2def',
    'productionRemote': '56df4eab7b6701f65d5189913e61acb27865567b',
    'checkout': str(checkout), 'command': command, 'startLevel': 1,
    'targetLevels': 6, 'workers': 1, 'references': str(references),
    'referencesSha256': hashlib.sha256(references.read_bytes()).hexdigest(),
    'runnerSha256': hashlib.sha256(runner.read_bytes()).hexdigest(),
    'budgetsChanged': False, 'result': str(result_path)}
output.with_suffix('.start.json').write_text(json.dumps(manifest, indent=2) + '\n')
environment = os.environ.copy()
environment['SIC_REPLAY_REFERENCES'] = str(references)
with output.with_suffix('.log').open('w') as log:
    completed = subprocess.run(command, cwd=checkout, env=environment, stdout=log, stderr=subprocess.STDOUT)
manifest.update({'endedAt': now(), 'exitCode': completed.returncode,
    'finalLocal': git('rev-parse', 'HEAD'), 'finalTree': git('rev-parse', 'HEAD^{tree}'),
    'finalStatus': git('status', '--porcelain')})
manifest['sourceUnchanged'] = manifest['finalLocal'] == head and manifest['finalTree'] == tree and not manifest['finalStatus']
output.with_suffix('.end.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in ['endedAt', 'exitCode', 'sourceUnchanged', 'result']}), flush=True)
raise SystemExit(completed.returncode)
