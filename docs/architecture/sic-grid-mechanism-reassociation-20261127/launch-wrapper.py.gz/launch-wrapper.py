"""Bounded public diagnostic; deliberately not a new strict game verdict."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/082336907086/sic-27-work')
checkout = root / 'grid-continuity'
output = root / 'snar-l5-first-loss-v2-diagnostic-07676e1e'
capture = root / 'snar-l5-first-loss-v2-capture-07676e1e.json'
expected = 'c12edff8679d783d45d71bb0f6c3ece7630186e6'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=checkout, text=True).strip()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
if head != expected or git('status', '--porcelain'):
    raise SystemExit('The diagnostic source must remain unchanged and clean')
result_path = output.with_suffix('.jsonl')
if result_path.exists() or capture.exists():
    raise SystemExit('Refusing to overwrite a previous diagnostic')
references = checkout / 'docs/architecture/sic-replay-reference-levels-20261126.json'
runner = root / 'grid-first-loss-diagnostic-v2.mjs'
command = ['node', str(runner), 'SNAR', '5', str(result_path), '1']
manifest = {'startedAt': now(), 'local': head,
    'remote': '6f938fd61ee4dd3a92972184bb96cdb122279163', 'tree': tree,
    'productionLocal': '07676e1eb49caf0d4323c798df20b15a2e480161',
    'productionRemote': '5773d96313daec7d62d6d314c484274f03ed565c',
    'checkout': str(checkout), 'command': command, 'startLevel': 1, 'targetLevel': 5,
    'diagnosticLimit': 'At most eight commands in level 5; stop before the first cavity ticket if earlier.',
    'newGameVerdict': None, 'workers': 1, 'references': str(references),
    'referencesSha256': hashlib.sha256(references.read_bytes()).hexdigest(),
    'runnerSha256': hashlib.sha256(runner.read_bytes()).hexdigest(),
    'originalBudgetsUnchanged': True, 'result': str(result_path), 'capture': str(capture)}
output.with_suffix('.start.json').write_text(json.dumps(manifest, indent=2) + '\n')
environment = os.environ.copy()
environment.update({'SIC_REPLAY_REFERENCES': str(references), 'SIC_DIAGNOSTIC_LEVEL': '5',
    'SIC_DIAGNOSTIC_MIN_LEVEL': '5', 'SIC_DIAGNOSTIC_ACTIONS': '8', 'SIC_DIAGNOSTIC_CAPTURE': str(capture)})
with output.with_suffix('.log').open('w') as log:
    completed = subprocess.run(command, cwd=checkout, env=environment, stdout=log, stderr=subprocess.STDOUT)
manifest.update({'endedAt': now(), 'exitCode': completed.returncode,
    'finalLocal': git('rev-parse', 'HEAD'), 'finalTree': git('rev-parse', 'HEAD^{tree}'),
    'finalStatus': git('status', '--porcelain')})
manifest['sourceUnchanged'] = manifest['finalLocal'] == head and manifest['finalTree'] == tree and not manifest['finalStatus']
output.with_suffix('.end.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in ['endedAt', 'exitCode', 'sourceUnchanged', 'result']}), flush=True)
raise SystemExit(completed.returncode)
